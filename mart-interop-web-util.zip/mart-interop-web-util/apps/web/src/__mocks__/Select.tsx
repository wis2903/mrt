const Select: React.FC<any> & { Option: any } = ({ value, onChange, children, options, filterOption, onSelect }) => {
  const handleChange = (e: any) => {
    onSelect && onSelect(e.target.value);
    onChange && onChange(e);
    return filterOption?.();
  };
  return (
    <>
      <input data-testid='select-onChange' value={value || ''} onChange={handleChange} />
      {children}
      <div data-testid='select-options'>
        {options?.map((option: any) => (
          <span key={option.value} title={option.value} onClick={() => onChange(option)}>
            {option.label}
          </span>
        ))}
      </div>
    </>
  );
};
const Option = ({ value, onChange }: any) => {
  return (
    <div
      data-testid={`options-${value}`}
      onClick={() => {
        onChange(value);
      }}>
      {value}
    </div>
  );
};
Select.Option = Option;

export default Select;
