import GlobalLoader from 'v2/app/components/loader/global-loader';

import { useAuth } from 'hooks/useAuth';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { LOGIN_URI } from 'routes/routes';

const PrivateRoute = () => {
    const auth = useAuth();
    const location = useLocation();

    if (auth?.initialing) return <GlobalLoader />;
    if (!auth?.user) return <Navigate to={LOGIN_URI} state={{ from: location }} replace />;
    return <Outlet />;
};

export default PrivateRoute;
