import LanguageProvider from 'containers/LanguageProvider';
import LoadingContainer from 'containers/LoadingContainer';
import dayjs from 'dayjs';
import duration from 'dayjs/plugin/duration';
import relativeTime from 'dayjs/plugin/relativeTime';
import GlobalStyle from 'globalStyle';
import ReactDOM from 'react-dom/client';
import configureStore from 'store/store';
import App from './App';

import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ability } from 'casl/ability';
import { AbilityContext } from 'casl/can';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import { ThemeProvider } from 'styled-components';
import { defaultTheme } from 'styles/defaultTheme.styles';
import { initMixpanel } from 'utils/mixpanel';
import { loadFontAssets } from '../../web-2.2/src/app/layout/fetch';
import { I18nProvider as Web22I18nProvider } from '../../web-2.2/src/app/provider/i18n';
import { store as web22Store } from '../../web-2.2/src/app/store';
import { StoreProvider as Web22StoreProvider } from '../../web-2.2/src/core/store';
import { translationMessages } from './i18n';

import './font-face.css';
import './index.css';

const store = configureStore;
const MOUNT_NODE = document.getElementById('root') as HTMLElement;
const root = ReactDOM.createRoot(MOUNT_NODE);
dayjs.extend(duration);
dayjs.extend(relativeTime);
initMixpanel();
loadFontAssets();

const queryClient = new QueryClient();

const render = (messages: any) => {
    root.render(
        <BrowserRouter>
            <Provider store={store}>
                <Web22StoreProvider state={web22Store}>
                    <AbilityContext.Provider value={ability}>
                        <LanguageProvider messages={messages}>
                            <Web22I18nProvider>
                                <QueryClientProvider client={queryClient}>
                                    <ThemeProvider theme={defaultTheme}>
                                        <GlobalStyle />
                                        <LoadingContainer>
                                            <App />
                                        </LoadingContainer>
                                    </ThemeProvider>
                                </QueryClientProvider>
                            </Web22I18nProvider>
                        </LanguageProvider>
                    </AbilityContext.Provider>
                </Web22StoreProvider>
            </Provider>
        </BrowserRouter>
    );
};

render(translationMessages);
