import { renderWithProvider, screen } from 'test';
import Component from '.';

describe('Render component', () => {
  it('should render without crash', () => {
    const { container } = renderWithProvider(<Component />);
    screen.getByTestId('submit').click();
    expect(container).toBeTruthy();
  });
});
