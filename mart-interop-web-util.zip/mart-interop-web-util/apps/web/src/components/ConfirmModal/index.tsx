import ExclamationCircleOutlined from '@ant-design/icons/lib/icons/ExclamationCircleOutlined'
import { Modal, ModalFuncProps } from 'antd'

type ConfirmModalProps = {
  t: any
  onOk?: () => void
  onCancel?: () => void
  content?: any
  title?: string
  extraContent?: React.ReactNode
  isDisabledFooter?: boolean
}
const confirmModal = ({ t, onOk, onCancel, content, title, extraContent, isDisabledFooter }: ConfirmModalProps) => {
  const modalConfigs: ModalFuncProps = {
    title: title || t('common.message.confirmTitle'),
    icon: <ExclamationCircleOutlined />,
    content: (
      <>
        <div>{content || t('common.message.confirmText')}</div>
        {extraContent}
      </>
    ),
    okText: t('common.button.ok'),
    cancelText: t('common.button.cancel'),
    okButtonProps: {
      className: 'bg-red-600'
    },
    onOk,
    onCancel
  }
  if (isDisabledFooter) {
    modalConfigs.cancelButtonProps = { style: { display: 'none' } }
    modalConfigs.okButtonProps = { style: { display: 'none' } }
  }
  return Modal.confirm(modalConfigs)
}

export default confirmModal
