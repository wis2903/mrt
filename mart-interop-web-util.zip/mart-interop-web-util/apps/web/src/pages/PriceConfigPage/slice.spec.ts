import { initialState, reducer, reducerActions, sagaOption, selectors, sliceName } from './slice';
import store from 'store/store';
import { fakeProduct } from './mockData';
import * as api from 'apis/sku';
import { mockProvinces } from './mockProvinces';
import { selectors as masterDataSelectors } from 'store/masterData/slice';
import { ALL_OPTIONS } from './constant';

describe('reducerActions', () => {
  it('fetchSkuDetailSuccess', () => {
    expect(reducer(initialState, reducerActions.fetchSkuDetailSuccess(fakeProduct))).toBeTruthy();
  });
  it('updateFormData', () => {
    expect(
      reducer(
        initialState,
        reducerActions.updateFormData([
          {
            id: 1
          }
        ])
      )
    ).toBeTruthy();
  });
  it('changeSelectedRegion', () => {
    expect(reducer(initialState, reducerActions.changeSelectedRegion('view'))).toBeTruthy();
  });
  it('changeSelectedSkuConfig', () => {
    expect(reducer(initialState, reducerActions.changeSelectedSkuConfig(fakeProduct.configurations[0]))).toBeTruthy();
  });
});

describe('selectors', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    jest.spyOn(masterDataSelectors, 'selectorProvinceList').mockReturnValue(mockProvinces);
  });
  const state = {
    masterData: {
      provinceList: mockProvinces
    },
    [sliceName]: {
      masterData: {
        provinceList: mockProvinces
      },
      selectedRegion: ALL_OPTIONS.name,
      districts: [],
      loading: true,
      provincesFormData: [{ province: { value: '01', label: 'Thành phố Hà Nội', region: 'Red River Delta' }, region: 'Red River Delta' }]
    }
  };

  it('availableProvincesSelector', () => {
    expect(selectors.availableProvincesSelector(state).length).toEqual(62);
  });
});

describe('sagaActions', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });
  it('fetchSkuDetail', async () => {
    const spyAction = jest.spyOn(reducerActions, 'fetchSkuDetailSuccess');
    const getMasterData = jest.spyOn(api, 'getSkuDetail');
    getMasterData.mockResolvedValueOnce({ data: {} } as any);
    await store.runSaga(sagaOption.caseSagas.fetchSkuDetail, { payload: {} }).toPromise();
    expect(spyAction).toBeCalledTimes(1);
  });
});
