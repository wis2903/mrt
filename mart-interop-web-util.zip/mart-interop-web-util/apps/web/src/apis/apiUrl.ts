export const BASE_AUTH = `/auth`;
export const LOGIN = `${BASE_AUTH}/sign-in`;
export const LOGOUT = `${BASE_AUTH}/sign-out`;
export const SIGNUP = `${BASE_AUTH}/signUp`;
export const GET_ACCESS_TOKEN = `${BASE_AUTH}/refresh`;
export const GET_CURRENT_USER = `${BASE_AUTH}/me`;
export const INVENTORY = `warehouse/inventory`;

// master
export const MASTER = `/warehouse/master`;

// mock url
export const USERS = `/users`;

// file
export const FILE = `/warehouse/file`;
export const FILE_V2 = `/mart-sp-mgmt/1.0/portal/image/upload`;

// product
export const CREATE_SKU = '/warehouse/sku';
export const GET_SKU = '/warehouse/sku';
export const DELETE_SKU = '/warehouse/sku';
export const UPDATE_SKU = '/warehouse/sku';
export const SELLING_PRICE = 'selling-price';
export const GET_SKU_LIST = '/warehouse/sku/search';
export const GET_SKU_LIST_V2 = '/warehouse/sku/price/search';
export const SKU_CONFIGURATIONS = '/warehouse/sku-configurations';
export const SKU_POINT = '/warehouse/sku-point/';
export const SKU_POINT_TEMPLATE = `${SKU_POINT}template`;
export const SKU_MARKET_PRICE = '/warehouse/price-match/';
export const SKU_MARKET_PRICE_TEMPLATE = `${SKU_MARKET_PRICE}template`;

//
export const ORDERS = '/orders';
export const ORDERSV2 = '/mart-sp-mgmt/1.0/portal/orders';
export const GET_ORDERS = '/orders/order-list-search';
export const GET_ORDERSV2 = '/mart-sp-mgmt/1.0/portal/orders/search';
export const GET_ORDERSV2_1_1 = '/mart-sp-mgmt/1.1/portal/orders/search';
export const GET_ORDERSV2_BY_PRODUCT_1_1 = '/mart-sp-mgmt/1.1/portal/orders/search-by-product';
export const GET_ORDERSV2_DETAILS_1_1 = '/mart-sp-mgmt/1.1/portal/orders/:id';
export const GET_PROMOTIONS = '/mart-promotion/1.0/deals/';
export const GET_PROMOTIONSV2 = '/mart-promotion/2.0/deals/';
export const UPLOAD_PROMOTION_IMAGE = '/mart-promotion/1.0/portal/promotion/upload/image';
export const CREATE_PROMOTIONS = '/mart-promotion/1.0/deals/';
export const VALIDATE_PROMOTIONS = '/mart-promotion/1.0/deals/validate';
export const COUNT_PROMOTION_APPLIED_TIMES = '/mart-promotion/2.0/deals/:id/count';
export const DELETE_PROMOTIONS = '/mart-promotion/1.0/deals/';
export const REPORT = '/report';
export const RECONCILIATION = '/orders/system/reconcile';
export const SYNC_PROMOTIONS = '/mart-promotion/1.0/portal/amast/promotion/sync';
export const GET_HOLDING_INVENTORY_ORDERS = '/mart-sp-mgmt/1.0/portal/inventories/onhold';
export const SEARCH_MALAY_INVENTORY = '/mart-sp-mgmt/1.0/portal/inventories';
export const SEARCH_INVENTORY_BY_POST_METHOD = '/mart-sp-mgmt/1.0/portal/inventories/search';

// locations
export const PROVINCES = '/warehouse/master/locations/provinces';

// cx
export const GET_NOTIFICATIONS = '/my/loyalty/1.0/external/ito/notificationCampaigns';
export const CREATE_NOTIFICATIONS = '/my/loyalty/1.0/external/ito/notificationCampaign';
