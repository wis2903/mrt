import { Order } from '../../types/Orders'

export const mockOrder: Order = {
  orderId: 1274797,
  haravanOrderNumber: '100339',
  source: 'Amast',
  total: 60000,
  grandTotal: 6000,
  createdDate: '2023-02-21T04:46:05.186967Z',
  totalItemCount: 1,
  totalQuantity: 1,
  currentStatus: 'CREATED',
  warehouseId: 11,
  grossWeight: 1,
  selfPickup: false,
  customerDetails: {
    customerId: 360005,
    customerZaloId: '',
    customerName: 'Luong (First)',
    phoneNumber: '03749573447',
    email: ''
  },
  firstItemDetail: null,
  shippingAddressDetails: {
    shippingCountry: 'Viet Nam',
    shippingProvince: 'Thành phố Đà Nẵng',
    shippingDistrict: 'Huyện Hòa Vang',
    shippingAddress: 'Thành phố Đà Nẵng',
    shippingWard: 'Xã Hòa Phú',
    shippingCountryId: '6',
    shippingProvinceId: '48',
    shippingDistrictId: '497',
    shippingWardId: '20317'
  },
  orderType: 'presale',
}
