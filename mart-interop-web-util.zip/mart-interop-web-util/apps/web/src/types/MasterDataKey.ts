export type MasterDataKey =
  | 'brandList'
  | 'categoryList'
  | 'sourceList'
  | 'countryList'
  | 'provinceList'
  | 'allProvinces'
  | 'orderStatusList'
  | 'warehouseList';

export type MasterDataItem = {
  id: number | string;
  code?: string;
  name: string;
  parentName?: string | null;
  parentId?: number;
  warehouseId?: number | null;
  region?: string;
};

export type ProvinceDataItem = {
  id: number | string;
  name: string;
  warehouseId: number | null;
  region: string;
};

export type WarehouseDataItem = {
  id: number | string;
  code: string;
  name: string;
};
