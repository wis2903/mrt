export const ALL_OPTIONS = {
  name: 'ALL'
};
