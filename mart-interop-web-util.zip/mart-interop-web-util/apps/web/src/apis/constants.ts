export const HTTP_AUTHORIZATION_HEADER = 'Authorization';
export const INVALID_CREDENTIAL_ERR = 'InvalidCredential';

export const orderAPIs = {
  ORDERS: '/orders'
};
