import { InputNumberProps } from 'antd';
import { useEffect, useState } from 'react';
import { formatterMoney, parserMoney } from 'utils/formatUtils';
import { MoneyInputStyled } from './styled';

const MoneyInput = ({ value, onChange, ...others }: InputNumberProps) => {
  const [val, setValue] = useState(value);

  useEffect(() => {
    setValue(value);
  }, [value]);

  const handleChangePrice = (_val: any) => {
    setValue(_val);
    return onChange?.(_val);
  };
  return (
    <MoneyInputStyled
      data-testid='money-input'
      min={0}
      formatter={formatterMoney}
      onChange={handleChangePrice}
      value={val}
      parser={parserMoney}
      {...others}
    />
  );
};

export default MoneyInput;
