class AbortableFunction<T> {
    private _callback: ((params?: any) => T) | ((params?: any) => Promise<T>);
    private _controller: AbortController;

    constructor(callback: ((params?: any) => T) | ((params?: any) => Promise<T>)) {
        this._controller = new AbortController();
        this._callback = callback;
    }

    get isAborted(): boolean {
        return this._controller.signal.aborted;
    }

    async execute(params?: any): Promise<T> {
        const execution = new Promise<T>(async (resolve, reject) => {
            const abortedMessage = 'Function aborted';

            if (this._controller.signal.aborted) {
                reject(abortedMessage);
            }

            this._controller.signal.addEventListener('abort', () => {
                reject(abortedMessage);
            });

            try {
                const callbackValue = await this._callback(params);
                resolve(callbackValue);
            } catch (e) {
                reject(e);
            }
        });
        const res = await execution;
        return res;
    }

    abort(): void {
        this._controller.abort();
    }
}

export default AbortableFunction;
