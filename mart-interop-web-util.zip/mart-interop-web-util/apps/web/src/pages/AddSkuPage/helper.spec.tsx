import { prepareFormData, prepareUpdateData } from './helpers';
import { data, categories, fakeProduct, brands, countries } from './mockData';

describe('prepareUpdateData', () => {
  it('should return data', () => {
    expect(prepareUpdateData(data, categories)).toBeTruthy();
    expect(prepareUpdateData({ ...data, category: { value: 0, label: 'test' } }, categories)).toBeTruthy();
  });
});
describe('prepareUpdateData', () => {
  it('should return data', () => {
    expect(prepareFormData(fakeProduct, categories, brands, countries)).toBeTruthy();
    expect(
      prepareFormData(fakeProduct, [{ ...categories[0], id: 2 }], [{ ...brands[0], id: 2 }], [{ ...countries[0], id: 2 }])
    ).toBeTruthy();
  });
});
