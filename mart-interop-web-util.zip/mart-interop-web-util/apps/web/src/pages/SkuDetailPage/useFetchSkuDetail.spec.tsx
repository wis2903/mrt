import { renderWithProvider } from 'test';
import { useFetchSkuDetail } from './useFetchSkuDetail';
jest.mock('react', () => ({
  ...jest.requireActual('react'),
  useParams: jest.fn().mockImplementation(() => ({})),
}));
describe('useAsync', () => {
  it('should return', async () => {
    const Component = () => {
      const result = useFetchSkuDetail();
      return null;
    };
    const { container } = renderWithProvider(<Component />);
    expect(container).toBeTruthy();
  });
});
