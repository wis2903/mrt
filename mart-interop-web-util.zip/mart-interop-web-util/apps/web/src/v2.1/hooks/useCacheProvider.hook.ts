import React from 'react';
import { CacheProviderContext } from 'v2.1/providers/cache';
import { ICacheProviderContext } from 'v2.1/providers/cache/type';

export const useCacheProvider = (): ICacheProviderContext => {
    return React.useContext(CacheProviderContext);
};
