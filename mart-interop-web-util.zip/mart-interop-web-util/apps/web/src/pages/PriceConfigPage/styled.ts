import { Table } from 'antd';
import styled from 'styled-components';

export const ProvinceItemStyled = styled.div`
  .ant-form-item {
    margin-bottom: 0;
  }

  border-bottom: 1px dashed #ddd;
  margin-bottom: 32px;
`;

export const TableNoBorder = styled(Table)`
  width: 100%;
  margin-top: 8px;

  .ant-table-thead > tr > th {
    background: none;
    border-bottom: none;
    padding-bottom: 0;

    &:before {
      background-color: none;
    }
  }
  .ant-table-tbody > tr > td {
    border: none;
  }
`;

export const ProvincePriceStyled = styled.div`
  display: flex;
  align-items: center;

  .price-input {
    margin-right: 16px;
  }
  .ant-input-number {
    width: auto;
  }
`;

export const SKUEnableWrapper = styled.div`
  .ant-form-item-label {
    width: 50%;
  }
`;

export type ProvinceSelectStyledType = {
  readOnly?: boolean;
};
export const ProvinceSelectStyled = styled('div')<ProvinceSelectStyledType>`
  ${(props) => props.readOnly && `pointer-events: none;`}
`;
