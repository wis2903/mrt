export enum PromotionStatusEnum {
    active = 1,
    inactive = 2,
    expired = 3,
}

export enum PromotionTypeEnum {
    Coupon = 9,
    ComboFlat = 8,
    ComboPercentage = 7,
    ComboItemFlat = 6,
    ComboItemPercent = 5,
    MoqItemFlat = 4,
    MoqItemPercentage = 2,
    CartAmountFlat = 3,
    CartAmountPercentage = 1,
    MovSkuDiscountAmount = 12,
    MovSkuPercentage = 13,
    DynamicBundlingFlat = 14,
    GroupItemDiscountAmount = 15,
    GroupDiscountPercentage = 16,
    MovcataArchived = 18,
    DynamicBundlingItemFlat = 20,
    GroupDiscountV2 = 21,
}

export enum PromotionCategoryEnum {
    combo = 'combo',
    order = 'order',
    moq = 'moq',
    coupon = 'coupon',
    movsku = 'movsku',
    comd = 'comd',
    comdItems = 'comdItems',
    group = 'group',
    groupV2 = 'groupV2',
    movcataArchived = 'movcata-archived',
}

export enum PromotionDiscountTypeEnum {
    setDiscountPercent = 'set-percent',
    setPriceAfterDiscount = 'set-price',
    setDiscountAmount = 'set-discount-amount',
}

export enum PromotionValidationEnum {
    ok = 'ok',
    error = 'error',
    hasConflict = 'has-conflict',
}

export enum ValidationRuleEnum {
    required = 'required',
    min = 'min',
    max = 'max',
    greaterThan = 'greaterThan',
    maxChars = 'maxChars',
    maxCharsWithoutHTMLTags = 'maxCharsWithoutHTMLTags',
    url = 'url',
    cxUrl = 'cxUrl',
    futureDate = 'futureDate',
}

export enum LangEnum {
    en = 'en',
    vi = 'vi',
}

export enum AmastUomEnum {
    ct = 'CT',
    un = 'UN',
    pk = 'PK',
    stk = 'STK',
    bg = 'BG',
    pc = 'PC',
    gm = 'GM',
    ea = 'EA',
}

export enum WeekDayEnEnum {
    'sunday' = 'common.datepicker.weekday.sun',
    'monday' = 'common.datepicker.weekday.mon',
    'tuesday' = 'common.datepicker.weekday.tue',
    'wednesday' = 'common.datepicker.weekday.wed',
    'thursday' = 'common.datepicker.weekday.thu',
    'friday' = 'common.datepicker.weekday.fri',
    'saturday' = 'common.datepicker.weekday.sat',
}

export enum MonthEnEnum {
    'january' = 'common.datepicker.month.jan',
    'february' = 'common.datepicker.month.feb',
    'march' = 'common.datepicker.month.mar',
    'april' = 'common.datepicker.month.apr',
    'may' = 'common.datepicker.month.may',
    'june' = 'common.datepicker.month.jun',
    'july' = 'common.datepicker.month.jul',
    'august' = 'common.datepicker.month.aug',
    'september' = 'common.datepicker.month.sep',
    'october' = 'common.datepicker.month.oct',
    'november' = 'common.datepicker.month.nov',
    'december' = 'common.datepicker.month.dec',
    'jan' = 'common.datepicker.monthShort.jan',
    'feb' = 'common.datepicker.monthShort.feb',
    'mar' = 'common.datepicker.monthShort.mar',
    'apr' = 'common.datepicker.monthShort.apr',
    'may-s' = 'common.datepicker.monthShort.may',
    'jun' = 'common.datepicker.monthShort.jun',
    'jul' = 'common.datepicker.monthShort.jul',
    'aug' = 'common.datepicker.monthShort.aug',
    'sep' = 'common.datepicker.monthShort.sep',
    'oct' = 'common.datepicker.monthShort.oct',
    'nov' = 'common.datepicker.monthShort.nov',
    'dec' = 'common.datepicker.monthShort.dec',
}

export enum ReportTypeEnum {
    sku = 'sku',
    inventory = 'inventory',
    order = 'order',
}

export enum LogSyncStatusEnum {
    successful = 'SUCCESSFUL',
    failed = 'FAILED',
}

export enum NotificationStatusEnum {
    all = 'all',
    scheduled = 'scheduled',
    sent = 'sent',
    cancelled = 'cancelled',
}

export enum CountryCodeEnum {
    vn = 'VN',
    my = 'MY',
}

export enum NotificationTypeEnum {
    promotion = 'Promotion',
    cashback = 'Cashback',
    announcement = 'Announcement',
}

export enum NotificationCampaignStatusEnum {
    all = 'All',
    sent = 'Sent',
    scheduled = 'Scheduled',
}

export enum OrderStatusEnum {
    created = 'CREATED',
    placed = 'PLACED',
    processing = 'PROCESSING',
    delivery = 'DELIVERY',
    rescheduled = 'RESCHEDULED',
    completed = 'COMPLETED',
    canceled = 'CANCELED',
    pending = 'PENDING',
}

export enum OrderTypeEnum {
    presale = 'presale',
    promptsale = 'prompt_sale',
}

export enum AppliedLimitTypeEnum {
    limited = 'limited',
    unlimited = 'unlimited',
}

export enum SelfPickupEnum {
    all = -1,
    no = 0,
    discount = 1,
    standard = 2,
}

export enum ResponseCodeEnum {
    success = 200,
}

export enum SkuPriceOptionEnum {
    hasPrice = 1,
    noPrice = 2,
}

export enum UomStatusEnum {
    inactive = 'inactive',
    active = 'active',
    unknown = '',
}

export enum CommonActionEnum {
    update = 'update',
    create = 'create',
}

export enum ProductStatusEnum {
    inactive = 'inactive',
    active = 'active',
    unknown = '',
}

export enum SearchOrderByEnum {
    product = 'product',
    order = 'order',
    orderNumbers = 'order-numbers',
}

export enum POStatusEnum {
    order = 'order',
    confirm = 'confirm',
    delivery = 'delivery',
    check = 'check',
    load = 'load',
    close = 'close',
    cancel = 'cancel',
    return = 'return',
}

export enum SourceEnum {
    amast = 5,
    cx = 6,
}

export enum OrderCancellationRequestStatusEnum {
    init = 'init',
    requested = 'requested',
    done = 'done',
}
