import AbortableHttpRequest from 'v2.1/libs/abortable-http-request.lib';
import { STORAGE_KEY } from 'v2/app/constants/common.constant';

class AbortableHttpRequestWithConfigs extends AbortableHttpRequest {
    constructor() {
        super();
        const token = String(localStorage.getItem(STORAGE_KEY.token) || '');
        this.setBaseURL(String(process.env.VITE_MART_API_URL));
        this.setHeader('Content-Type', 'application/json;charset=UTF-8');
        this.setHeader('Authorization', token);
    }
}

export default AbortableHttpRequestWithConfigs;
