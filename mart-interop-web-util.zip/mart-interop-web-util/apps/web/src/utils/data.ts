import _ from 'lodash'

function mapper(value: any, transformCase: any) {
  return _.isObject(value) ? toAnyCase(value, transformCase) : value
}

export function toAnyCase(data: any, transformCase: any) {
  const mapValues = (value: any): any => mapper(value, transformCase)
  if (_.isArray(data)) {
    return data.map(mapValues)
  } else {
    return _.mapKeys(_.mapValues(data, mapValues), (value, key) => transformCase(key))
  }
}

export function toSnakeCase(data: any) {
  return toAnyCase(data, _.snakeCase)
}

export function toCamelCase(data: any) {
  return toAnyCase(data, _.camelCase)
}
