import React from 'react';
import { ControllerProviderContext } from 'v2.1/providers/controller';
import { IControllerProviderContext } from 'v2.1/providers/controller/type';

export const useControllerProvider = (): IControllerProviderContext => {
    return React.useContext(ControllerProviderContext);
};
