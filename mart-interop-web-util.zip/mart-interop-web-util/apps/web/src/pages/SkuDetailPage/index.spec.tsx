import { fireEvent, renderWithProvider, screen, waitFor } from 'test';
import Component from '.';
import userEvent from '@testing-library/user-event';
import { selectors as masterDataSelectors } from 'store/masterData/slice';

import * as slice from 'pages/AddSkuPage/slice';
import sinon from 'sinon';
import apiClient from 'apis/apiClient';
import * as reactRouter from 'react-router';
import { AbilityContext } from '../../casl/can';
import { useContext, useEffect } from 'react';
import { updateAbility } from '../../casl/ability';
import { mockUser } from '__mocks__/mockUser';
const mockFn = jest.fn().mockReturnValue({});
jest.mock('./useFetchSkuDetail.tsx', () => ({
  get useFetchSkuDetail() {
    return mockFn;
  }
}));

sinon.stub(apiClient, 'get').callsFake(
  () =>
    ({
      data: {}
    } as any)
);
sinon.stub(apiClient, 'post').callsFake(
  () =>
    ({
      data: {}
    } as any)
);
sinon.stub(apiClient, 'put').callsFake(
  () =>
    ({
      data: {}
    } as any)
);

jest.spyOn(reactRouter, 'useParams').mockReturnValue({ skuId: '1' });

describe('Render component', () => {
  it('should render without crash', () => {
    const { container } = renderWithProvider(<Component />);

    expect(container).toBeTruthy();
  });
});

describe('Actions', () => {
  beforeAll(() => {
    jest.spyOn(slice.selectors, 'selectLoading').mockReturnValue(false);
    jest
      .spyOn(masterDataSelectors, 'selectorCategoryListLevel2')
      .mockReturnValue([{ id: 44, code: 'test', name: 'test', parentId: 1, parentName: 'test' }]);
    jest
      .spyOn(masterDataSelectors, 'selectorCategoryListAllLevel')
      .mockReturnValue([{ id: 44, code: 'test', name: 'test', parentId: 1, parentName: 'test' }]);
    jest.spyOn(masterDataSelectors, 'selectorByKey').mockReturnValue(() => [
      { id: 1, code: 'VIETNAM', name: 'test', parentId: 1, parentName: 'test' },
      { id: 6, code: 'VIETNAM', name: 'test', parentId: 1, parentName: 'test' },
      { id: 66, code: 'VIETNAM', name: 'test', parentId: 1, parentName: 'test' }
    ]);
    jest.spyOn(masterDataSelectors, 'selectLoading').mockReturnValue(false);
  });
  it('should able to click save', async () => {
    const execute = jest.fn();
    mockFn.mockReturnValue({
      loading: false,
      error: null,
      skuDetail: {
        id: 1495,
        name: 'Nước xả vải Downy hương nước hoa huyền bí túi 3.5 lít',
        code: 'NJM001495',
        description: 'Nước xả vải Downy hương nước hoa huyền bí túi 3.5 lít',
        countryId: 6,
        tax: 8,
        categoryId: 5,
        categoryName: null,
        subcategoryId: 44,
        subcategoryName: null,
        brandId: 66,
        brandName: null,
        configurations: [
          {
            id: 1851,
            name: 'BAG',
            barcode: null,
            generatedName: 'Nước xả vải Downy hương nước hoa huyền bí túi 3.5 lít - Unit - 1',
            quantity: 1,
            grossWeight: null,
            netWeight: null,
            volume: null,
            isPrimary: true,
            imageUrls: ['https://storage.googleapis.com/gcs-devqc-bucket/ab2752b9-428a-4e1b-909f-7df506a9d8e8.jpg'],
            sellingPrices: [
              {
                id: 626,
                provinceId: '92',
                provinceName: 'Thành phố Cần Thơ',
                tax: null,
                grossPrice: 225000,
                netPrice: 208334,
                discountPrice: null,
                note: '225000',
                isActive: false,
                lastModifiedBy: 'anonymousUser',
                lastModifiedDate: '2022-10-10T07:22:11.584Z'
              }
            ]
          }
        ],
        sourceMappingList: [],
        numberUom: null,
        minGrossPrice: null,
        maxGrossPrice: null
      },
      execute
    });
    renderWithProvider(<Component />);
    fireEvent.change(screen.getByTestId('select-onChange'), { target: { value: 'edit' } });
    await waitFor(() => screen.getByText(/Save/));
    await userEvent.click(screen.getByText(/Save/));
    expect(execute).toBeCalled();
  });
  it('should able to click save', async () => {
    const execute = jest.fn();
    mockFn.mockReturnValue({
      loading: false,
      error: null,
      skuDetail: {
        id: 1495,
        name: 'Nước xả vải Downy hương nước hoa huyền bí túi 3.5 lít',
        code: 'NJM001495',
        description: 'Nước xả vải Downy hương nước hoa huyền bí túi 3.5 lít',
        countryId: 6,
        tax: 8,
        categoryId: 5,
        categoryName: null,
        subcategoryId: 44,
        subcategoryName: null,
        brandId: 66,
        brandName: null,
        configurations: [
          {
            id: 1851,
            name: 'BAG',
            barcode: null,
            generatedName: 'Nước xả vải Downy hương nước hoa huyền bí túi 3.5 lít - Unit - 1',
            quantity: 1,
            grossWeight: null,
            netWeight: null,
            volume: null,
            isPrimary: true,
            imageUrls: ['https://storage.googleapis.com/gcs-devqc-bucket/ab2752b9-428a-4e1b-909f-7df506a9d8e8.jpg']
          },
          {
            id: 1852,
            name: 'BAG',
            barcode: null,
            generatedName: 'Nước xả vải Downy hương nước hoa huyền bí túi 3.5 lít - Unit - 1',
            quantity: 1,
            grossWeight: null,
            netWeight: null,
            volume: null,
            isPrimary: true,
            imageUrls: ['https://storage.googleapis.com/gcs-devqc-bucket/ab2752b9-428a-4e1b-909f-7df506a9d8e8.jpg']
          }
        ],
        sourceMappingList: [],
        numberUom: null,
        minGrossPrice: null,
        maxGrossPrice: null
      },
      execute
    });
    const MockComponent = () => {
      const ability = useContext(AbilityContext);
      useEffect(() => {
        updateAbility(ability, mockUser);
      }, []);
      return <Component />;
    };
    renderWithProvider(<MockComponent />);
    fireEvent.change(screen.getByTestId('select-onChange'), { target: { value: 'edit' } });
    await waitFor(() => screen.getByText(/Save/));
    await userEvent.click(screen.getByText(/Save/));
    await userEvent.click(
      screen.getByRole('button', {
        name: /cancel/i
      })
    );
    await userEvent.click(screen.getByTestId('options-edit'));
    await userEvent.click(screen.getByTestId('options-view'));
    await userEvent.click(screen.getByTestId('options-delete'));
    await waitFor(() =>
      screen.getByRole('button', {
        name: /ok/i
      })
    );
    await userEvent.click(
      screen.getByRole('button', {
        name: /ok/i
      })
    );
  });
});
