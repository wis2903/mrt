import {
  createSku,
  deleteSku,
  exportSKUs,
  getSkuDetail,
  getSkuList,
  updateSku,
  updateSkuSellingPrice,
  updateSkuSource,
  validateBarcode
} from './sku'
import apiClient from './apiClient'

describe('SKU Apis', () => {
  it('Should update data', async () => {
    const data = {
      skuId: 'test',
      description: '',
      countryId: '',
      tax: 10,
      categoryId: '',
      subcategoryId: '',
      brandId: '',
      usageDays: 1,
      configurations: [],
      t: jest.fn()
    }
    const putSpy = jest.spyOn(apiClient, 'put')
    putSpy.mockReturnValueOnce(Promise.resolve({}))
    const result = await updateSku(data)
    expect(result).toEqual({})
  })
  it('Should updateSkuSellingPrice', async () => {
    const data = { skuId: 'test', sellingPrices: [], skuConfigurationId: 1 }
    const putSpy = jest.spyOn(apiClient, 'put')
    putSpy.mockReturnValueOnce(Promise.resolve({}))
    const result = await updateSkuSellingPrice(data)
    expect(result).toEqual({})
  })
  it('Should getSkuList', async () => {
    const data = { pageNumber: 1, pageSize: 2, t: jest.fn() }
    const putSpy = jest.spyOn(apiClient, 'post')
    putSpy.mockReturnValueOnce(Promise.resolve({}))
    const result = await getSkuList(data)
    expect(result).toEqual({})
  })
  it('Should createSku', async () => {
    const data = {
      name: 'string',
      description: 'string',
      countryId: 1,
      tax: 1,
      categoryId: 1,
      subcategoryId: 1,
      brandId: 1,
      usageDays: 1,
      configurations: []
    }
    const putSpy = jest.spyOn(apiClient, 'post')
    putSpy.mockReturnValueOnce(Promise.resolve({}))
    const result = await createSku(data)
    expect(result).toEqual({})
  })
  it('Should deleteSku', async () => {
    const data = {
      skuId: '1',
      t: jest.fn()
    }
    const putSpy = jest.spyOn(apiClient, 'delete')
    putSpy.mockReturnValueOnce(Promise.resolve({}))
    const result = await deleteSku(data)
    expect(result).toEqual({})
  })
  it('Should getSkuDetail', async () => {
    const data = {
      skuId: '1',
      t: jest.fn()
    }
    const putSpy = jest.spyOn(apiClient, 'get')
    putSpy.mockReturnValueOnce(Promise.resolve({}))
    const result = await getSkuDetail(data)
    expect(result).toEqual({})
  })
  it('Should updateSkuSource', async () => {
    const data = {
      skuId: '1',
      sourceList: []
    }
    const putSpy = jest.spyOn(apiClient, 'put')
    putSpy.mockReturnValueOnce(Promise.resolve({}))
    const result = await updateSkuSource(data)
    expect(result).toEqual({})
  })
  it('Should validateBarcode', async () => {
    const data = {
      skuId: 1,
      barcode: 'test'
    }
    const putSpy = jest.spyOn(apiClient, 'post')
    putSpy.mockReturnValueOnce(Promise.resolve({}))
    const result = await validateBarcode(data)
    expect(result).toEqual({})
  })
  it('Should exportSKUs', async () => {
    const putSpy = jest.spyOn(apiClient, 'get')
    putSpy.mockReturnValueOnce(Promise.resolve({}))
    const result = await exportSKUs()
    expect(result).toEqual({})
  })
})
