import { renderWithProvider } from 'test';
import Component from '.';

describe('Render component', () => {
  it('should render without crash', () => {
    const { container } = renderWithProvider(
      <Component>
        <div></div>
      </Component>
    );

    expect(container).toBeTruthy();
  });
});
