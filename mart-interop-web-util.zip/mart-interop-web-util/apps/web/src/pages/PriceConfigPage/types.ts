import { SellingPrice } from 'types/SKUDetail';

export type ProductDetailModel = {
  name: string;
  skuCode: string;
  tax: number;
};

export type ProvinceItemModel = {
  id: number | string;
  skus: Array<SKUItem>;
  provinceIds?: string[];
};

export type SKUItem = {
  id: number;
  key: string | number;
  uom: string;
  grossPrice?: number;
  numberItems: number; // the product's number in a SKU,  default = 1,
  isCarton?: boolean; // the SKU with max number item
} & Partial<SellingPrice>;
