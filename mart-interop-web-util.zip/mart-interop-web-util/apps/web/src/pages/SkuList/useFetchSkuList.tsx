import useLocales from 'hooks/useLocales';
import { isNumber, isUndefined } from 'lodash';
import { sliceName, reducer, saga, selectors, sagaActions } from 'pages/AddSkuPage/slice';
import { useEffect, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useAppDispatch, useAppSelector, useInjectReducer, useInjectSaga } from 'store/hooks';

export const useFetchSkuList = (pageNumber: number, pageSize: number) => {
  useInjectReducer({ key: sliceName, reducer });
  useInjectSaga({ key: sliceName, saga });
  const [searchParams] = useSearchParams();

  const { t } = useLocales();

  const dispatch = useAppDispatch();

  const loading = useAppSelector(selectors.selectLoading);
  const skuList = useAppSelector(selectors.selectSkuList);
  const total = useAppSelector(selectors.selectTotal);

  const search: any = useMemo(() => {
    const values: any = {
      bi: 1,
      tf: 1,
      tt: 1,
      s: '',
      ci: 1,
      sci: 1
    };
    const _values: any = Object.keys(values).reduce(
      (acc, key) =>
        searchParams.get(key)
          ? { ...acc, [key]: isNumber(values[key]) ? parseInt(searchParams.get(key) as any) : searchParams.get(key) }
          : acc,
      {}
    );
    return {
      brandId: _values.bi,
      totalFrom: _values.tf,
      totalTo: _values.tt,
      search: _values.s,
      categoryId: _values.ci,
      subCategoryId: _values.sci
    };
  }, [searchParams]);

  useEffect(() => {
    if (isUndefined(pageNumber)) return;
    dispatch(
      sagaActions.fetchSkuList({
        pageNumber,
        pageSize,
        search,
        t
      })
    );
  }, [dispatch, pageNumber, pageSize, search]);

  return { loading, skuList, total };
};
