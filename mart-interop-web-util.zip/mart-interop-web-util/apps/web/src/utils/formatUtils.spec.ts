import { formatUOMName, formatUOMNameForm } from './formatUtils';

describe('formatUOMName', () => {
  it('should return value', () => {
    expect(formatUOMName(0, 'name')).toEqual('Type 1 UOM name');
    expect(formatUOMNameForm('name', '3')).toEqual('name - Carton - 3');
  });
});
