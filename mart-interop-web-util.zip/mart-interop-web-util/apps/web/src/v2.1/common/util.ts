export function isPromise(p?: Object | Function) {
    if (!p) return false;
    return typeof p === 'object' && typeof Object(p).then === 'function';
}

export function upperCaseFirtLetter(str: string): string {
    if (!str) return '';
    return `${str.charAt(0).toUpperCase()}${str.substring(1)}`;
}

export function toCamelCase(str: string): string {
    if (!str) return '';

    const splitedStringByUnderscore = str.trim().split('_');
    let result = '';
    splitedStringByUnderscore.forEach((word, idx) => {
        if (idx) {
            result += upperCaseFirtLetter(word);
        } else {
            result += word;
        }
    });

    return result;
}

export function toSnakeCase(str: string): string {
    if (!str) return '';
    const splitedStringByUpperCaseLetter = str.trim().split(/\B(?=[A-Z])/);
    return splitedStringByUpperCaseLetter.map((word) => word.toLowerCase()).join('_');
}

export function toCaseTransformed(data: unknown, type: 'camelCase' | 'snakeCase'): unknown {
    if (typeof data !== 'object' || data === null) {
        return data;
    }

    if (Array.isArray(data)) {
        const _arr: unknown[] = [];
        data.forEach((item, idx) => {
            _arr[idx] = toCaseTransformed(item, type);
        });
        return _arr;
    }

    const _obj: Record<string, unknown> = {};
    const keys = Object.keys(data);

    keys.forEach((key) => {
        const value = Object(data)[key];
        if (type === 'camelCase') {
            _obj[toCamelCase(key)] = toCaseTransformed(value, type);
        } else {
            _obj[toSnakeCase(key)] = toCaseTransformed(value, type);
        }
    });

    return _obj;
}

export function isSingleElementChildren(children?: JSX.Element): boolean {
    if (!children) return false;
    if (Object(children.props).children) return false;
    return true;
}
