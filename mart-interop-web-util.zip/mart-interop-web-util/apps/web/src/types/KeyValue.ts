export default interface KeyValue {
  [key: string]: any;
}
