import { randomString } from '../../v2/app/helpers/utils.helper';

class ListItem<T> {
    private _instance: T;
    private _id: string;

    constructor(value: T) {
        this._instance = value;
        this._id = randomString(12);
    }

    get id(): string {
        return this._id;
    }

    get instance(): T {
        return this._instance;
    }

    update(value: T) {
        this._instance = value;
    }
}

class List<T> {
    private _items: ListItem<T>[];

    constructor(items?: ListItem<T>[]) {
        this._items = items || [];
    }

    loop(callback: (entry: ListItem<T>, idx: number) => void) {
        this._items.forEach((item, idx) => {
            callback(item, idx);
        });
    }

    add(item: ListItem<T>) {
        this._items.push(item);
    }

    remove(itemId: string): void {
        this._items = this._items.filter((item) => item.id === itemId);
    }

    clear(): void {
        this._items = [];
    }

    find(itemId: string): ListItem<T> | undefined {
        return this._items.find((item) => item.id === itemId);
    }
}

export default List;
export { ListItem };
