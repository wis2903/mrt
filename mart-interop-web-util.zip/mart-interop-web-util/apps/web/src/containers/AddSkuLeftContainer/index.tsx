import React from 'react';
import Input from 'components/Input';
import Select from 'components/Select';
import TextArea from 'components/TextArea';
import useLocales from 'hooks/useLocales';
import { Col, Form, Row, Typography } from 'antd';
import { MAX_LENGTH_TEXT_AREA } from 'constants/common';
import { AddSkuFormFields } from 'pages/AddSkuPage/const';
import { useAppSelector } from 'store/hooks';
import { selectors } from 'store/masterData/slice';
import { selectors as languageSelectors } from 'containers/LanguageProvider/slices';
import { NewBrandButton } from './styled';
import { FormInstance, useWatch } from 'antd/lib/form/Form';
import { AddSkuForm } from 'pages/AddSkuPage/types';
import BrandCreation from 'v2/app/pages/management/brand/create/create';
import { IOnDialogLoadedAPI } from 'v2/app/components/dialog/dialog';
import IconCollection from 'v2/app/components/icon/icon';
import { IBrand } from 'v2/app/@types/data.type';
import { LangEnum } from 'v2/app/@types/enum.type';

const { Option } = Select;
const { Title } = Typography;

export interface AddSkuLeftContainerProps {
    readOnly?: boolean;
    form: FormInstance<AddSkuForm>;
}

const AddSkuLeftContainer: React.FC<AddSkuLeftContainerProps> = ({
    readOnly,
    form,
}) => {
    const { t } = useLocales();
    const categoryList = useAppSelector(selectors.selectorCategoryListLevel2);
    const countryList = useAppSelector(selectors.selectorByKey('countryList'));
    const brand = useAppSelector(selectors.selectorByKey('brandList'));
    const lang = useAppSelector(languageSelectors.languageSelected);
    const activeCountry = useWatch(String(AddSkuFormFields.country));
    const brandSelectionRef = React.useRef(null);
    const brandCreationDialogApi = React.useRef<IOnDialogLoadedAPI | undefined>(
        undefined
    );

    const countryOptions: SelectOptions[] = countryList?.map((x) => ({
        value: x.id,
        label: x.name,
        code: x.code,
    }));

    const brandOptions: SelectOptions[] = brand
        ?.filter((x) => Object(x).countryId === activeCountry?.value)
        ?.map((x) => ({
            value: x.id,
            label: x.name,
        }));

    const handleOnSelectCountry = (): void => {
        form.setFieldValue(String(AddSkuFormFields.brand), undefined);
    };

    const handleOpenBrandCreationDialog = (): void => {
        const ref = brandSelectionRef.current as any;
        ref.focus();
        ref.blur();
        setTimeout(() => {
            brandCreationDialogApi.current?.requestOpenDialog();
        }, 500);
    };

    return (
        <>
            <Row>
                <Col span={6}>
                    <Title level={5}>{t('sku.productDetails')}</Title>
                </Col>
                <Col span={18}>
                    <Row>
                        <Col span={24}>
                            <Form.Item
                                name={AddSkuFormFields.name}
                                rules={[{ required: true }]}
                                label={t('sku.productName')}
                            >
                                <Input
                                    readOnly={readOnly}
                                    placeholder={t('Enter Product Name')}
                                />
                            </Form.Item>
                            <Form.Item
                                name={AddSkuFormFields.description}
                                rules={[{ required: true }]}
                                label={t('sku.description')}
                            >
                                <TextArea
                                    maxLength={MAX_LENGTH_TEXT_AREA}
                                    readOnly={readOnly}
                                    placeholder={t('Enter Description')}
                                />
                            </Form.Item>
                            <Form.Item
                                name={AddSkuFormFields.category}
                                rules={[{ required: true }]}
                                label={t('sku.category')}
                            >
                                <Select
                                    readOnly={readOnly}
                                    labelInValue
                                    showSearch
                                    optionFilterProp="children"
                                    placeholder={t(
                                        'Select (but able to type to search)'
                                    )}
                                    filterOption={(input, option) =>
                                        (option?.children as unknown as string)
                                            ?.toLowerCase()
                                            ?.includes(input?.toLowerCase())
                                    }
                                >
                                    {categoryList?.map((x) => (
                                        <Option key={x.id} value={x.id}>
                                            {`${x.name}`}
                                        </Option>
                                    ))}
                                </Select>
                            </Form.Item>
                            <Form.Item
                                name={AddSkuFormFields.country}
                                rules={[{ required: true }]}
                                label={t('sku.country')}
                            >
                                <Select
                                    readOnly={readOnly}
                                    labelInValue
                                    showSearch
                                    optionFilterProp="children"
                                    placeholder="Select (but able to type to search)"
                                    filterOption={(input, option) =>
                                        (option?.children as unknown as string)
                                            ?.toLowerCase()
                                            ?.includes(input?.toLowerCase())
                                    }
                                    onSelect={handleOnSelectCountry}
                                >
                                    {countryOptions?.map((x) => (
                                        <Option key={x.value} value={x.value}>
                                            {x.label}
                                        </Option>
                                    ))}
                                </Select>
                            </Form.Item>
                            <Form.Item
                                name={AddSkuFormFields.brand}
                                rules={[{ required: true }]}
                                label={t('sku.brand')}
                            >
                                <Select
                                    reference={brandSelectionRef}
                                    readOnly={readOnly}
                                    labelInValue
                                    showSearch
                                    optionFilterProp="children"
                                    placeholder={t(
                                        'Select (but able to type to search)'
                                    )}
                                    filterOption={(input, option) =>
                                        (option?.children as unknown as string)
                                            ?.toLowerCase()
                                            ?.includes(input?.toLowerCase())
                                    }
                                    dropdownRender={(menu) => (
                                        <>
                                            {menu}
                                            <NewBrandButton
                                                onClick={
                                                    handleOpenBrandCreationDialog
                                                }
                                            >
                                                <IconCollection.PlusPrimary />
                                                {t('New brand')}
                                            </NewBrandButton>
                                        </>
                                    )}
                                >
                                    {brandOptions?.map((x) => (
                                        <Option key={x.value} value={x.value}>
                                            {x.label}
                                        </Option>
                                    ))}
                                </Select>
                            </Form.Item>
                        </Col>
                    </Row>
                </Col>
            </Row>
            <BrandCreation
                lang={lang === 'vi' ? LangEnum.vi : LangEnum.en}
                specificCountry={
                    activeCountry
                        ? {
                              id: activeCountry.value,
                              code: activeCountry.code,
                              name: activeCountry.label,
                          }
                        : undefined
                }
                onLoaded={(api): void => {
                    brandCreationDialogApi.current = api;
                }}
                onSuccess={(newBrand: IBrand): void => {
                    form.setFieldValue(String(AddSkuFormFields.brand), {
                        disabled: undefined,
                        key: String(newBrand.id),
                        label: newBrand.name,
                        title: undefined,
                        value: Number(newBrand.id),
                    });
                }}
            />
        </>
    );
};

export default AddSkuLeftContainer;
