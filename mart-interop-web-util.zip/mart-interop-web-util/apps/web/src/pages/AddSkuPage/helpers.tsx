/* istanbul ignore file */
import { CreateSkuParams, UpdateSkuParams, SourceOptionsParams } from 'apis/sku'
import { COUNTRY_CODE } from 'constants/common'
import { keys } from 'lodash'
import { MasterDataItem } from 'types/MasterDataKey'
import SkuDetail from 'types/SKUDetail'
import { HINT_TEXT } from './const'
import { AddSkuForm, InitialValueSkuForm } from './types'

export const prepareSaveData = (data: AddSkuForm, categories: MasterDataItem[]): CreateSkuParams => {
  return {
    name: data.name,
    description: data.description,
    tax: data.tax,
    countryId: data.country?.value || '',
    brandId: data.brand?.value || '',
    usageDays: data.usageDays || '',
    subcategoryId: data.category?.value || '',
    categoryId: categories.find((category) => category.id === data.category?.value)?.parentId || '',
    configurations: data.skuConfigurations.map((skuConfiguration) => ({
      id: skuConfiguration.id,
      quantity: skuConfiguration.quantity,
      barcode: skuConfiguration.barcode || null,
      imageUrls: [skuConfiguration.image],
      isPrimary: !!skuConfiguration.isPrimary,
      name: skuConfiguration.name,
      generatedName: skuConfiguration.generatedName,
      grossWeight: skuConfiguration.grossWeight,
      netWeight: skuConfiguration.netWeight,
      volume: skuConfiguration.volume,
      amastSellable: true
    }))
  }
}

export const prepareUpdateData = (data: AddSkuForm, categories: MasterDataItem[]): Omit<UpdateSkuParams, 't'> => {
  return {
    skuId: data.skuId || '',
    name: data.name,
    description: data.description,
    tax: data.tax,
    countryId: data.country?.value || '',
    brandId: data.brand?.value || '',
    usageDays: data.usageDays || '',
    subcategoryId: data.category?.value || '',
    categoryId: categories.find((category) => category.id === data.category?.value)?.parentId || '',
    configurations: data.skuConfigurations?.map((skuConfiguration) => ({
      id: skuConfiguration.id,
      quantity: skuConfiguration.quantity,
      barcode: skuConfiguration.barcode,
      imageUrls: [skuConfiguration.image],
      isPrimary: !!skuConfiguration.isPrimary,
      name: skuConfiguration.name,
      generatedName: skuConfiguration.generatedName,
      grossWeight: skuConfiguration.grossWeight,
      netWeight: skuConfiguration.netWeight,
      volume: skuConfiguration.volume,
      amastSellable: skuConfiguration.amastSellable
    }))
  }
}

export const prepareUpdateSourceOptionsData = (data: AddSkuForm): SourceOptionsParams => {
  return {
    skuId: data.skuId || '',
    sourceList: keys(data.sources).filter((key: any) => data.sources?.[key])
  }
}

export const prepareFormData = (
  data: SkuDetail,
  categories: MasterDataItem[],
  brands: MasterDataItem[],
  countries: MasterDataItem[]
): InitialValueSkuForm => {
  const country = countries?.find((item) => item.id === data.countryId)
  const brand = brands?.find((item) => item.id === data.brandId)
  const category = categories?.find((item) => item.id === data.subcategoryId)
  const sources: any = data.sourceMappingList?.reduce((acc, item) => ({ ...acc, [item.sourceId]: item.isDisplay }), {})
  return {
    name: data.name,
    description: data.description,
    tax: data.tax,
    country: country ? { value: country.id, label: country.name } : undefined,
    brand: brand ? { value: brand.id, label: brand.name } : undefined,
    usageDays: data.usageDays,
    category: category ? { value: category.id, label: category.name } : undefined,
    code: data.code,
    skuConfigurations: data.configurations?.map((skuConfiguration) => ({
      id: skuConfiguration.id,
      quantity: skuConfiguration.quantity,
      barcode: skuConfiguration.barcode,
      image: skuConfiguration.imageUrls[0],
      isPrimary: !!skuConfiguration.isPrimary,
      name: skuConfiguration.name,
      generatedName: skuConfiguration.generatedName,
      grossWeight: skuConfiguration.grossWeight,
      netWeight: skuConfiguration.netWeight,
      volume: skuConfiguration.volume
    })),
    sources
  }
}

export const prepareAddSkuFormInitialValues = (countries: SelectOptions[]): DeepPartial<AddSkuForm> => {
  return {
    skuConfigurations: [],
    code: HINT_TEXT,
    country: countries?.find((country) => country.code === COUNTRY_CODE.VIETNAM)
  }
}
