import * as router from 'react-router-dom'
import Component from './Filters'
import userEvent from '@testing-library/user-event'
import { renderWithProvider, screen } from 'test'
import { PAGE_SIZE_OPTIONS } from 'constants/common'
import { InventoryFilter } from 'types/Inventory'

jest.unmock('antd')

const TestComponent = (): JSX.Element => {
  const initialFilters: InventoryFilter = { isGetAll: false, page: 1, size: PAGE_SIZE_OPTIONS[0] }
  return <Component initialValues={initialFilters} onChange={jest.fn()} />
}

describe('Inventory - Filters', () => {
  it('should render without crash', () => {
    const { container } = renderWithProvider(<TestComponent />)
    expect(container).toBeTruthy()
  })
  it('should handle when clicking Reset button', async () => {
    const mockSetSearchParams = jest.fn()
    const mockSearchParams = { set: jest.fn(), get: jest.fn() }
    const mockUseSearchParams = jest.spyOn(router, 'useSearchParams')
    mockUseSearchParams.mockReturnValueOnce([mockSearchParams as any, mockSetSearchParams])

    renderWithProvider(<TestComponent />)
    await userEvent.click(screen.getByTestId('reset-filter-button'))
    expect(mockSetSearchParams).toBeCalled()
  })
})
