import { AccountDetail } from '../page/account/detail';
import { BrandCreation } from '../page/brand/creation';
import { BrandDetail } from '../page/brand/detail';
import { BrandList } from '../page/brand/list';
import { CashbackMovement } from '../page/cashback-movement';
import { CommissionConfiguration } from '../page/commission/configuration';
import { CommissionList } from '../page/commission/list';
import { CustomerDetail } from '../page/customer/detail';
import { CustomerList } from '../page/customer/list';
import { Error } from '../page/error';
import { InventoryForecastList } from '../page/inventory-forecast';
import { LoyaltyServiceClone } from '../page/loyalty-service/clone';
import { LoyaltyServiceCreation } from '../page/loyalty-service/creation';
import { LoyaltyServiceDetail } from '../page/loyalty-service/detail';
import { LoyaltyServiceList } from '../page/loyalty-service/list';
import { MOVCATAClone } from '../page/movcata/clone';
import { MOVCATACreation } from '../page/movcata/creation';
import { MOVCATADetail } from '../page/movcata/detail';
import { MOVCATAList } from '../page/movcata/list';
import { OrderRoutingCreation } from '../page/order-routing/creation';
import { OrderRoutingDetail } from '../page/order-routing/detail';
import { OrderRoutingEdit } from '../page/order-routing/edit';
import { OrderRoutingList } from '../page/order-routing/list';
import { OrderList } from '../page/order/list';
import { ProductPoint } from '../page/product-point';
import { ProductList } from '../page/product/list';
import { PromoList } from '../page/promo/list';
import { PurchaseOrderCreation } from '../page/purchase-order/creation';
import { PurchaseOrderDetail } from '../page/purchase-order/detail';
import { PurchaseOrderList } from '../page/purchase-order/list';
import { SpinTheWheelReward } from '../page/spin-the-wheel-reward';
import { SupplierCreation } from '../page/supplier/creation';
import { SupplierDetail } from '../page/supplier/detail';
import { SupplierList } from '../page/supplier/list';
import { Util } from '../page/util';
import { fm } from '../provider/feature';
import { FeatureCodeEnum } from '../provider/feature/type';
import { IRoute } from './type';

export const ROUTE_PATH = {
    accountDetail: '/v-2.2.0/account',
    productList: '/v-2.2.0/product',
    productPointManagement: '/v-2.2.0/product-point',
    promoList: '/v-2.2.0/promo',
    movcataList: '/v-2.2.0/movcata',
    movcataCreation: '/v-2.2.0/movcata/create',
    movcataDetail: '/v-2.2.0/movcata/:code',
    movcataClone: '/v-2.2.0/movcata/clone/:code',
    orderList: '/v-2.2.0/order',
    purchaseOrderList: '/v-2.2.0/purchase-order',
    purchaseOrderCreation: '/v-2.2.0/purchase-order/create',
    purchaseOrderDetail: '/v-2.2.0/purchase-order/:id',
    inventoryForecastList: '/v-2.2.0/inventory-forecast',
    loyaltyServiceList: '/v-2.2.0/loyalty-service',
    loyaltyServiceCreation: '/v-2.2.0/loyalty-service/create',
    loyaltyServiceDetail: '/v-2.2.0/loyalty-service/:id',
    loyaltyServiceClone: '/v-2.2.0/loyalty-service/clone/:id',
    supplierList: '/v-2.2.0/supplier',
    supplierDetail: '/v-2.2.0/supplier/:id',
    supplierCreation: '/v-2.2.0/supplier/create',
    commissionList: '/v-2.2.0/commission',
    commissionConfiguration: '/v-2.2.0/commission/configuration',
    brandList: '/v-2.2.0/brand',
    brandCreation: '/v-2.2.0/brand/create',
    brandDetail: '/v-2.2.0/brand/:id',
    customerList: '/v-2.2.0/customer',
    customerDetail: '/v-2.2.0/customer/:id',
    customerDetailByAmastId: '/v-2.2.0/customer/dba/:countryCode/:amastId',
    cashbackMovement: '/v-2.2.0/cashback-movement',
    spinTheWheelReward: '/v-2.2.0/spin-the-wheel-reward',
    orderRoutingList: '/v-2.2.0/routing',
    orderRoutingCreation: '/v-2.2.0/routing/create',
    orderRoutingEdit: '/v-2.2.0/routing/edit/:id',
    orderRoutingDetail: '/v-2.2.0/routing/:id',
    forbidden: '/v-2.2.0/forbidden',
};

const ROUTE: { [key: string]: IRoute } = {
    product: {
        path: ROUTE_PATH.productList,
        name: 'general.module.product',
        hasSidebar: true,
        element: <ProductList />,
        children: [
            {
                path: '/n/products/market-price',
                element: <></>,
            },
        ],
    },
    promo: {
        path: ROUTE_PATH.promoList,
        name: 'general.module.promo',
        hasSidebar: true,
        element: <PromoList />,
        children: [
            {
                path: ROUTE_PATH.movcataList,
                name: 'MOVCATA',
                hasSidebar: true,
                element: <MOVCATAList />,
            },
            {
                path: ROUTE_PATH.movcataCreation,
                element: <MOVCATACreation />,
            },
            {
                path: ROUTE_PATH.movcataDetail,
                element: <MOVCATADetail />,
            },
            {
                path: ROUTE_PATH.movcataClone,
                element: <MOVCATAClone />,
            },
        ],
    },
    order: {
        name: 'general.module.order',
        hasSidebar: true,
        children: ((): IRoute[] => {
            let rs = [
                {
                    name: 'general.module.order-list',
                    path: ROUTE_PATH.orderList,
                    hasSidebar: true,
                    element: <OrderList />,
                },
                {
                    path: '/n/orders/:id',
                    element: <></>,
                },
            ];
            if (fm.enabled(FeatureCodeEnum.routingJob)) {
                rs = [
                    ...rs,
                    {
                        name: 'order-routing.label.routing-job',
                        path: ROUTE_PATH.orderRoutingList,
                        hasSidebar: true,
                        element: <OrderRoutingList />,
                    },
                    {
                        path: ROUTE_PATH.orderRoutingCreation,
                        element: <OrderRoutingCreation />,
                    },
                    {
                        path: ROUTE_PATH.orderRoutingEdit,
                        element: <OrderRoutingEdit />,
                    },
                    {
                        path: ROUTE_PATH.orderRoutingDetail,
                        element: <OrderRoutingDetail />,
                    },
                ];
            }
            return rs;
        })(),
    },
    loyaltyService: {
        name: 'general.module.loyalty-service',
        hasSidebar: true,
        children: ((): IRoute[] => {
            let rs: IRoute[] = [];

            if (fm.enabled(FeatureCodeEnum.loyaltyServiceProgram)) {
                rs = [
                    ...rs,
                    {
                        path: ROUTE_PATH.loyaltyServiceList,
                        name: 'loyalty-service.label.program',
                        hasSidebar: true,
                        element: <LoyaltyServiceList />,
                    },
                    {
                        path: ROUTE_PATH.loyaltyServiceCreation,
                        element: <LoyaltyServiceCreation />,
                    },
                    {
                        path: ROUTE_PATH.loyaltyServiceDetail,
                        element: <LoyaltyServiceDetail />,
                    },
                    {
                        path: ROUTE_PATH.loyaltyServiceClone,
                        element: <LoyaltyServiceClone />,
                    },
                ];
            }
            if (fm.enabled(FeatureCodeEnum.loyaltyServiceCashbackMovement)) {
                rs = [
                    ...rs,
                    {
                        path: ROUTE_PATH.cashbackMovement,
                        name: 'general.module.cashback-movement',
                        hasSidebar: true,
                        element: <CashbackMovement />,
                    },
                ];
            }
            rs.push({
                path: ROUTE_PATH.spinTheWheelReward,
                name: 'spin-the-wheel-reward.label.title',
                hasSidebar: true,
                element: <SpinTheWheelReward />,
            });
            return rs;
        })(),
    },
    purchaseOrder: {
        path: ROUTE_PATH.purchaseOrderList,
        name: 'general.module.purchase-order',
        hasSidebar: true,
        element: <PurchaseOrderList />,
        children: [
            {
                path: ROUTE_PATH.inventoryForecastList,
                name: 'general.module.inventory-forecast',
                hasSidebar: true,
                element: <InventoryForecastList />,
            },
            {
                path: ROUTE_PATH.purchaseOrderCreation,
                element: <PurchaseOrderCreation />,
            },
            {
                path: ROUTE_PATH.purchaseOrderDetail,
                element: <PurchaseOrderDetail />,
            },
        ],
    },
    configuration: {
        name: 'general.module.configuration',
        children: ((): IRoute[] => {
            let rs = [
                {
                    path: ROUTE_PATH.supplierList,
                    name: 'general.module.supplier',
                    hasSidebar: true,
                    element: <SupplierList />,
                },
                {
                    path: ROUTE_PATH.supplierCreation,
                    element: <SupplierCreation />,
                },
                {
                    path: ROUTE_PATH.supplierDetail,
                    element: <SupplierDetail />,
                },
            ];
            if (fm.enabled(FeatureCodeEnum.brand)) {
                rs = [
                    ...rs,
                    {
                        path: ROUTE_PATH.brandList,
                        name: 'general.label.brand',
                        hasSidebar: true,
                        element: <BrandList />,
                    },
                    {
                        path: ROUTE_PATH.brandCreation,
                        element: <BrandCreation />,
                    },
                    {
                        path: ROUTE_PATH.brandDetail,
                        element: <BrandDetail />,
                    },
                ];
            }
            return rs;
        })(),
    },
    account: {
        path: ROUTE_PATH.accountDetail,
        name: 'general.module.account',
        hasSidebar: true,
        element: <AccountDetail />,
    },
    salesManagment: {
        name: 'general.module.sales-management',
        element: <></>,
        children: [
            {
                path: ROUTE_PATH.commissionList,
                name: 'general.module.commission',
                hasSidebar: true,
                element: <CommissionList />,
            },
            {
                path: ROUTE_PATH.commissionConfiguration,
                element: <CommissionConfiguration />,
            },
            {
                path: ROUTE_PATH.productPointManagement,
                name: 'product-point.label.point-management',
                hasSidebar: true,
                element: <ProductPoint />,
            },
        ],
    },
    forbidden: {
        path: ROUTE_PATH.forbidden,
        element: <Error type="forbidden" />,
    },
};

if (fm.enabled(FeatureCodeEnum.customer)) {
    ROUTE.customerManagement = {
        name: 'customer.label.customer-management',
        path: ROUTE_PATH.customerList,
        hasSidebar: true,
        element: <CustomerList />,
        children: [
            {
                path: ROUTE_PATH.customerDetail,
                element: <CustomerDetail />,
            },
            {
                path: ROUTE_PATH.customerDetailByAmastId,
                element: <CustomerDetail byAmastId />,
            },
        ],
    };
}

if (fm.enabled(FeatureCodeEnum.util)) {
    ROUTE.util = {
        path: '/v-2.2.0/util',
        name: 'Util',
        element: <Util />,
    };
}

export { ROUTE };

