import useLocales from 'hooks/useLocales';
import React, { useState } from 'react';

import { CloseOutlined, LoadingOutlined, PlusOutlined } from '@ant-design/icons';
import { Upload, message } from 'antd';
import type { RcFile, UploadChangeParam, UploadFile, UploadProps } from 'antd/es/upload/interface';
import { apiClientV2 } from 'apis/apiClient';
import { FILE_V2, UPLOAD_PROMOTION_IMAGE } from 'apis/apiUrl';
import { AxiosInstance } from 'axios';
import { isFunction } from 'lodash';
import { NO_PHOTO_IMAGE_URL } from 'v2/app/constants/common.constant';
import { getObjectContentByKeyChain } from 'v2/kit/helpers/object.helper';
import { Container, DefaultImageButton, ImageUploaded } from './styled';

const getBase64 = (img: RcFile, callback: (url: string) => void) => {
    const reader = new FileReader();
    /* istanbul ignore next */
    reader.addEventListener('load', () => callback(reader.result as string));
    reader.readAsDataURL(img);
};

export interface UploadImageProps extends Omit<UploadProps, 'onChange'> {
    text?: string;
    value?: string;
    maxSizeInMB?: number;
    isEnableDefaultImageButton?: boolean;
    isHideLabel?: boolean;
    hasError?: boolean;
    service?: 'promotion' | 'mart-sp';
    onBeforeUpload?: (file: RcFile) => boolean;
    onChange?: (value: string, size?: number) => void;
    onLoadingStateChange?: (value: boolean) => void;
}

const UploadImage: React.FC<UploadImageProps> = ({
    text,
    value,
    maxSizeInMB = 10,
    isEnableDefaultImageButton,
    isHideLabel,
    hasError,
    service,
    onBeforeUpload,
    onChange,
    onLoadingStateChange,
    ...props
}: UploadImageProps) => {
    const [loading, setLoading] = useState(false);
    const fileSize = React.useRef<number>(0);
    const { t } = useLocales();
    const _text = text || (loading ? `${t('Processing')}` : t('Upload image'));
    const beforeUpload = (file: RcFile) => {
        if (onBeforeUpload) return onBeforeUpload(file);

        const isImage =
            file.type === 'image/jpg' || file.type === 'image/jpeg' || file.type === 'image/png';
        if (!isImage) {
            message.error(t('You can only upload JPG/JPEG/PNG file!'));
        }

        const fileSizeInMB = file.size / 1024 / 1024;
        const isLt2M = fileSizeInMB <= maxSizeInMB;
        fileSize.current = fileSizeInMB;
        if (!isLt2M) {
            message.error(t(`Image must be less than ${maxSizeInMB}MB!`));
        }
        return isImage && isLt2M;
    };

    const handleChange: UploadProps['onChange'] = (info: UploadChangeParam<UploadFile>) => {
        if (info.file.status === 'uploading') {
            setLoading(true);
            return;
        }
        if (info.file.status === 'done') {
            // Get this url from response in real world.
            /* istanbul ignore next */
            getBase64(info.file.originFileObj as RcFile, () => {
                setLoading(false);
            });
            isFunction(onChange) && onChange(info.file.response.data?.url, fileSize.current);
        }
        if (info.file.status === 'error') {
            setLoading(false);
            message.error(`${info.file.name} ${t('common.file upload failed.')}`);
        }
    };

    const handleRemove = (e: React.MouseEvent<HTMLSpanElement, MouseEvent>) => {
        e.stopPropagation();
        e.preventDefault();
        isFunction(onChange) && onChange('');
    };

    const uploadImage = async (options: any) => {
        const { onSuccess, onError, file } = options;
        const fmData = new FormData();
        const nameSplited = (file.name || 'default.jpg').split('.');
        const extension = nameSplited[nameSplited.length - 1];
        fmData.append('file', file, `image.${extension}`);
        let url: string = FILE_V2;
        let api: AxiosInstance = apiClientV2;
        let responseUrlKeyChain = 'data.data';
        switch (service) {
            case 'promotion':
                url = UPLOAD_PROMOTION_IMAGE;
                responseUrlKeyChain = 'data.data';
                break;
            default:
                break;
        }
        try {
            const res = await api.post(url, fmData, {
                headers: {
                    'content-type': 'multipart/form-data',
                },
            });
            const uploadedImageUrl = getObjectContentByKeyChain(Object(res), responseUrlKeyChain);
            onSuccess({
                data: {
                    url: uploadedImageUrl,
                },
            });
        } catch (err) {
            onError({ err });
        }
    };

    const handleOnUseDefaultImage = (): void => {
        onChange?.(NO_PHOTO_IMAGE_URL);
    };

    const uploadButton = (
        <div>
            {loading ? <LoadingOutlined /> : <PlusOutlined />}
            {!isHideLabel && <div style={{ marginTop: 8 }}>{_text}</div>}
        </div>
    );

    React.useEffect(() => {
        onLoadingStateChange?.(loading);
    }, [loading]);

    return (
        <Container hasError={hasError} isEnableDefaultImageButton={isEnableDefaultImageButton}>
            <Upload
                name="file"
                accept=".jpg,.jpeg,.png"
                listType="picture-card"
                className="avatar-uploader"
                showUploadList={false}
                customRequest={uploadImage}
                beforeUpload={beforeUpload}
                onChange={handleChange}
                {...props}
            >
                {value && !loading ? (
                    <ImageUploaded backgroundImage={value}>
                        {/* <img src={value} alt="avatar" style={{ width: '100%' }} /> */}
                        {!props.disabled && (
                            <CloseOutlined
                                data-testid="remove"
                                className="remove"
                                onClick={handleRemove}
                                // disabled={props.disabled}
                            />
                        )}
                    </ImageUploaded>
                ) : (
                    uploadButton
                )}
            </Upload>
            {isEnableDefaultImageButton && !value && !loading && !props.disabled && (
                <DefaultImageButton onClick={handleOnUseDefaultImage}>
                    {t('Use default img')}
                </DefaultImageButton>
            )}
        </Container>
    );
};

export default UploadImage;
