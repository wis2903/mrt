type OptionItem = {
  value: string;
  label: string;
};

export default OptionItem;
