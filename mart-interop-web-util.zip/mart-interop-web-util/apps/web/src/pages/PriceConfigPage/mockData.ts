import SkuDetail from 'types/SKUDetail';
import { ProvinceItemModel } from './types';

export const fakeBlocks: ProvinceItemModel[] = [
  {
    id: 1,
    provinceIds: ['34'],
    skus: [
      {
        id: 1,
        key: '1',
        uom: '1 chai',
        grossPrice: 22110,
        numberItems: 1
      },
      {
        id: 2,
        key: '2',
        uom: '1 lốc',
        grossPrice: 120121,
        numberItems: 6 // 1 lốc 6 chai
      },
      {
        id: 3,
        key: '3',
        uom: '1 thùng',
        grossPrice: 480121,
        numberItems: 24, // 1 thùng 24 chai,
        isCarton: true
      }
    ]
  },
  {
    id: 2,
    provinceIds: ['35'],
    skus: [
      {
        id: 1,
        key: '1',
        uom: '1 chai',
        grossPrice: 22110,
        numberItems: 1
      },
      {
        id: 2,
        key: '2',
        uom: '1 lốc',
        grossPrice: 120121,
        numberItems: 6 // 1 lốc 6 chai
      },
      {
        id: 3,
        key: '3',
        uom: '1 thùng',
        grossPrice: 480121,
        numberItems: 24, // 1 thùng 24 chai,
        isCarton: true
      }
    ]
  }
];

export const initialBlock = [
  {
    id: 1,
    skus: [
      {
        key: '1',
        uom: '1 gói',
        numberItems: 1
      },
      {
        key: '2',
        uom: '1 lốc',
        numberItems: 12
      },
      {
        key: '3',
        uom: '1 thùng',
        numberItems: 24, // 1 thùng 24 chai,
        isCarton: true
      }
    ]
  }
];

export const fakeProduct: SkuDetail = {
  id: 1106,
  name: 'Bia 3333',
  code: 'NJM001107',
  description: 'Lon - Lốc - Thùng',
  countryId: 6,
  tax: 10.0,
  categoryId: 3,
  subcategoryId: 10,
  brandId: 152,
  usageDays: 10,
  sourceMappingList: [{ sourceId: 1, isDisplay: true, skuId: 1106, id: 1 }],
  configurations: [
    {
      id: 32,
      name: 'Lon',
      generatedName: 'Lon',
      quantity: 1,
      grossWeight: 100.0,
      netWeight: 101.0,
      volume: 102,
      isPrimary: false,
      imageUrls: ['https://storage.googleapis.com/gcs-devqc-bucket/fa181a3f-b468-4611-8ca2-661b62cfd314.png'],
      sellingPrices: [
        {
          provinceId: 34,
          tax: 1,
          grossPrice: 120000,
          netPrice: 115000,
          discountPrice: 5000,
          id: 1,
          isActive: true,
          note: 'abc',
          lastModifiedBy: '1/1/2021',
          lastModifiedDate: '1/1/2021',
          newPrice: 123456
        },
        {
          provinceId: 35,
          tax: 1,
          grossPrice: 130000,
          netPrice: 116000,
          discountPrice: 6000,
          id: 2,
          isActive: true,
          note: 'abc',
          lastModifiedBy: '1/1/2021',
          lastModifiedDate: '1/1/2021',
          newPrice: 123456
        },
        {
          provinceId: 36,
          tax: 1,
          grossPrice: 120000,
          netPrice: 115000,
          discountPrice: 5000,
          id: 3,
          isActive: true,
          note: 'abc',
          lastModifiedBy: '1/1/2021',
          lastModifiedDate: '1/1/2021',
          newPrice: 123456
        }
      ]
    },
    {
      id: 33,
      name: 'Lốc',
      generatedName: 'Lốc',
      quantity: 6,
      grossWeight: undefined,
      netWeight: undefined,
      volume: undefined,
      isPrimary: true,
      imageUrls: ['https://storage.googleapis.com/gcs-devqc-bucket/cafa36a6-f03a-4eed-9d09-26177ce14e3c.jpg'],
      sellingPrices: [
        {
          provinceId: 34,
          tax: 1,
          grossPrice: 220000,
          netPrice: 215000,
          discountPrice: 10000,
          id: 4,
          isActive: true,
          note: 'abc',
          lastModifiedBy: '1/1/2021',
          lastModifiedDate: '1/1/2021',
          newPrice: 123456
        },
        {
          provinceId: 35,
          tax: 1,
          grossPrice: 230000,
          netPrice: 216000,
          discountPrice: 12000,
          id: 5,
          isActive: true,
          note: 'abc',
          lastModifiedBy: '1/1/2021',
          lastModifiedDate: '1/1/2021',
          newPrice: 123456
        },
        {
          provinceId: 36,
          tax: 1,
          grossPrice: 220000,
          netPrice: 215000,
          discountPrice: 10000,
          id: 6,
          isActive: true,
          note: 'abc',
          lastModifiedBy: '1/1/2021',
          lastModifiedDate: '1/1/2021',
          newPrice: 123456
        }
      ]
    },
    {
      id: 34,
      name: 'Thùng',
      generatedName: 'Thùng',
      quantity: 24,
      grossWeight: 300.0,
      netWeight: 301.0,
      volume: 302,
      isPrimary: false,
      imageUrls: ['https://storage.googleapis.com/gcs-devqc-bucket/403426f3-0860-4484-ad7e-3dbe10962d1d.jpg'],
      sellingPrices: [
        {
          provinceId: 34,
          tax: 1,
          grossPrice: 1220000,
          netPrice: 1215000,
          discountPrice: 110000,
          id: 1,
          isActive: true,
          note: 'abc',
          lastModifiedBy: '1/1/2021',
          lastModifiedDate: '1/1/2021',
          newPrice: 123456
        },
        {
          provinceId: 35,
          tax: 1,
          grossPrice: 1230000,
          netPrice: 1216000,
          discountPrice: 112000,
          id: 2,
          isActive: true,
          note: 'abc',
          lastModifiedBy: '1/1/2021',
          lastModifiedDate: '1/1/2021',
          newPrice: 123456
        },
        {
          provinceId: 36,
          tax: 1,
          grossPrice: 1220000,
          netPrice: 1215000,
          discountPrice: 110000,
          id: 3,
          isActive: true,
          note: 'abc',
          lastModifiedBy: '1/1/2021',
          lastModifiedDate: '1/1/2021',
          newPrice: 123456
        }
      ]
    }
  ]
};
