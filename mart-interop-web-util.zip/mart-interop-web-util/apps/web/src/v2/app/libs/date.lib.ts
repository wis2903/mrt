class DateL {
    static get beginOfToday(): Date {
        const dt = new Date();
        dt.setHours(0, 0, 0, 0);
        return dt;
    }

    static get currentDateTime(): Date {
        return new Date();
    }

    static get timestamp(): number {
        return +new Date();
    }
}

export default DateL;
