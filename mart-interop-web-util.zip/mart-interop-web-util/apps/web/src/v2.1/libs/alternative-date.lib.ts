class AlternativeDate {
    private _instance: Date;

    constructor(value?: Date) {
        this._instance = value || new Date();
    }

    public get today(): AlternativeDate {
        return new AlternativeDate(new Date());
    }

    public toDate(): Date {
        return this._instance;
    }

    public toTimestamp(): number {
        return this._instance.valueOf();
    }

    public toUnixTimestamp(): number {
        return Math.round(this.toTimestamp() / 1000);
    }

    public get endOfTheDay(): AlternativeDate {
        const dt = new Date(this._instance);
        dt.setHours(23, 59, 59, 0);
        return new AlternativeDate(dt);
    }

    public get beginOfTheDay(): AlternativeDate {
        const dt = new Date(this._instance);
        dt.setHours(0, 0, 0, 0);
        return new AlternativeDate(dt);
    }

    public moveTo(numb: number, type: 'days'): AlternativeDate {
        this._instance.setDate(this._instance.getDate() + numb);
        return this;
    }

    public static fromUnixTimestamp(unixTimestamp: number): AlternativeDate {
        return new AlternativeDate(new Date(unixTimestamp * 1000));
    }
}

export default AlternativeDate;
