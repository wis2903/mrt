const Dropdown: React.FC<any> = ({ overlay }) => {
  return <>{overlay}</>;
};

export default Dropdown;
