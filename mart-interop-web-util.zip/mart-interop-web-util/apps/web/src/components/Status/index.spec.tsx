import { renderWithProvider } from 'test'
import { Status } from './index'

describe('Status Tag', () => {
  it('should render correctly', () => {
    const { container } = renderWithProvider(<Status syncStatus={'SUCCESSFUL'} isTag />)

    expect(container).toMatchSnapshot()

    const { container: container2 } = renderWithProvider(<Status syncStatus={'SUCCESSFUL'} isTag={false} />)
    expect(container2).toMatchSnapshot()
  })
})
