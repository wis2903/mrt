import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { createDeliveryOrder, getOrder } from 'apis/orders';
import { DEFAULT_PAGE_NUMBER, DEFAULT_PAGE_SIZE } from 'constants/common';
import { showNotification } from 'containers/NotificationContainer/Notification';
import { call, put } from 'redux-saga/effects';
import { createSliceSaga, SagaType } from 'redux-toolkit-saga';
import { AppState } from 'store/store';
import { ChangeOrderStatusParams, OrderDetail, OrderItem, OrderSearchForm } from 'types/Orders';
import { notification } from '__mocks__/antd';

// ---------------------------------------
const sliceName = 'orderDetails';

export interface OrderDetailsState {
  loading?: boolean;
  order?: OrderDetail;
  orderItems?: OrderItem[];
  total?: number;
  pageNumber: number;
  pageSize: number;
  search?: OrderSearchForm;
}

const initialState: OrderDetailsState = {
  pageNumber: DEFAULT_PAGE_NUMBER,
  pageSize: DEFAULT_PAGE_SIZE
};

// ---------------------------------------
const reducers = {
  changeLoading: (state: OrderDetailsState, action: PayloadAction<boolean>) => ({
    ...state,
    loading: action.payload
  }),
  fetchOrderSuccess: (state: OrderDetailsState, action: PayloadAction<any>) => ({
    ...state,
    order: action.payload
  }),
  changeSearch: (state: OrderDetailsState, action: PayloadAction<OrderSearchForm>) => {
    return {
      ...state,
      search: { ...state.search, ...action.payload },
      pageNumber: DEFAULT_PAGE_NUMBER,
      pageSize: DEFAULT_PAGE_SIZE
    };
  },
  changePageNumber: (state: OrderDetailsState, action: PayloadAction<number>) => {
    return {
      ...state,
      pageNumber: action.payload
    };
  },
  changePageSize: (state: OrderDetailsState, action: PayloadAction<number>) => {
    return {
      ...state,
      pageSize: action.payload
    };
  },
  removeStore: () => initialState
};

const sliceOption = {
  name: sliceName,
  initialState,
  reducers
};
const slice = createSlice(sliceOption);
const { reducer, actions: reducerActions } = slice;

// -----------------------------------------------------

const selectLoading = (state: AppState) => {
  const dataSelected = state[sliceName] as OrderDetailsState;
  return dataSelected?.loading;
};

const selectOrder = (state: AppState) => {
  const dataSelected = state[sliceName] as OrderDetailsState;
  return dataSelected?.order;
};

const selectOrderItems = (state: AppState) => {
  const dataSelected = state[sliceName] as OrderDetailsState;
  return dataSelected?.orderItems;
};

const selectTotal = (state: AppState) => {
  const dataSelected = state[sliceName] as OrderDetailsState;
  return dataSelected?.total;
};

const selectSearch = (state: AppState) => {
  const dataSelected = state[sliceName] as OrderDetailsState;
  return dataSelected?.search;
};

const selectPageNumber = (state: AppState) => {
  const dataSelected = state[sliceName] as OrderDetailsState;
  return dataSelected?.pageNumber;
};

const selectPageSize = (state: AppState) => {
  const dataSelected = state[sliceName] as OrderDetailsState;
  return dataSelected?.pageSize;
};

const selectors = {
  selectLoading,
  selectOrder,
  selectOrderItems,
  selectTotal,
  selectSearch,
  selectPageNumber,
  selectPageSize
};

// ---------------------------------------

const sagaOption = {
  name: sliceName,
  sagaType: SagaType.TakeLatest,
  caseSagas: {
    *fetchOrderDetail(action: PayloadAction<string>): any {
      try {
        yield put(slice.actions.changeLoading(true));
        const { data } = yield call(getOrder, action.payload);

        yield put(slice.actions.fetchOrderSuccess(data));
      } catch (e: any) {
        notification.error({
          message: `Failed`,
          description: e.response?.data?.title || `Failed to fetch Orders, please try again.`,
          placement: 'top'
        });
      } finally {
        yield put(slice.actions.changeLoading(false));
      }
    },
    *changeOrder(data: PayloadAction<ChangeOrderStatusParams>): any {
      const { id, action, callback, callbackFinally } = data.payload;
      try {
        yield put(slice.actions.changeLoading(true));
        yield call(createDeliveryOrder, { id, action });
        callback && callback();

        showNotification({
          type: 'success',
          message: 'orders.changeOrderSuccess'
        });
      } catch (e: any) {
        showNotification({
          type: 'error',
          message: e.response?.data?.title || 'orders.changeOrderFailed'
        });
      } finally {
        yield put(slice.actions.changeLoading(false));
        callbackFinally();
      }
    }
  }
};
const sliceSaga = createSliceSaga(sagaOption);
const { saga, actions: sagaActions } = sliceSaga;
// ---------------------------------------

export { initialState, sliceName, reducer, saga, reducerActions, sagaActions, sagaOption, selectors };
