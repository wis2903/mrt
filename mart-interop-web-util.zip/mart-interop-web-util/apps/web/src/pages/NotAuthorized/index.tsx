import { WarningOutlined } from '@ant-design/icons';
import { notification, Typography } from 'antd';
import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { HOME_URI } from 'routes/routes';
import useLocales from '../../hooks/useLocales';
import { NotAuthorizedStyled } from './styled';
import Button from 'components/Button'

const NotAuthorized = () => {
  const { t } = useLocales();
  useEffect(() => {
    notification.destroy();
  });
  return (
    <NotAuthorizedStyled>
      <WarningOutlined style={{ fontSize: 100 }} />
      <br />
      <Typography.Title level={2}>{t('common.You are not authorized')}</Typography.Title>
      <br />
      <Typography.Text>{t("common.It seems like you don't have permission to use this feature.")}</Typography.Text>
      <Typography.Text>{t('common.Please contact your administrator!')}</Typography.Text>
      <br />
      <Link to={HOME_URI}>
        <Button type='primary'>{t('common.Back to Home page')}</Button>
      </Link>
    </NotAuthorizedStyled>
  );
};

export default NotAuthorized;
