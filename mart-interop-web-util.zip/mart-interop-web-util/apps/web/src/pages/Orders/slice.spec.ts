import apiClient from 'apis/apiClient'
import sinon from 'sinon'
import store from 'store/store'
import { reducerActions, sagaActions, sagaOption } from './slice'

const stub = sinon.stub(apiClient, 'post')
const stubPut = sinon.stub(apiClient, 'put')
describe('sagaActions', () => {
  afterEach(() => {
    jest.clearAllMocks()
  })
  it('fetchOrders successfully', async () => {
    stub.callsFake(
      () =>
        ({
          data: {
            data: [
              {
                id: 1
              }
            ],
            totalElement: 12
          }
        } as any)
    )
    const spyAction = jest.spyOn(reducerActions, 'fetchOrdersSuccess')

    await store.runSaga(sagaOption.caseSagas.fetchOrders, { payload: { pageNumber: 1, pageSize: 20 } }).toPromise()
    expect(spyAction).toBeCalledWith({
      orders: [
        {
          id: 1
        }
      ],
      total: 12
    })
  })
  it('fetchOrders failed', async () => {
    stub.rejects()
    const spyAction = jest.spyOn(reducerActions, 'fetchOrdersSuccess')

    await store.runSaga(sagaOption.caseSagas.fetchOrders, { payload: { pageNumber: 1, pageSize: 20 } }).toPromise()
    expect(spyAction).not.toBeCalled()
  })
})
