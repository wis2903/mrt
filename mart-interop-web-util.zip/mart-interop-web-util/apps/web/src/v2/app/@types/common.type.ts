import React from 'react';

import { AppV2ModuleEnum, AppV2Permission } from 'constants/ability';
import { SortDirectionEnum } from 'v2/kit/@types/sort.type';
import { ValidationRuleEnum } from './enum.type';

export type IVoidFunction = () => void;

export interface ITableSortData {
    column?: string;
    direction?: SortDirectionEnum;
}

export interface ITableColumn {
    title: React.ReactNode;
    key: string;
    isSortable?: boolean;
    align?: 'left' | 'right' | 'center';
    render: (record: Record<string, any>, idx: number) => React.ReactNode;
    headingClassName?: string;
    cellClassName?: string;
    zIndex?: number;
    isHighlight?: boolean;
    isHidden?: boolean;
}

export type FormFieldType =
    | 'text'
    | 'number'
    | 'code'
    | 'textarea'
    | 'datepicker'
    | 'single-select'
    | 'search-selection';

export interface IValidation {
    rule: ValidationRuleEnum;
    value?: number;
    message?: string;
}

export interface IAbility {
    module: AppV2ModuleEnum;
    permission: AppV2Permission;
}
