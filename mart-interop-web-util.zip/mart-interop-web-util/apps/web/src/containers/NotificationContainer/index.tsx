import get from 'lodash/get';
import isPlainObject from 'lodash/isPlainObject';
import isString from 'lodash/isString';
import transform from 'lodash/transform';
import { useEffect } from 'react';
import { useIntl } from 'react-intl';
import { shallowEqual, useDispatch, useSelector } from 'react-redux';
import { useInjectReducer } from 'store/hooks';
import showNotification from './Notification';
import { initialState, notificationActions, reducer, notificationSliceName } from './slice';

// Translate message keys in params object
// Ex { name: "company.info.name" } => { name: "Company info" }
const formatParamsMessage = (params: any, intl: any) => {
  if (!isPlainObject(params)) return {};

  return transform(params, (result: any, value, pKey) => {
    result[pKey] = intl.formatMessage({ id: value });
    return result;
  });
};

const formatMessage = (message: any, intl: any) => {
  let pFormatMessage;
  // Translate an array of message keys
  if (Array.isArray(message)) {
    pFormatMessage = message.map(
      (msgId) =>
        `${intl.formatMessage({
          id: msgId,
          defaultMessage: 'Message here.'
        })}\n`
    );
  }
  // Translate an message object with its param
  else if (isPlainObject(message) && isString(message.id)) {
    return intl.formatMessage({ id: message.id, defaultMessage: 'Message here' }, formatParamsMessage(message.params, intl));
  }
  // Translate a normal message key
  else if (isString(message)) {
    pFormatMessage = message;
  }
  return pFormatMessage;
};

export function NotificationContainer() {
  const intl = useIntl();
  useInjectReducer({
    key: notificationSliceName,
    reducer
  });

  const dispatch = useDispatch();
  const currentNotification = useSelector(
    (state) => get(state, [notificationSliceName, 'currentNotification'], initialState.currentNotification),
    shallowEqual
  );
  useEffect(() => {
    if (currentNotification && currentNotification.type && currentNotification.message) {
      showNotification({
        ...currentNotification,
        message: formatMessage(currentNotification.message, intl),
        onClose: () => {
          dispatch(notificationActions.removeNotification());
        }
      });
    }
  });

  return null;
}
