import CFile from './file.lib';
import { STORAGE_KEY } from '../constants/common.constant';
import { storageService } from '../services/storage.service';

class Stream {
    static download = async (url: string, filename: string): Promise<void> => {
        return new Promise((resolve, reject) => {
            fetch(`${process.env.VITE_PTC_API_URL}${url}`, {
                method: 'GET',
                headers: {
                    Authorization: `Bearer ${storageService.get(STORAGE_KEY.token)}`,
                },
            })
                .then((response: Response) => {
                    const reader = response?.body?.getReader();
                    return new ReadableStream({
                        start(controller) {
                            return pump();
                            function pump(): Promise<void> {
                                if (!reader) return new Promise((resolve) => resolve());
                                return reader.read().then(({ done, value }) => {
                                    if (done) {
                                        controller.close();
                                        return;
                                    }
                                    controller.enqueue(value);
                                    return pump();
                                });
                            }
                        },
                    });
                })
                .then((stream) => new Response(stream))
                .then((response) => response.blob())
                .then((blob) => {
                    CFile.saveFromBlob(blob, filename);
                    resolve();
                })
                .catch((e) => reject(e));
        });
    };
}

export default Stream;
