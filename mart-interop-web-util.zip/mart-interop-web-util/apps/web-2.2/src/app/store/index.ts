import { PandaObject } from '../../core/shared/lib/object';
import { IStoreState as ICoreStoreState } from '../../core/store/type';
import { ACCOUNT_INITIAL_STATE } from './account';
import { BRAND_FORM_INITIAL_STATE, BRAND_LIST_INITIAL_STATE } from './brand';
import { CASHBACK_MOVEMENT_INITIAL_STATE } from './cashback-movement';
import { COMMISSION_FORM_INITIAL_STATE, COMMISSION_LIST_INITIAL_STATE } from './commission';
import { CUSTOMER_FORM_INITIAL_STATE, CUSTOMER_LIST_INITIAL_STATE } from './customer';
import { INVENTORY_FORECAST_INITIAL_STATE } from './inventory-forecast';
import { MASTER_INITIAL_STATE } from './master';
import { MOVCATA_LIST_INITIAL_STATE } from './movcata';
import { ORDER_LIST_INITIAL_STATE, ORDER_UTIL_INITIAL_STATE } from './order';
import { PRODUCT_LIST_INITIAL_STATE } from './product';
import { PROMO_LIST_INITIAL_STATE } from './promo';
import { SPIN_THE_WHEEL_REWARD_INITIAL_STATE } from './spin-the-wheel-reward';
import { SUPPLIER_FORM_INITIAL_STATE, SUPPLIER_LIST_INITIAL_STATE } from './supplier';
import { UNTIL_INITIAL_STATE } from './util';

import {
    LOYALTY_SERVICE_FORM_INITIAL_STATE,
    LOYALTY_SERVICE_LIST_INITIAL_STATE,
} from './loyalty-service';

import {
    PURCHASE_ORDER_FORM_INITIAL_STATE,
    PURCHASE_ORDER_LIST_INITIAL_STATE,
} from './purchase-order';

import {
    PRODUCT_POINT_HISTORY_INITIAL_STATE,
    PRODUCT_POINT_SYNC_INITIAL_STATE,
} from './product-point';

import {
    ORDER_ROUTING_CREATION_INITIAL_STATE,
    ORDER_ROUTING_DETAIL_INITIAL_STATE,
    ORDER_ROUTING_LIST_INITIAL_STATE,
} from './order-routing';

export interface IStoreState extends ICoreStoreState {
    fetched: boolean;
    fetching: boolean;
    timestamp: number | undefined;
}

export const store: Record<string, unknown> = {
    account: PandaObject.deepCopy(ACCOUNT_INITIAL_STATE),
    master: PandaObject.deepCopy(MASTER_INITIAL_STATE),
    util: PandaObject.deepCopy(UNTIL_INITIAL_STATE),
    promo: {
        list: PandaObject.deepCopy(PROMO_LIST_INITIAL_STATE),
    },
    movcata: {
        list: PandaObject.deepCopy(MOVCATA_LIST_INITIAL_STATE),
    },
    loyaltyService: {
        list: PandaObject.deepCopy(LOYALTY_SERVICE_LIST_INITIAL_STATE),
        form: PandaObject.deepCopy(LOYALTY_SERVICE_FORM_INITIAL_STATE),
    },
    cashbackMovement: {
        list: PandaObject.deepCopy(CASHBACK_MOVEMENT_INITIAL_STATE),
    },
    order: {
        list: PandaObject.deepCopy(ORDER_LIST_INITIAL_STATE),
        util: PandaObject.deepCopy(ORDER_UTIL_INITIAL_STATE),
    },
    purchaseOrder: {
        list: PandaObject.deepCopy(PURCHASE_ORDER_LIST_INITIAL_STATE),
        form: PandaObject.deepCopy(PURCHASE_ORDER_FORM_INITIAL_STATE),
    },
    inventoryForecast: {
        list: PandaObject.deepCopy(INVENTORY_FORECAST_INITIAL_STATE),
    },
    supplier: {
        list: PandaObject.deepCopy(SUPPLIER_LIST_INITIAL_STATE),
        form: PandaObject.deepCopy(SUPPLIER_FORM_INITIAL_STATE),
    },
    brand: {
        list: PandaObject.deepCopy(BRAND_LIST_INITIAL_STATE),
        form: PandaObject.deepCopy(BRAND_FORM_INITIAL_STATE),
    },
    commission: {
        list: PandaObject.deepCopy(COMMISSION_LIST_INITIAL_STATE),
        form: PandaObject.deepCopy(COMMISSION_FORM_INITIAL_STATE),
    },
    productPoint: {
        history: PandaObject.deepCopy(PRODUCT_POINT_HISTORY_INITIAL_STATE),
        sync: PandaObject.deepCopy(PRODUCT_POINT_SYNC_INITIAL_STATE),
    },
    product: {
        list: PandaObject.deepCopy(PRODUCT_LIST_INITIAL_STATE),
    },
    customer: {
        list: PandaObject.deepCopy(CUSTOMER_LIST_INITIAL_STATE),
        form: PandaObject.deepCopy(CUSTOMER_FORM_INITIAL_STATE),
    },
    spinTheWheelReward: PandaObject.deepCopy(SPIN_THE_WHEEL_REWARD_INITIAL_STATE),
    orderRouting: {
        list: PandaObject.deepCopy(ORDER_ROUTING_LIST_INITIAL_STATE),
        detail: PandaObject.deepCopy(ORDER_ROUTING_DETAIL_INITIAL_STATE),
        creation: PandaObject.deepCopy(ORDER_ROUTING_CREATION_INITIAL_STATE),
    },
};
