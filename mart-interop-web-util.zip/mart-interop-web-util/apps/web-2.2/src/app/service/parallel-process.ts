/* eslint-disable no-loop-func */
import { BaseRequest } from '.';

interface IParallelProcessConstructor {
    requests: BaseRequest[];
    maximumThreads?: number;
    sequentially?: boolean;
    abortWhenErrorOccurred?: boolean;
}

export class ParallelProcess<T> {
    private _requests: BaseRequest[];
    private _maximumThreads: number;
    private _aborted: boolean;
    private _sequentially: boolean;
    private _abortWhenErrorOccurred: boolean;

    constructor({
        requests,
        maximumThreads,
        sequentially,
        abortWhenErrorOccurred,
    }: IParallelProcessConstructor) {
        this._requests = requests;
        this._maximumThreads = maximumThreads || 20;
        this._sequentially = Boolean(sequentially);
        this._abortWhenErrorOccurred = Boolean(abortWhenErrorOccurred);
        this._aborted = false;
    }

    get aborted(): boolean {
        return this._aborted;
    }

    async execute(progress?: (percentage: number) => void): Promise<T[]> {
        const queue = [...this._requests];
        let previousCompletedReqsCount = 0;
        let results: T[] = [];
        while (queue.length) {
            const reqs = queue.splice(0, this._maximumThreads);
            if (this._aborted) return results;
            const responses = await this._executeOneTime<T>(reqs, (completedReqsCnt) => {
                progress?.(
                    Math.ceil(
                        ((previousCompletedReqsCount + completedReqsCnt) * 100) /
                            this._requests.length
                    )
                );
            });
            previousCompletedReqsCount += reqs.length;
            results = results.concat(responses);
        }
        return results;
    }

    abort(): void {
        this._requests.forEach((item) => item.abort());
        this._aborted = true;
    }

    private _executeOneTime<T>(
        reqs: BaseRequest[],
        progress?: (completedReqsCount: number) => void
    ): Promise<T[]> {
        const responses: T[] = [];
        let processedReqsCount = 0;
        progress?.(0);
        if (!this._sequentially) {
            return new Promise((resolve) => {
                reqs.forEach((req, idx) => {
                    req.call().then((response) => {
                        progress?.(++processedReqsCount);
                        if (response) (response as Record<string, unknown>).request = req;
                        responses[idx] = response as T;
                        if (this._abortWhenErrorOccurred && Object(response).error) this.abort();
                        if (processedReqsCount === reqs.length) resolve(responses);
                    });
                });
            });
        }

        // eslint-disable-next-line no-async-promise-executor
        return new Promise(async (resolve) => {
            for (let idx = 0; idx < reqs.length; idx++) {
                const req = reqs[idx];
                const response = await req.call();
                progress?.(++processedReqsCount);
                if (response) (response as Record<string, unknown>).request = req;
                responses[idx] = response as T;
                if (this._abortWhenErrorOccurred && Object(response).error) this.abort();
                if (processedReqsCount === reqs.length) resolve(responses);
            }
        });
    }
}
