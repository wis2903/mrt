import { TagProps } from 'antd';

export interface LogStatusMasterData {
  code: string;
  name: string;
  color: TagProps['color'];
}

export const LOG_STATUS_MASTER_DATA: LogStatusMasterData[] = [
  {
    code: 'SUCCESSFUL',
    name: 'Successful',
    color: 'success'
  },
  {
    code: 'FAILED',
    name: 'Failed',
    color: 'magenta'
  }
];
