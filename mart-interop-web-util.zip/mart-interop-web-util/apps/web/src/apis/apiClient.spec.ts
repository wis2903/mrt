import { transform } from './apiClient'

describe('apiClient', () => {
  it('should transform request correctly', () => {
    const actual = transform({ nameCamel: 'test-name' })
    expect(actual).toEqual('{"name_camel":"test-name"}')
  })
})
