import ErrorIcon from './Error'
import { renderWithProvider } from '../../test'

describe('ErrorIcon component', () => {
  it('should render correctly', () => {
    const { container } = renderWithProvider(<ErrorIcon />)

    expect(container).toMatchSnapshot()

    const { container: containerWithProps } = renderWithProvider(<ErrorIcon width={16} height={16} />)

    expect(containerWithProps).toMatchSnapshot()
  })
})
