import { ICountry, IMasterData, IProvince } from './data.type';
import { LangEnum } from './enum.type';

export interface IAppContextUser {
    name: string
}

export interface IAppContext {
    isFetchedData?: boolean;
    isLoadingData: boolean;
    masterData: IMasterData;
    activeProvinces: IProvince[];
    activeCountries: ICountry[];
    selectedProvinceId: number;
    selectedCountryId: number;
    defaultCountryId: number;
    activeProvincesMatchSelectedCountryId: IProvince[];
    lang: LangEnum;
    cache: Record<string, any>;
    user: IAppContextUser;
    updateLang: (lang: LangEnum) => void;
    updateSelectedProvinceId: (id: number) => void;
    updateSelectedCountryId: (id: number) => void;
    updateCache: (data: Record<string, any>) => void;
    updateMasterData: (data: IMasterData) => void;
    updateActiveProvincesMatchSelectedCountryId: (data: IProvince[]) => void;
}
