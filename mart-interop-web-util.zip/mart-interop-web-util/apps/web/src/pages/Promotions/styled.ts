import styled from 'styled-components';
import { defaultTheme } from 'styles/defaultTheme.styles';

export const PromotionsStyled = styled.div`
  .justify-end {
    display: flex;
    justify-content: end;
    margin-bottom: ${defaultTheme.spacing.md};
  }
  .actions {
    width: 25px;
    height: 25px;
    border-radius: 6px;
    border: 1px solid ${defaultTheme.colors.BLACK};
    background: ${defaultTheme.colors.WHITE};
    display: flex;
    justify-content: center;
    align-items: center;
  }
`;
