import { InputNumber } from 'antd';
import styled from 'styled-components';

export const MoneyInputStyled = styled(InputNumber)`
  .ant-input-number-handler-wrap {
    display: none;
  }
`;
