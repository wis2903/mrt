import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { createDeliveryOrder, getOrders } from 'apis/orders';
import { DEFAULT_PAGE_NUMBER, DEFAULT_PAGE_SIZE } from 'constants/common';
import { showNotification } from 'containers/NotificationContainer/Notification';
import { call, put, select } from 'redux-saga/effects';
import { createSliceSaga, SagaType } from 'redux-toolkit-saga';
import { AppState } from 'store/store';
import { ChangeOrderStatusParams, GetOrdersParams, Order, OrderSearchForm } from 'types/Orders';

// ---------------------------------------
const sliceName = 'orders';

export interface OrdersState {
  loading?: boolean;
  orders?: Order[];
  total?: number;
  pageNumber: number;
  pageSize: number;
  search?: OrderSearchForm;
}

const initialState: OrdersState = {
  pageNumber: DEFAULT_PAGE_NUMBER,
  pageSize: DEFAULT_PAGE_SIZE
};

// ---------------------------------------
const reducers = {
  changeLoading: (state: OrdersState, action: PayloadAction<boolean>) => ({
    ...state,
    loading: action.payload
  }),
  fetchOrdersSuccess: (state: OrdersState, action: PayloadAction<any>) => ({
    ...state,
    orders: action.payload.orders,
    total: action.payload.total
  }),
  changeSearch: (state: OrdersState, action: PayloadAction<OrderSearchForm>) => {
    return {
      ...state,
      search: { ...state.search, ...action.payload },
      pageNumber: DEFAULT_PAGE_NUMBER,
      pageSize: DEFAULT_PAGE_SIZE
    };
  },
  changePageNumber: (state: OrdersState, action: PayloadAction<number>) => {
    return {
      ...state,
      pageNumber: action.payload
    };
  },
  changePageSize: (state: OrdersState, action: PayloadAction<number>) => {
    return {
      ...state,
      pageSize: action.payload
    };
  }
};

const sliceOption = {
  name: sliceName,
  initialState,
  reducers
};
const slice = createSlice(sliceOption);
const { reducer, actions: reducerActions } = slice;

// -----------------------------------------------------

const selectLoading = (state: AppState) => {
  const dataSelected = state[sliceName] as OrdersState;
  return dataSelected?.loading;
};

const selectOrders = (state: AppState) => {
  const dataSelected = state[sliceName] as OrdersState;
  return dataSelected?.orders;
};

const selectTotal = (state: AppState) => {
  const dataSelected = state[sliceName] as OrdersState;
  return dataSelected?.total;
};

const selectSearch = (state: AppState) => {
  const dataSelected = state[sliceName] as OrdersState;
  return dataSelected?.search;
};

const selectPageNumber = (state: AppState) => {
  const dataSelected = state[sliceName] as OrdersState;
  return dataSelected?.pageNumber;
};

const selectPageSize = (state: AppState) => {
  const dataSelected = state[sliceName] as OrdersState;
  return dataSelected?.pageSize;
};

const selectors = {
  selectLoading,
  selectOrders,
  selectTotal,
  selectSearch,
  selectPageNumber,
  selectPageSize
};

// ---------------------------------------

export const sagaOption = {
  name: sliceName,
  sagaType: SagaType.TakeLatest,
  caseSagas: {
    *fetchOrders(action: PayloadAction<GetOrdersParams>): any {
      try {
        yield put(slice.actions.changeLoading(true));

        const { data } = yield call(getOrders, action.payload);

        yield put(slice.actions.fetchOrdersSuccess({ orders: data.data, total: data.totalElement }));
      } catch (e: any) {
        showNotification({
          type: 'error',
          message: e.response?.data?.title || 'orders.failedToFetch'
        });
      } finally {
        yield put(slice.actions.changeLoading(false));
      }
    },
    *changeOrder(action: PayloadAction<ChangeOrderStatusParams>): any {
      try {
        yield put(slice.actions.changeLoading(true));
        yield call(createDeliveryOrder, action.payload);

        // reload the orders
        const orderState = yield select((state) => state[sliceName]);

        yield put(
          sliceSaga.actions.fetchOrders({
            pageNumber: orderState?.pageNumber,
            pageSize: orderState?.pageSize,
            search: orderState?.search
          })
        );

        showNotification({
          type: 'success',
          message: 'orders.changeOrderSuccess'
        });
      } catch (e: any) {
        showNotification({
          type: 'error',
          message: e.response?.data?.title || 'orders.changeOrderFailed'
        });
      } finally {
        yield put(slice.actions.changeLoading(false));
      }
    }
  }
};
const sliceSaga = createSliceSaga(sagaOption);
const { saga, actions: sagaActions } = sliceSaga;
// ---------------------------------------

export { initialState, sliceName, reducer, saga, reducerActions, sagaActions, selectors };
