import userEvent from '@testing-library/user-event';
import { renderWithProvider, screen } from 'test';
import Component from '.';

describe('Render component', () => {
  it('should render without crash', () => {
    const { container } = renderWithProvider(<Component />);

    expect(container).toBeTruthy();
  });

  it('should onChange', async () => {
    const onChange = jest.fn();
    const value = '111';
    renderWithProvider(<Component value={value} onChange={onChange} />);
    const moneyInput = screen.getByTestId('money-input');

    await userEvent.type(screen.getByTestId('money-input'), '2');
    expect(moneyInput.getAttribute('value')).toBe('1,112');
  });
});
