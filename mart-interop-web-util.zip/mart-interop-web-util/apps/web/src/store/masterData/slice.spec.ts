import { initialState, reducer, reducerActions, sagaOption, selectors, sliceName } from './slice';
import * as api from './apis';
import store from 'store/store';
import categoriesMock from './categoriesMock.json';
import { mockProvinces } from 'pages/PriceConfigPage/mockProvinces';
describe('reducerActions', () => {
  it('changeLoading', () => {
    expect(reducer(initialState, reducerActions.changeLoading(true))).toMatchObject({
      loading: true
    });
  });
  it('fetchDataSuccess', () => {
    expect(
      reducer(
        initialState,
        reducerActions.fetchDataSuccess({
          id: 'test'
        })
      )
    ).toMatchObject({
      masterData: {
        id: 'test'
      }
    });
  });
  it('fetchDistrictsSuccess', () => {
    expect(reducer(initialState, reducerActions.fetchDistrictsSuccess([]))).toMatchObject({
      districts: []
    });
  });
});

describe('selectors', () => {
  const state = {
    [sliceName]: {
      masterData: {
        provinceList: mockProvinces,
        categoryList: categoriesMock
      },
      districts: [],
      loading: true
    }
  };
  it('selectorByKey', () => {
    expect(selectors.selectorByKey('brandList')(state)).toEqual([]);
  });
  it('selectLoading', () => {
    expect(selectors.selectLoading(state)).toEqual(true);
  });
  it('selectDistrict', () => {
    expect(selectors.selectDistrict(state)).toEqual([]);
  });
  it('selectorCategoryListLevel2', () => {
    expect(selectors.selectorCategoryListLevel2(state)).toBeTruthy();
  });
  it('selectorCategoryListAllLevel', () => {
    expect(selectors.selectorCategoryListAllLevel(state)).toBeTruthy();
  });
  it('selectorProvinceList', () => {
    expect(selectors.selectorProvinceList(state)).toBeTruthy();
  });
});

describe('sagaActions', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });
  it('fetchMasterData', async () => {
    const spyAction = jest.spyOn(reducerActions, 'fetchDataSuccess');
    const getMasterData = jest.spyOn(api, 'getMasterData');
    getMasterData.mockResolvedValueOnce({ data: {} } as any);
    await store.runSaga(sagaOption.caseSagas.fetchMasterData, { payload: {} }).toPromise();
    expect(spyAction).toBeCalledTimes(1);
  });
  it('fetchMasterData failed', async () => {
    const spyAction = jest.spyOn(reducerActions, 'fetchDataSuccess');
    const getMasterData = jest.spyOn(api, 'getMasterData');
    getMasterData.mockRejectedValueOnce({});
    await store.runSaga(sagaOption.caseSagas.fetchMasterData, { payload: {} }).toPromise();
    expect(spyAction).not.toBeCalled();
  });
  it('fetchDistricts', async () => {
    const spyAction = jest.spyOn(reducerActions, 'fetchDistrictsSuccess');
    const fetchDistricts = jest.spyOn(api, 'getDistrict');
    fetchDistricts.mockResolvedValueOnce({ data: {} } as any);
    await store.runSaga(sagaOption.caseSagas.fetchDistricts, { payload: {} }).toPromise();
    expect(spyAction).toBeCalledTimes(1);
  });
  it('fetchDistricts failed', async () => {
    const spyAction = jest.spyOn(reducerActions, 'fetchDistrictsSuccess');
    const fetchDistricts = jest.spyOn(api, 'getDistrict');
    fetchDistricts.mockRejectedValueOnce(Promise.resolve({} as any));
    await store.runSaga(sagaOption.caseSagas.fetchDistricts, { payload: {} }).toPromise();
    expect(spyAction).not.toBeCalled();
  });
});
