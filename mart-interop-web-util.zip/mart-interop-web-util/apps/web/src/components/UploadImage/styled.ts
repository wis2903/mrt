import styled from 'styled-components';
import { getGlobalDesignToken } from 'v2/kit/design-tokens';

export const ImageUploaded = styled.div<{ backgroundImage?: string }>`
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100%;
    background-position: center;
    background-size: cover;
    background-repeat: no-repeat;

    ${(props): string => {
        if (!props.backgroundImage) return '';
        return `
            background-image: url(${props.backgroundImage});
        `;
    }}

    &:hover img {
        opacity: 0.3;
    }

    .remove {
        position: absolute;
        padding: 4px;
        top: 4px;
        right: 4px;
        background-color: ${getGlobalDesignToken('color.grey-1')};
        border-radius: 2px;
        box-shadow: 0 0 4px rgba(0, 0, 0, 0.1);

        svg {
            width: 12px;
            height: 12px;
        }

        svg path {
            fill: #ffffff;
        }
    }
`;

export const Container = styled.div<{ hasError?: boolean; isEnableDefaultImageButton?: boolean }>`
    ${(props): string => {
        if (!props.hasError) return '';
        return `
          padding: 4px;
          border-radius: 2px;
          border: 1px solid ${getGlobalDesignToken('color.red-3')};
        `;
    }}

    ${(props): string => {
        if (!props.isEnableDefaultImageButton) return '';
        return `
            display: inline-flex;
            flex-direction: column;
            gap: 2px;
            position: relative;
        `;
    }}
`;

export const DefaultImageButton = styled.button`
    font-size: 11px;
    text-decoration: underline;
    color: ${getGlobalDesignToken('color.grey-2')};
    border-radius: 2px;
    padding: 0;
    font-weight: 500;
`;
