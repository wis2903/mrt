import React from 'react'
import cx from 'classnames'

type TagProps = {
  tagClassName?: string
  textClassName?: string
  borderClassName?: string
  children: React.ReactNode
}
const Tag: React.FC<TagProps> = ({
  tagClassName = 'bg-[#ffffff]',
  textClassName = 'text-[#4c4c4c]',
  borderClassName = 'border border-solid border-[#979797]',
  children
}) => {
  return (
    <div className={cx('inline-flex px-2 py-0.5 rounded', tagClassName, borderClassName)}>
      <span className={textClassName}>{children}</span>
    </div>
  )
}

export default Tag
