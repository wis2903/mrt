import React from 'react';

import { Outlet } from 'react-router-dom';
import { DialogProvider } from '../../core/component/dialog/provider';
import { FlexboxComponent } from '../../core/component/flexbox';
import { ScrollAreaComponent } from '../../core/component/scrollarea';
import { ToastProvider } from '../../core/component/toast';
import { token } from '../../core/foundation/token';
import { FlexboxDirectionEnum } from '../../core/shared/type';
import { link } from '../../core/store';
import { ILinkedComponentProps } from '../../core/store/type';
import { useI18nProvider } from '../provider/i18n';
import { PermissionProvider } from '../provider/permission';
import { LayoutFetcher } from './fetch';
import { Header } from './header';
import { StyledLayoutContainer } from './styled';
import { ILayoutProps } from './type';

export const Layout = link(
    (props: ILayoutProps & ILinkedComponentProps): JSX.Element => {
        const { store, isPrivate, hasSidebar, children, autoHeight } = props;
        const { lang } = useI18nProvider();

        const [ready, setReady] = React.useState<boolean>(hasSidebar || false);

        const content = (
            <>
                {!isPrivate || store.state.get('master.fetched') ? (
                    <PermissionProvider>{children || <Outlet />}</PermissionProvider>
                ) : (
                    <></>
                )}
            </>
        );

        React.useEffect(() => {
            let timeoutHandler: NodeJS.Timeout | undefined = undefined;

            if (!ready) {
                timeoutHandler = setTimeout(() => {
                    setReady(true);
                }, 200);
            }
            return (): void => {
                !!timeoutHandler && clearTimeout(timeoutHandler);
            };
        }, []);

        return (
            <StyledLayoutContainer
                direction={FlexboxDirectionEnum.column}
                id={token.get<string>('global.util.root.id')}
                className={token.get<string>('global.util.root.class')}
                minWidth="360px"
            >
                <ToastProvider lang={lang}>
                    <DialogProvider lang={lang}>
                        <LayoutFetcher {...props} />
                        {hasSidebar && <Header />}

                        {!ready ? (
                            <StyledLayoutContainer>
                                <FlexboxComponent width="100%" height="100vh" />
                            </StyledLayoutContainer>
                        ) : autoHeight ? (
                            content
                        ) : (
                            <ScrollAreaComponent
                                width="100%"
                                height={hasSidebar ? 'calc(100vh - 64px)' : '100vh'}
                            >
                                {content}
                            </ScrollAreaComponent>
                        )}
                    </DialogProvider>
                </ToastProvider>
            </StyledLayoutContainer>
        );
    },
    { watch: ['master.fetched'] }
);
