import { SKUConfigurationForm } from '../pages/AddSkuPage/types';
import { intl } from 'containers/LanguageProvider';
export const removeAccentsVietnamese = (str: string) => {
    if (!str) return '';
    return str
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/đ/g, 'd')
        .replace(/Đ/g, 'D');
};

export const includeText = (data: string = '', searchValue: string = '') => {
    return removeAccentsVietnamese(data)
        .toLowerCase()
        .includes(removeAccentsVietnamese(searchValue).toLowerCase());
};

export const validateSKUConfig = (skuConfig: SKUConfigurationForm[]) => {
    const primaryConfigs = skuConfig.filter((config) => config.isPrimary);
    if (skuConfig.length === 0) {
        return 'Please add at least one UOM.';
    }
    if (skuConfig.length > 1 && primaryConfigs.length === 0) {
        return 'Please indicate the primary UOM.';
    }
    if (primaryConfigs.length > 1) {
        return 'More than one primary UOM indicated. Please keep only one as the primary UOM.';
    }
    return '';
};

export function printHTML(name: string, text: string) {
    const originalTitle = document.title;
    const iframe: any = document.createElement('iframe');
    iframe.style.display = 'none';
    const html = `<head><title>${name}</title></head><body>${text}</body>`;
    document.body.appendChild(iframe);
    iframe.contentWindow.document.open();
    iframe.contentWindow.document.write(html);
    iframe.contentWindow.document.close();
    iframe.contentWindow.print();
    (function () {
        const beforePrint = function () {
            document.title = name;
        };
        const afterPrint = function () {
            document.title = originalTitle;
            document.body.removeChild(iframe);
        };

        if (iframe.contentWindow.matchMedia) {
            const mediaQueryList = iframe.contentWindow.matchMedia('print');
            mediaQueryList.addListener(function (mql: any) {
                if (mql.matches) {
                    beforePrint();
                } else {
                    afterPrint();
                }
            });
        }

        iframe.contentWindow.onbeforeprint = beforePrint;
        iframe.contentWindow.onafterprint = afterPrint;
    })();
    return true;
}

export const saveData = (function () {
    const a: any = document.createElement('a');
    document.body.appendChild(a);
    a.style = 'display: none';
    return function (data: any, fileName: string) {
        const blob = new Blob([data], { type: 'octet/stream' }),
            url = window.URL.createObjectURL?.(blob);
        a.href = url;
        a.download = fileName;
        a.click();
        return window.URL.revokeObjectURL?.(url);
    };
})();

export const t = (key: string) => key;

export const isEnableOrder =
    !process.env.VITE_ORDER_DISABLE || process.env.VITE_ORDER_DISABLE === 'false';
export const isEnableLog =
    !process.env.VITE_LOG_DISABLE || process.env.VITE_LOG_DISABLE === 'false';
export const isEnableReport =
    !process.env.VITE_REPORT_DISABLE || process.env.VITE_REPORT_DISABLE === 'false';
export const isEnablePrintOrder =
    !process.env.VITE_PRINT_ORDER_DISABLE || process.env.VITE_PRINT_ORDER_DISABLE === 'false';
export const isEnableLangSwitcher =
    !process.env.VITE_LANG_SWITCHER_DISABLE || process.env.VITE_LANG_SWITCHER_DISABLE === 'false';
export const isEnableInventoryActivityLog =
    !process.env.VITE_INVENTORY_ACTIVITY_LOG_DISABLE ||
    process.env.VITE_INVENTORY_ACTIVITY_LOG_DISABLE === 'false';

export const showTotalPaginationItemsAmount = (_total: number, range: Array<number>) =>
    intl.formatMessage(
        { id: 'common.message.showingFromTo' },
        {
            from: range[0].toString(),
            to: range[1].toString(),
            total: _total.toString(),
        }
    );

export const isEmptyValue = (value: any) => [undefined, null, ''].includes(value);

export const isDisabledExportByTimeRange = (): boolean => {
    // const currentTime = new Date();
    // return currentTime.getHours() >= 7 && currentTime.getHours() <= 19;
    return false;
};
