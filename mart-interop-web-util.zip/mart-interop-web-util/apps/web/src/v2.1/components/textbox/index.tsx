import { ITextboxComponentProperties } from './type';

const TextboxComponent = (properties: ITextboxComponentProperties): JSX.Element => {
    return <input {...properties} />;
};

TextboxComponent.displayName = 'TextboxComponent';
export { TextboxComponent };
