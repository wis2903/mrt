import MenuLeft from 'layouts/components/MenuLeft';
import Topbar from 'layouts/components/Topbar';
import React, { useEffect } from 'react';
import { Layout } from 'antd';
import { useDispatch } from 'react-redux';
import { Outlet } from 'react-router-dom';
import { sagaActions } from 'store/masterData/slice';
import { defaultTheme } from 'styles/defaultTheme.styles';
import { NVLayout } from './styled';
import { useAppSelector } from 'store/hooks';
import { uiSelector } from 'containers/UiContainer/slices';

const { Sider } = Layout;

type Props = {
    breadcrumbs?: any[];
};
const AdminLayout: React.FC<Props> = () => {
    const dispatch = useDispatch();
    const showTopBar = useAppSelector(uiSelector.showTopBar);

    useEffect(() => {
        dispatch(sagaActions.fetchMasterData());
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <NVLayout>
            <Sider
                color={defaultTheme.colors.PRIMARY_BROWN}
                width={defaultTheme.layout.sidebar}
                className="site-layout-background"
            >
                <img
                    src="/assets/logo.svg"
                    style={{
                        maxHeight: '54px',
                        padding: '20px 24px 0',
                        width: 'auto',
                    }}
                />
                <MenuLeft />
            </Sider>
            <Layout>
                {showTopBar && <Topbar />}
                <Layout className="content-layout">
                    <Outlet />
                </Layout>
            </Layout>
        </NVLayout>
    );
};

export default AdminLayout;
