/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        black: {
          DEFAULT: '#4c4c4c',
          dark: '#2e2e2e'
        },
        grey: {
          dark: 'rgba(0, 0, 0, 0.25)',
          DEFAULT: '#f5f5f5',
          1: '#2E2E2E',
          2: '#4C4C4C',
          3: '#8F8F8F',
          4: '#B3B3B3',
          5: '#CCCCCC',
          6: '#D9D9D9',
          7: '#E5E5E5',
          8: '#F2F2F2',
          9: '#F8F8F8'
        },
        red: {
          DEFAULT: '#c31424',
          1: '#721A19',
          2: '#9A191F',
          3: '#C31424',
          4: '#FA002C',
          5: '#FFDEE4',
          6: '#FFF0F2'
        },
        blue: {
          1: '#0F5183',
          2: '#065B9C',
          3: '#1D74BB',
          4: '#318FD6',
          5: '#D1EBFF',
          6: '#F1F8FE'
        },
        green: {
          1: '#077D52',
          2: '#009961',
          3: '#00B271',
          4: '#02CA81',
          5: '#C7FFE9',
          6: '#F1FEF9'
        },
        orange: {
          1: '#DD6210',
          2: '#F06C00',
          3: '#FF7700',
          4: '#FF8E32',
          5: '#FFE2C7',
          6: '#FFF7F0'
        },
        purple: {
          1: '#2D007A',
          2: '#4300A2',
          3: '#5D0CCF',
          4: '#A34DD2',
          5: '#D2A4E2',
          6: '#F6F0FF'
        }
      }
    }
  },
  plugins: []
}
