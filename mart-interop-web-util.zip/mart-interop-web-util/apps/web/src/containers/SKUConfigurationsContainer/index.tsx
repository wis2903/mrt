import {
  CheckOutlined,
  DeleteOutlined,
  EditOutlined,
  EllipsisOutlined,
  QuestionCircleOutlined
} from '@ant-design/icons'
import { Empty, Typography, Table, Dropdown, Menu, Tooltip } from 'antd'
import React, { useState } from 'react'
import { ColumnsType } from 'antd/lib/table'
import { formatUOMNameForm } from 'utils/formatUtils'
import AddUOMModal from 'containers/AddUOMModal'
import EditUOMModal from 'containers/EditUOMModal'
import { SKUConfigurationForm } from 'pages/AddSkuPage/types'
import confirmModal from 'components/ConfirmModal'
import useLocales from 'hooks/useLocales'
import { FormInstance } from 'antd/es/form'
import { AddSkuForm } from '../../pages/AddSkuPage/types'
import { validateSKUConfig } from 'utils/common'
import Switch from 'components/Form/Switch'
export interface SKUConfigurationsContainerProps {
  isNew?: boolean
  isEditable?: boolean
  isEnableAmastSellableColumn?: boolean
  submitted: boolean
  readOnly?: boolean
  parentForm: FormInstance<AddSkuForm>
  configurations: SKUConfigurationForm[]
  onSetConfigurations: (configurations: SKUConfigurationForm[]) => void
  onChange: (event: React.FormEvent<HTMLFormElement>) => void
}
type EditableTableProps = Parameters<typeof Table>[0]
type ColumnTypes = Exclude<EditableTableProps['columns'], undefined>

const SKUConfigurationsContainer: React.FC<SKUConfigurationsContainerProps> = ({
  isNew,
  isEditable,
  isEnableAmastSellableColumn,
  parentForm,
  submitted,
  readOnly,
  configurations,
  onSetConfigurations,
  onChange
}) => {
  const { t } = useLocales()
  const [selected, setSelected] = useState<number | null>(null)
  const handleDelete = (index: number) => {
    return confirmModal({
      t,
      title: t('common.Delete the unit of measurement?'),
      content: (
        <>
          <div>{t('common.By clicking on OK, this UOM will be deleted')}</div>
          <div>{t('common.This action cannot be undone!')}</div>
        </>
      ),
      onOk: () => {
        onSetConfigurations(configurations.filter((_, i) => i !== index))
        onChange({} as React.FormEvent<HTMLFormElement>)
      }
    })
  }

  const defaultColumns: (ColumnsType<any>[number] & { editable?: boolean; dataIndex: string | string[] })[] = [
    {
      title: t('common.Primary'),
      dataIndex: 'primary',
      align: 'center',
      width: 100,
      render: (_, record) => (record.isPrimary ? <CheckOutlined /> : <div></div>)
    },
    {
      title: t('AMAST sellable'),
      dataIndex: '',
      className: isEnableAmastSellableColumn ? '' : 'hidden',
      align: 'center',
      width: 100,
      render: (_: any, record: any) => {
        const defaultChecked = record.amastSellable

        return (
          <Switch
            disabled={!isEditable}
            defaultChecked={defaultChecked}
            onChange={(status) => {
              const tmpConfigurations = [...configurations]
              const processingConfiguration = tmpConfigurations.find((item) => item.id === record.id)
              if (!processingConfiguration) return
              processingConfiguration.amastSellable = status
              onSetConfigurations(tmpConfigurations)
            }}
          />
        )
      }
    },
    {
      title: t('common.Display name'),
      dataIndex: 'name',
      align: 'left',
      width: 150,
      render: (_, { name }) => {
        return name
      }
    },
    {
      title: t('common.Name'),
      dataIndex: '_name',
      align: 'left',
      width: 200,
      render: (_, { quantity }) => {
        return formatUOMNameForm(parentForm.getFieldValue('name'), quantity)
      }
    },
    {
      title: t('common.Quantity'),
      dataIndex: 'quantity',
      align: 'right',
      width: 100,
      render: (_, { quantity }) => {
        return quantity
      }
    },
    {
      title: t('common.Gross weight (g)'),
      dataIndex: 'grossWeight',
      align: 'right',
      width: 100,
      render: (_, { grossWeight }) => {
        return grossWeight
      }
    },
    {
      title: t('common.Net weight (g)'),
      dataIndex: 'netWeight',
      align: 'right',
      width: 150,
      render: (_, { netWeight }) => {
        return netWeight
      }
    },
    {
      title: t('common.Volume (ml)'),
      dataIndex: 'volume',
      align: 'right',
      width: 150,
      render: (_, { volume }) => {
        return volume
      }
    },
    {
      title: t('common.Image'),
      dataIndex: 'image',
      align: 'center',
      width: 150,
      render: (_, { image }) => {
        return (
          image && (
            <div
              style={{
                display: 'inline-block',
                width: '50px',
                height: '50px',
                background: `url(${image})`,
                backgroundSize: 'cover'
              }}
            ></div>
          )
        )
      }
    },
    {
      title: t('common.Action'),
      dataIndex: 'action',
      align: 'center',
      width: 100,
      render: (_, record, index) => {
        const actions =
          index === 0
            ? [{ key: '1', label: t('common.button.edit'), icon: <EditOutlined />, onClick: () => setSelected(index) }]
            : [
                { key: '1', label: t('common.button.edit'), icon: <EditOutlined />, onClick: () => setSelected(index) },
                {
                  key: '2',
                  label: t('common.button.delete'),
                  icon: <DeleteOutlined />,
                  onClick: () => handleDelete(index)
                }
              ]
        return readOnly ? (
          <div />
        ) : (
          <Dropdown trigger={['click']} overlay={<Menu items={actions} />}>
            <a>
              <EllipsisOutlined />
            </a>
          </Dropdown>
        )
      }
    }
  ]

  return (
    <>
      <Typography.Title level={5}>
        {t('common.Types of SKU Configurations')}&nbsp;
        <Tooltip title={t('Able to add two different UOMs for an SKU.')}>
          <QuestionCircleOutlined />
        </Tooltip>
      </Typography.Title>
      <AddUOMModal
        isNew={isNew}
        hidden={!!readOnly}
        disabled={configurations.length >= 2}
        parentForm={parentForm}
        configurations={configurations}
        onSetConfigurations={onSetConfigurations}
        onChange={onChange}
      />
      <br />
      {submitted && validateSKUConfig(configurations) ? (
        <>
          <Typography.Text type='danger'>{t(validateSKUConfig(configurations))}</Typography.Text>
          <br />
        </>
      ) : null}
      <Table
        className='mt-md overflow-x-auto'
        bordered
        dataSource={configurations}
        columns={defaultColumns as ColumnTypes}
        pagination={false}
        rowKey={'name'}
        locale={{ emptyText: <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description={t('common.No Data')} /> }}
      />
      {selected !== null && (
        <EditUOMModal
          isNew={isNew}
          index={selected}
          parentForm={parentForm}
          configurations={configurations}
          onSetConfigurations={onSetConfigurations}
          onChange={onChange}
          onClose={() => setSelected(null)}
        />
      )}
    </>
  )
}

export default SKUConfigurationsContainer
