export enum ControllerProviderFieldTypeEnum {
    number = 'number',
    string = 'string',
    date = 'date',
    list = 'list',
}

export enum ControllerProviderFieldValidationEnum {
    required = 'required',
}

export type ControllerProviderFieldType = number | string | Date | unknown[] | undefined;

export interface IControllerProviderFieldValidation {
    type: ControllerProviderFieldValidationEnum;
    message: string;
}

interface IBaseControllerProviderField {
    validations?: IControllerProviderFieldValidation[];
    error?: string;
}

interface IControllerProviderFieldNumber extends IBaseControllerProviderField {
    type: ControllerProviderFieldTypeEnum.number;
    value?: number;
    meta?: unknown;
}

interface IControllerProviderFieldString extends IBaseControllerProviderField {
    type: ControllerProviderFieldTypeEnum.string;
    value?: string;
    meta?: unknown;
}

interface IControllerProviderFieldDate extends IBaseControllerProviderField {
    type: ControllerProviderFieldTypeEnum.date;
    value?: Date;
    meta?: unknown;
}

interface IControllerProviderFieldList extends IBaseControllerProviderField {
    type: ControllerProviderFieldTypeEnum.list;
    value?: unknown[];
    meta?: unknown;
}

export type ControllerProviderField =
    | IControllerProviderFieldNumber
    | IControllerProviderFieldString
    | IControllerProviderFieldDate
    | IControllerProviderFieldList;

export interface IControllerProviderContext {
    fields: { [name: string]: ControllerProviderField };
    field: (fieldName: string) => ControllerProviderField | undefined;
    value: (fieldName: string) => ControllerProviderFieldType;
    meta: (fieldName: string) => unknown;
    error: (fieldName: string) => string | undefined;
    values: () => Record<string, ControllerProviderFieldType>;
    setValue: (fieldName: string, value: ControllerProviderFieldType) => void;
    setMeta: (fieldName: string, meta: unknown) => void;
    validate: (fieldName: string) => void;
    clearError: (fieldName: string) => void;
}

export interface IControllerProviderProperties {
    children?: React.ReactNode;
    schema?: { [key: string]: ControllerProviderField };
}
