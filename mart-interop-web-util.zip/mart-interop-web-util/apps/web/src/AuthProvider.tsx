import React, { useContext, useEffect, useRef, useState } from 'react';

import { updateAbility } from 'casl/ability';
import { AbilityContext } from 'casl/can';
import { DefaultRole } from 'constants/ability';
import { LOCAL_STORAGE_KEY } from 'constants/common';
import { isEqual } from 'lodash';
import { useNavigate } from 'react-router';
import { FORBIDDEN } from 'routes/routes';
import { useAppDispatch, useAppSelector } from 'store/hooks';
import { ProvinceDataItem, WarehouseDataItem } from 'types/MasterDataKey';

import Keycloak, {
    KeycloakInstance,
    KeycloakLoginOptions,
    KeycloakLogoutOptions,
} from 'keycloak-js';

import {
    reducerActions as masterDataActions,
    selectors as masterDataSelectors,
} from 'store/masterData/slice';

interface AuthContextType {
    initialing: boolean;
    keycloak: KeycloakInstance | null;
    user: any;
    province: any[];
    signin: (options: KeycloakLoginOptions) => void;
    signout: (options?: KeycloakLogoutOptions) => void;
    onTokenExpired?: () => void;
}

export interface LocationTypeLogin {
    state: {
        from: {
            pathname: string;
        };
    };
}

const AuthContext = React.createContext<AuthContextType>({
    initialing: true,
    user: null,
    province: [],
    keycloak: null,
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    signin: () => {},
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    signout: () => {},
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    onTokenExpired: () => {},
});

export function AuthProvider({ children }: { children: React.ReactNode }) {
    const [user, setUser] = useState<any>(null);
    const [initialing, setInitialing] = useState<boolean>(true);
    const [province, setProvince] = useState<any>([]);

    const keycloakRef = useRef<KeycloakInstance | null>(null);
    const ability = useContext(AbilityContext);

    const provinceList = useAppSelector(
        masterDataSelectors.selectorByKey<ProvinceDataItem>('provinceList')
    );
    const warehouseList = useAppSelector(
        masterDataSelectors.selectorByKey<WarehouseDataItem>('warehouseList')
    );

    const dispatch = useAppDispatch();
    const navigate = useNavigate();

    useEffect(() => {
        const token = localStorage.getItem(LOCAL_STORAGE_KEY.KC_TOKEN) || undefined; //TODO: use cookie https instead
        const refreshToken = localStorage.getItem(LOCAL_STORAGE_KEY.KC_REFRESH_TOKEN) || undefined; //TODO: use cookie https instead
        const keycloak = new Keycloak('/keycloak.json');

        keycloak
            .init({
                checkLoginIframe: false,
                token,
                refreshToken,
            })
            .then((authenticated) => {
                if (!authenticated) return Promise.reject(new Error('unauthorized'));
                if (!keycloak.token || !keycloak.refreshToken) {
                    localStorage.removeItem(LOCAL_STORAGE_KEY.KC_TOKEN);
                    localStorage.removeItem(LOCAL_STORAGE_KEY.KC_REFRESH_TOKEN);
                    return;
                }

                localStorage.setItem(LOCAL_STORAGE_KEY.KC_TOKEN, keycloak.token);
                localStorage.setItem(LOCAL_STORAGE_KEY.KC_REFRESH_TOKEN, keycloak.refreshToken);
                //TODO: use cookie https instead

                const tokens = keycloak.token?.split('.');
                const jwtPayload = JSON.parse(atob(tokens![1]));
                const roles = Object(jwtPayload.realm_access).roles as any[];
                if (
                    !roles.length ||
                    isEqual(roles, [DefaultRole.DefaultRolesInterop]) ||
                    isEqual(roles, [DefaultRole.DefaultRolesInterop, DefaultRole.DefaultInterop])
                ) {
                    localStorage.removeItem(LOCAL_STORAGE_KEY.KC_TOKEN);
                    localStorage.removeItem(LOCAL_STORAGE_KEY.KC_REFRESH_TOKEN);
                    keycloak.logout({
                        redirectUri: `${window.location.origin}${FORBIDDEN}`,
                    });
                    return Promise.resolve();
                }
                setProvince(jwtPayload.province);
                updateAbility(ability, jwtPayload);
                setUser({
                    token: keycloak.token,
                });

                const lastAccessUrl = localStorage.getItem(LOCAL_STORAGE_KEY.LAST_ACCESS_URL);
                if (lastAccessUrl) {
                    localStorage.removeItem(LOCAL_STORAGE_KEY.LAST_ACCESS_URL);
                    navigate(String(lastAccessUrl));
                }
            })
            .catch((e) => {
                if (!e) console.log(e);
                localStorage.removeItem(LOCAL_STORAGE_KEY.KC_TOKEN); //TODO: use cookie https instead
                localStorage.removeItem(LOCAL_STORAGE_KEY.KC_REFRESH_TOKEN); //TODO: use cookie https instead
            })
            .finally(() => {
                setInitialing(false);
            });
        keycloak.onTokenExpired = () => {
            keycloak.updateToken(30).then((refreshed) => {
                if (refreshed) {
                    localStorage.setItem(LOCAL_STORAGE_KEY.KC_TOKEN, keycloak.token || ''); //TODO: use cookie https instead
                    localStorage.setItem(
                        LOCAL_STORAGE_KEY.KC_REFRESH_TOKEN,
                        keycloak.refreshToken || ''
                    ); //TODO: use cookie https instead
                }
            });
        };
        keycloakRef.current = keycloak;
    }, []);

    const signin = (options: KeycloakLoginOptions) => {
        return keycloakRef.current?.login(options);
    };

    const signout = (options?: KeycloakLogoutOptions) => {
        // localStorage.removeItem(LOCAL_STORAGE_KEY.KC_TOKEN);
        // localStorage.removeItem(LOCAL_STORAGE_KEY.KC_REFRESH_TOKEN);
        // setUser(null);
        return keycloakRef.current?.logout(options);
    };

    useEffect(() => {
        if (provinceList?.length) {
            const provinceListFilter = provinceList.filter((item) => province?.includes(item.id));
            const warehouseListFilter = warehouseList.filter((item) =>
                provinceListFilter.find((_item) => _item.warehouseId === item.id)
            );
            dispatch(
                masterDataActions.adjustMasterData({
                    provinceList: provinceListFilter,
                    warehouseList: warehouseListFilter,
                })
            );
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [JSON.stringify(provinceList), JSON.stringify(province)]);

    const value = {
        initialing,
        keycloak: keycloakRef.current,
        user,
        province,
        signin,
        signout,
        onTokenExpired: keycloakRef.current?.onTokenExpired as any,
    };

    return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export { AuthContext };
