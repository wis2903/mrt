import userEvent from '@testing-library/user-event';
import apiClient from 'apis/apiClient';
import sinon from 'sinon';
import * as masterDataSlice from 'store/masterData/slice';
import { renderWithProvider, screen } from 'test';
import Component from '.';
import * as slice from '../AddSkuPage/slice';

jest.mock('lodash', () => ({
  ...jest.requireActual('lodash'),
  debounce: (cb: any) => cb
}));

sinon.stub(apiClient, 'post').callsFake(
  () =>
    ({
      data: {}
    } as any)
);
sinon.stub(apiClient, 'get').callsFake(
  () =>
    ({
      data: {}
    } as any)
);

describe('Render component', () => {
  it('should render without crash', () => {
    const { container } = renderWithProvider(<Component />);

    expect(container).toBeTruthy();
  });
  it('should render with masterData', () => {
    jest.spyOn(masterDataSlice.selectors, 'selectorByKey').mockReturnValue(() => [
      {
        id: 1,
        code: 'test',
        name: 'test',
        parentId: 2,
        parentName: '1'
      }
    ]);

    const { container } = renderWithProvider(<Component />);

    expect(container).toBeTruthy();
  });
});
describe('Actions', () => {
  afterEach(() => {
    jest.clearAllMocks();
    jest.restoreAllMocks();
  });

  it('should run form onChange when change search textbox', async () => {

    const user = userEvent.setup();

    renderWithProvider(<Component />);
    await user.type(screen.getAllByPlaceholderText(/Search/)[0], 'A');

  });
  it('should run form onChange when change search textbox 2', async () => {
    jest.spyOn(masterDataSlice.selectors, 'selectorByKey').mockImplementation(() => () => [
      {
        id: 1,
        code: 'test',
        name: 'test',
        parentId: 2,
        parentName: 'test'
      }
    ]);
    jest.spyOn(masterDataSlice.selectors, 'selectorCategoryListAllLevel').mockImplementation(() => [
      {
        id: 1,
        code: 'test',
        name: 'test',
        parentId: 2,
        parentName: 'test'
      }
    ]);
    const { container } = renderWithProvider(<Component />);
    await userEvent.click(screen.getAllByTestId('options-1')[0]);

    expect(container).toBeTruthy();
  });
  it('should run changeSearch in every form control', async () => {
    jest.spyOn(masterDataSlice.selectors, 'selectorByKey').mockImplementation(() => () => [
      {
        id: 1,
        code: 'test',
        name: 'test',
        parentId: 2,
        parentName: 'test'
      }
    ]);

    const user = userEvent.setup();

    renderWithProvider(<Component />);
    // Search textbox
    await user.type(screen.getAllByPlaceholderText(/Search/)[0], 'A');
    // Category
    await user.type(screen.getAllByTestId('select-onChange')[0], 'A');
    // Brand
    await user.type(screen.getAllByTestId('select-onChange')[1], 'A');
    // Price From
    await user.type(screen.getAllByPlaceholderText(/From/)[0], '1');
    // Price To
    await user.type(screen.getAllByPlaceholderText(/To/)[0], '1');

  });
  it('should run reset', async () => {
    const user = userEvent.setup();

    renderWithProvider(<Component />);
    // Search textbox
    await user.type(screen.getAllByPlaceholderText(/Search/)[0], 'A');
    await user.click(screen.getAllByText(/Reset/)[0]);

  });
  it('should render well with parentName null', async () => {
    jest.spyOn(masterDataSlice.selectors, 'selectorByKey').mockImplementation(() => () => [
      {
        id: 1,
        code: 'test',
        name: 'test',
        parentId: 2,
        parentName: null
      }
    ]);
    const { container } = renderWithProvider(<Component />);
    expect(container).toBeTruthy();
  });
});
