import { getOrders } from 'apis/orders';
import { DEFAULT_PAGE_NUMBER, DEFAULT_PAGE_SIZE, TIME_FORMAT } from 'constants/common';
import { isNumber, isUndefined } from 'lodash';
import moment from 'moment';
import { reducer, saga, sagaActions, selectors, sliceName } from 'pages/Orders/slice';
import { useEffect, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useAppDispatch, useAppSelector, useInjectReducer, useInjectSaga } from 'store/hooks';

export const useFetchOrders = () => {
    useInjectReducer({ key: sliceName, reducer });
    useInjectSaga({ key: sliceName, saga });
    const [searchParams] = useSearchParams();

    const dispatch = useAppDispatch();

    const loading = useAppSelector(selectors.selectLoading);
    const orders = useAppSelector(selectors.selectOrders);
    const total = useAppSelector(selectors.selectTotal);
    const pageNumber = searchParams.get('pn')
        ? parseInt(searchParams.get('pn') as any)
        : DEFAULT_PAGE_NUMBER;
    const pageSize = searchParams.get('ps')
        ? parseInt(searchParams.get('ps') as any)
        : DEFAULT_PAGE_SIZE;
    const createdDateFrom = useMemo(
        () =>
            searchParams.get('cdf')
                ? searchParams.get('cdf') !== '-1'
                    ? moment.unix(parseInt(searchParams.get('cdf') as string)).format(TIME_FORMAT)
                    : null
                : moment().subtract(1, 'week').format(TIME_FORMAT),
        [searchParams]
    );
    const createdDateTo = useMemo(
        () =>
            searchParams.get('cdt')
                ? searchParams.get('cdt') !== '-1'
                    ? moment.unix(parseInt(searchParams.get('cdt') as string)).format(TIME_FORMAT)
                    : null
                : moment().format(TIME_FORMAT),
        [searchParams]
    );
    const statusId = useMemo(() => {
        return searchParams.get('si') ? searchParams.get('si')?.split(',') : [];
    }, [searchParams]);
    const search: any = useMemo(() => {
        const values: any = {
            pi: 1,
            di: 1,
            w: 1,
            tf: 1,
            tt: 1,
            tp: '',
            s: '',
        };
        const _values: any = Object.keys(values).reduce(
            (acc, key) =>
                searchParams.get(key)
                    ? {
                          ...acc,
                          [key]: isNumber(values[key])
                              ? parseInt(searchParams.get(key) as any)
                              : searchParams.get(key),
                      }
                    : acc,
            {
                cdf: createdDateFrom,
                cdt: createdDateTo,
                si: statusId,
            }
        );

        return {
            provinceId: _values.pi,
            districtId: _values.di,
            warehouseId: _values.w,
            totalFrom: _values.tf,
            totalTo: _values.tt,
            search: _values.s,
            createdDateFrom: _values.cdf,
            createdDateTo: _values.cdt,
            statusId: _values.si,
            type: _values.tp,
        };
    }, [createdDateFrom, createdDateTo, statusId, searchParams]);

    const fetchWithoutDispatch = async (): Promise<Record<string, unknown>[]> => {
        let results: Record<string, unknown>[] = [];

        for (let i = DEFAULT_PAGE_NUMBER; i < Infinity; i++) {
            try {
                const response = await getOrders({
                    pageNumber: i,
                    pageSize: 1000,
                    search,
                });
                const _orders = Array.isArray(response.data.data) ? response.data.data : [];
                if (!_orders.length) break;
                else results = results.concat(_orders);
            } catch (e) {
                break;
            }
        }

        return results;
    };

    const fetch = () => {
        console.log(search);

        dispatch(
            sagaActions.fetchOrders({
                pageNumber,
                pageSize,
                search,
            })
        );
    };

    useEffect(() => {
        if (isUndefined(pageNumber)) return;
        fetch();
    }, [dispatch, pageNumber, pageSize, search]);

    return { loading, orders, total, search, fetch, fetchWithoutDispatch };
};
