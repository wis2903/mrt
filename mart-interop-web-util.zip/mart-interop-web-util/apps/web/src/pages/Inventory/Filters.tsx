import { Col, Divider, Form, Input, Row } from 'antd';
import { DEFAULT_PAGE_SIZE, DELAY_INPUT_TIME } from 'constants/common';
import useLocales from 'hooks/useLocales';
import { debounce } from 'lodash';
import { useEffect, useRef } from 'react';
import { useAppSelector } from 'store/hooks';
import { InventoryFilter, TYPE_OF_QUANTITY } from 'types/Inventory';
import { selectors as masterDataSelectors } from 'store/masterData/slice';
import { SearchOutlined } from '@ant-design/icons';
import { useSearchParams } from 'react-router-dom';
import { DEFAULT_PAGE_NUMBER } from '../../constants/common';
import Select from 'components/Select';
import Button from 'components/Button';
import { DefaultOptionType } from 'antd/lib/select';
const { Option } = Select;
const Filters = ({
    initialValues,
    onChange,
}: {
    initialValues: InventoryFilter;
    onChange: (value: InventoryFilter) => void;
}) => {
    const { t } = useLocales();
    const [searchParams, setSearchParams] = useSearchParams();

    const warehouseList = useAppSelector(
        masterDataSelectors.selectorByKey('warehouseList')
    );

    const [form] = Form.useForm<InventoryFilter>();
    const handleChange = debounce(
        () => {
            onChange(form.getFieldsValue());
        },
        DELAY_INPUT_TIME,
        { trailing: true }
    );

    const filterOption = (input: string, option?: DefaultOptionType) =>
        (option?.children as unknown as string)
            ?.toLowerCase()
            ?.includes(input?.toLowerCase());

    useEffect(() => {
        form.setFieldsValue({
            warehouseId: searchParams.get('wi')
                ? parseInt(searchParams.get('wi') as string)
                : undefined,
            typeOfOnhandQuantity: searchParams.get('on') || undefined,
            typeOfAvailableQuantity: searchParams.get('av') || undefined,
            textSearch: searchParams.get('s') || undefined,
        });
    }, [searchParams]);

    useEffect(() => {
        searchParams.set('pn', '1');
        setSearchParams(searchParams);
    }, [
        searchParams.get('wi'),
        searchParams.get('s'),
        searchParams.get('on'),
        searchParams.get('av'),
    ]);

    return (
        <>
            <Form
                form={form}
                layout="horizontal"
                labelWrap
                labelAlign="left"
                onChange={handleChange}
                initialValues={initialValues}
            >
                <Row gutter={32}>
                    <Col span={8}>
                        <Form.Item
                            name="warehouseId"
                            label={t('Warehouse')}
                            className="mb-05"
                        >
                            <Select
                                allowClear
                                placeholder={t('Select a warehouse')}
                                showSearch
                                onChange={handleChange}
                                optionFilterProp="children"
                                filterOption={filterOption}
                            >
                                {warehouseList?.map((x) => (
                                    <Option key={x.id} value={x.id}>
                                        {x.name}
                                    </Option>
                                ))}
                            </Select>
                        </Form.Item>
                    </Col>
                    <Col span={8}>
                        <Form.Item
                            name="typeOfOnhandQuantity"
                            label={t('Type of onhand quantity')}
                            className="mb-05"
                        >
                            <Select
                                allowClear
                                placeholder={t('Select')}
                                showSearch
                                onChange={handleChange}
                                optionFilterProp="children"
                                filterOption={filterOption}
                            >
                                {TYPE_OF_QUANTITY?.map((x) => (
                                    <Option key={x.key} value={x.key}>
                                        {x.value}
                                    </Option>
                                ))}
                            </Select>
                        </Form.Item>
                    </Col>
                    <Col span={8}>
                        <Form.Item
                            name="typeOfAvailableQuantity"
                            label={t('Type of available quantity')}
                            className="mb-05"
                        >
                            <Select
                                allowClear
                                placeholder={t('Select')}
                                showSearch
                                onChange={handleChange}
                                optionFilterProp="children"
                                filterOption={filterOption}
                            >
                                {TYPE_OF_QUANTITY?.map((x) => (
                                    <Option key={x.key} value={x.key}>
                                        {x.value}
                                    </Option>
                                ))}
                            </Select>
                        </Form.Item>
                    </Col>
                    <Col flex="auto" className="mt-md">
                        <div className="justify-content-end align-items-center">
                            <Button
                                data-testid="reset-filter-button"
                                htmlType="button"
                                onClick={() => {
                                    form.resetFields();
                                    setSearchParams({
                                        ps: DEFAULT_PAGE_SIZE.toString(),
                                        pn: DEFAULT_PAGE_NUMBER.toString(),
                                    });
                                }}
                            >
                                {t('common.button.reset')}
                            </Button>
                        </div>
                    </Col>
                    <Divider dashed className="mt-md" />
                    <Col flex="auto" className="mt-0">
                        <div className="justify-content-end align-items-center">
                            <Form.Item name="textSearch">
                                <Input
                                    className="site-input-right"
                                    placeholder={t('Search')}
                                    suffix={<SearchOutlined />}
                                    allowClear
                                    onChange={handleChange}
                                />
                            </Form.Item>
                        </div>
                    </Col>
                </Row>
            </Form>
        </>
    );
};
export default Filters;
