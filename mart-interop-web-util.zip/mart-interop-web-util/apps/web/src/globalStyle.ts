import { createGlobalStyle } from 'styled-components';
import { defaultTheme } from 'styles/defaultTheme.styles';

const GlobalStyle = createGlobalStyle`
  body,
  #root {
    margin: 0;
    font-family: -apple-system, BlinkMacSystemFont, 'Nunito', sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale; 
    color: ${defaultTheme.colors.GRAY1};
  }

  body.hiddenScrollbar {
    -ms-overflow-style: none;  /* IE and Edge */
    scrollbar-width: none;
  }

  body.hiddenScrollbar::-webkit-scrollbar {
    display: none;
  }

  a,
  abbr,
  acronym,
  address,
  applet,
  article,
  aside,
  audio,
  b,
  big,
  blockquote,
  body,
  canvas,
  caption,
  center,
  cite,
  code,
  dd,
  del,
  details,
  dfn,
  div,
  dl,
  dt,
  em,
  embed,
  fieldset,
  figcaption,
  figure,
  footer,
  form,
  h1,
  h2,
  h3,
  h4,
  h5,
  h6,
  header,
  hgroup,
  html,
  i,
  iframe,
  img,
  ins,
  kbd,
  label,
  legend,
  li,
  mark,
  menu,
  nav,
  object,
  ol,
  output,
  p,
  pre,
  q,
  ruby,
  s,
  samp,
  section,
  small,
  span,
  strike,
  strong,
  sub,
  summary,
  sup,
  table,
  tbody,
  td,
  tfoot,
  th,
  thead,
  time,
  tr,
  tt,
  u,
  ul,
  var,
  video {
    margin: 0;
    padding: 0;
    border: 0;
    outline: none;
  }
  /* HTML5 display-role reset for older browsers */
  article,
  aside,
  details,
  figcaption,
  figure,
  footer,
  header,
  hgroup,
  menu,
  nav,
  section {
    display: block;
  }

  body {
    font-size: 14px;
    line-height: 20px;
  }

  button, i {
    cursor: pointer;
  }

  button {
    outline: none;
  }

  body * {
    box-sizing: border-box;
  }

  ol,
  ul {
    list-style: none;
  }

  blockquote,
  q {
    quotes: none;
  }

  blockquote:after,
  blockquote:before,
  q:after,
  q:before {
    content: '';
    content: none;
  }

  table {
    border-collapse: collapse;
    border-spacing: 0;
  }

  a {
    text-decoration: none;
    color: ${defaultTheme.colors.PRIMARY};
    &:hover,
    &:active,
    &:focus {
      color: ${defaultTheme.colors.RED2}
    }
  }

  // CSS for NProgress
  #nprogress {
    pointer-events: none;
    z-index: 1201;
    position: absolute;
  }
  #nprogress .bar {
    background: ${defaultTheme.colors.PRIMARY}
  }
  #nprogress .spinner {
    display: none;
  }
  #nprogress .peg {
    box-shadow: 0 0 10px ${defaultTheme.colors.PRIMARY}, 0 0 5px ${defaultTheme.colors.PRIMARY};
  }

  // table
  .ant-table-content{
    overflow: auto;
  }

  body{
    .tox-tinymce {
        border-radius: 0 !important;
        border: 0 !important;
    }

    .tox-editor-header {
        padding: 2px !important;
        border-bottom: 1px solid #cccccc !important;
        box-shadow: none !important;
        background: white !important;
    }

    .tox .tox-tbtn {
        margin: 0 2px 0 0 !important;
        border-radius: 0 !important;
    }

    .tox .tox-tbtn:hover{
      background-color: #eeeeee !important;
    }

    .tox .tox-tbtn--enabled, .tox .tox-tbtn--enabled:hover{
      background-color: #eeeeee !important;
    }

    .tox .tox-collection--list .tox-collection__item--active {
        background-color: #f8f8f8 !important;
    }

    .tox .tox-collection--list .tox-collection__item--enabled {
        background-color: #f2f2f2 !important;
    }

    .tox .tox-collection__item-checkmark {
        display: none !important;
    }

    .tox .tox-toolbar__group {
        padding: 0 !important;
    }

    .tox-toolbar__overflow {
        padding: 4px 4px !important;
        border-radius: 2px !important;
        border: 0 !important;
    }

    .tox.tox-tinymce-aux .tox-toolbar__overflow {
      background: #ffffff !important;
    }

    .tox .tox-number-input button.plus,
    .tox .tox-number-input button.minus,
    .tox .tox-number-input input {
      border-radius: 0 !important;
    }

    .tox .tox-number-input:focus:not(:active)>.tox-input-wrapper,
    .tox .tox-number-input:focus:not(:active)>button {
      background: unset !important;
    }

    .tox .tox-menu {
        border-radius: 2px !important;
    }

    .tox-collection__group {
        display: inline-flex;
        flex-direction: column;
        gap: 2px;
    } 

    .tox-toolbar__primary{
      display: flex;
      flex-wrap: wrap;
      gap: 4px;
      background: transparent !important;
    }

    .tox .tox-toolbar, .tox .tox-toolbar__primary{
      background: transparent !important;
    }

    .tox .tox-edit-area__iframe{
      background: transparent !important;
    }

    .tox .tox-toolbar-overlord{
      background: transparent !important;
    }
  }
`;

export default GlobalStyle;
