export interface GetDistrictParams {
  district?: string;
  province?: string;
}
