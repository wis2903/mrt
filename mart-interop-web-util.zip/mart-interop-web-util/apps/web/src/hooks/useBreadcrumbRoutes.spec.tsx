import * as intl from 'react-intl';
import { useBreadcrumbRoutes } from './useBreadcrumbRoutes';
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useLocation: () => ({ key: 'test', pathname: 'test', state: 'test', search: 'test', hash: 'test' })
}));
describe('useTranslate', () => {
  it('Should run normally', async () => {
    jest.spyOn(intl, 'useIntl').mockReturnValueOnce({ formatMessage: jest.fn() } as any);
    expect(useBreadcrumbRoutes()).toEqual([
      { breadcrumbName: undefined, path: '' },
      { breadcrumbName: 'test', path: 'test' }
    ]);
  });
});
