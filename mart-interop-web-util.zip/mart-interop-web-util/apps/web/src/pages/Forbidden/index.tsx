import Button from 'components/Button';
import useLocales from '../../hooks/useLocales';

import { WarningFilled } from '@ant-design/icons';
import { notification, Typography } from 'antd';
import { AuthContext } from 'AuthProvider';
import { useContext, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { HOME_URI } from 'routes/routes';
import { NotAuthorizedStyled } from './styled';

const Forbidden = () => {
    const { t } = useLocales();
    const auth = useContext(AuthContext);
    const navigate = useNavigate();
    useEffect(() => {
        notification.destroy();
    });
    return (
        <NotAuthorizedStyled>
            <WarningFilled style={{ fontSize: 100 }} />
            <br />
            <Typography.Title level={2}>{t('common.You are not authorized')}</Typography.Title>
            <br />
            <Typography.Text>
                {t("It seems like you don't have permission to use this portal.")}
            </Typography.Text>
            <Typography.Text>{t('Please sign in with a different account!')}</Typography.Text>
            <br />
            <Button
                type="primary"
                onClick={() => {
                    auth.signin({
                        idpHint: 'google',
                        redirectUri: `${window.location.origin}`,
                    });
                }}
            >
                {t('Sign in with another account')}
            </Button>
            <br />
            <Link to={HOME_URI}>{t('common.Back to Home page')}</Link>
        </NotAuthorizedStyled>
    );
};

export default Forbidden;
