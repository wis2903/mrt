import axios from 'axios';
import { API_TIMEOUT, LOCAL_STORAGE_KEY } from 'constants/common';
import { toCamelCase, toSnakeCase } from 'utils/data';

export const transform = (data: any) => JSON.stringify(toSnakeCase(data));

const apiClient = axios.create({
    baseURL: process.env.VITE_PTC_API_URL,
    timeout: API_TIMEOUT,
    headers: {
        'Content-Type': 'application/json;charset=UTF-8',
    },
});

export const apiClientV2 = axios.create({
    baseURL: process.env.VITE_MART_API_URL,
    timeout: API_TIMEOUT,
    headers: {
        'Content-Type': 'application/json;charset=UTF-8',
    },
});

export const apiClientWithTransformedResponse = axios.create({
    baseURL: process.env.VITE_MART_API_URL,
    timeout: API_TIMEOUT,
    headers: {
        'Content-Type': 'application/json;charset=UTF-8',
    },
});
export const apiClientWithTransformedRequestAndResponse = axios.create({
    baseURL: process.env.VITE_MART_API_URL,
    timeout: API_TIMEOUT,
    headers: {
        'Content-Type': 'application/json;charset=UTF-8',
    },
    transformRequest: [transform],
});

export const apiMartClient = axios.create({
    baseURL: process.env.VITE_MART_API_URL,
    timeout: API_TIMEOUT,
    headers: {
        'Content-Type': 'application/json;charset=UTF-8',
    },
    transformRequest: [transform],
});

export const apiCXClient = axios.create({
    baseURL: process.env.VITE_CX_API_URL,
    timeout: API_TIMEOUT,
    headers: {
        'Content-Type': 'application/json;charset=UTF-8',
    },
});

const addCustomHeader = (_config: any) => {
    const token = localStorage.getItem(LOCAL_STORAGE_KEY.KC_TOKEN) || undefined;
    const config: any = {
        ..._config,
        headers: { ..._config.headers },
    };
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
};

const addCustomHeaderForCX = (_config: any) => {
    const config: any = {
        ..._config,
        headers: { ..._config.headers },
    };
    config.headers.Authorization = process.env.VITE_CX_API_TOKEN;
    return config;
};

apiClient.interceptors.request.use(addCustomHeader, (error) => {
    return Promise.reject(error);
});
apiClientV2.interceptors.request.use(addCustomHeader, (error) => {
    return Promise.reject(error);
});
apiClientWithTransformedResponse.interceptors.request.use(addCustomHeader, (error) => {
    return Promise.reject(error);
});
apiClientWithTransformedResponse.interceptors.response.use((response) => {
    return {
        ...response,
        data: toCamelCase(response.data),
    };
});
apiClientWithTransformedRequestAndResponse.interceptors.request.use(addCustomHeader, (error) => {
    return Promise.reject(error);
});
apiClientWithTransformedRequestAndResponse.interceptors.response.use((response) => {
    return {
        ...response,
        data: toCamelCase(response.data),
    };
});
apiCXClient.interceptors.request.use(addCustomHeaderForCX, (error) => {
    return Promise.reject(error);
});
apiMartClient.interceptors.request.use(addCustomHeader, (error) => {
    return Promise.reject(error);
});
apiMartClient.interceptors.response.use((response) => {
    return {
        ...response,
        data: toCamelCase(response.data),
    };
});

export default apiClient;
