import React from 'react';
import Button from 'components/Button';
import useLocales from 'hooks/useLocales';
import Content from 'layouts/components/Content';
import PageFooter from 'layouts/components/PageFooter';
import PageHeader from 'layouts/components/PageHeader';
import ProductDetail from './components/ProductDetail';
import ProvinceList from './components/ProvinceList';
import SKUDetail from './components/SKUDetail';
import { DeleteOutlined, EditOutlined, EyeOutlined } from '@ant-design/icons';
import { Card, Col, Result, Row, Select, Spin } from 'antd';
import { loadingSelectors } from 'containers/LoadingContainer/slices';
import { useEffect } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import { selectors as masterDataSelectors } from 'store/masterData/slice';
import { isUndefined } from 'lodash';
import { isInvalidFormData, prepareUpdateData } from './utils';
import { SKUS_URI } from 'routes/routes';
import { AbilityContext } from 'casl/can';
import {
    reducer,
    reducerActions,
    saga,
    sagaActions,
    selectors,
    sliceName,
} from './slice';
import {
    useAppDispatch,
    useAppSelector,
    useInjectReducer,
    useInjectSaga,
} from 'store/hooks';
import { Action, Page } from 'constants/ability';

const { Option } = Select;

const PriceConfigPage = () => {
    useInjectReducer({ key: sliceName, reducer });
    useInjectSaga({ key: sliceName, saga });
    const ability = React.useContext(AbilityContext);
    const [searchParams, setSearchParams] = useSearchParams();
    const viewMode = (
        !ability.can(Action.Edit, Page.PriceConfiguration)
            ? 'view'
            : searchParams.get('viewMode') || 'edit'
    ) as Actions;
    const { t } = useLocales();
    const dispatch = useAppDispatch();
    const { skuId } = useParams();

    const routes = [
        {
            path: '',
            breadcrumbName: t('Home'),
        },
        {
            path: '/price-config',
            breadcrumbName: t('SKU Price Configuration'),
        },
    ];

    const skuDetail = useAppSelector(selectors.skuDetailSelector);
    const selectedSkuConfig = useAppSelector(
        selectors.selectedSkuConfigSelector
    );
    const provincesFormData = useAppSelector(
        selectors.provincesFormDataSelector
    );

    const isLoading = useAppSelector(loadingSelectors.selectIsLoading);
    const loadingMasterData = useAppSelector(masterDataSelectors.selectLoading);
    const isSaving = useAppSelector(selectors.isSavingSelector);

    useEffect(() => {
        if (skuId) dispatch(sagaActions.fetchSkuDetail({ skuId, t }));
    }, [skuId, dispatch]);

    const handleSave = () => {
        if (!selectedSkuConfig || !skuId) return;

        const updateData = prepareUpdateData(provincesFormData);

        dispatch(reducerActions.changeIsValidating(true));
        if (isInvalidFormData(updateData)) return;

        dispatch(
            sagaActions.updatePriceConfig({
                skuConfigurationId: selectedSkuConfig.id,
                sellingPrices: updateData,
                skuId,
                callback: () => {
                    searchParams.set('viewMode', 'view');
                    setSearchParams(searchParams);
                },
                t,
            })
        );
    };

    const handleCancel = () => {
        skuId && dispatch(sagaActions.fetchSkuDetail({ skuId, t }));
    };

    const handleChangeViewMode = (value: Actions) => {
        searchParams.set('viewMode', value);
        setSearchParams(searchParams);
        skuId && dispatch(sagaActions.fetchSkuDetail({ skuId, t }));
    };

    if (
        isLoading ||
        isUndefined(isLoading) ||
        loadingMasterData ||
        isUndefined(loadingMasterData)
    )
        return (
            <div className="justify-content-center">
                <Spin size="large" />
            </div>
        );
    else if (!skuDetail)
        return (
            <Result
                status="warning"
                title={t('common.message.somethingWrong')}
            />
        );

    return (
        <>
            <PageHeader
                title={t('priceConfiguration.priceConfiguration')}
                breadcrumb={{ routes }}
                extra={[
                    <Link key="back" to={SKUS_URI}>
                        <Button className="btn-pill">{t('Back')}</Button>
                    </Link>,
                    <Select
                        key="dropdown"
                        style={{ width: 120 }}
                        value={viewMode}
                        placeholder={t('common.button.actions')}
                        data-testid="select-mode"
                        onSelect={handleChangeViewMode}
                    >
                        <Option key="view">
                            <EyeOutlined /> {t('common.button.view')}
                        </Option>
                        {ability.can(Action.Edit, Page.PriceConfiguration) && (
                            <Option key="edit">
                                <EditOutlined /> {t('common.button.edit')}
                            </Option>
                        )}
                        {ability.can(
                            Action.Delete,
                            Page.PriceConfiguration
                        ) && (
                            <Option key="delete">
                                <DeleteOutlined /> {t('common.button.delete')}
                            </Option>
                        )}
                    </Select>,
                ]}
            />
            <Content>
                <>
                    <Row gutter={30} className="mb-md">
                        <Col span={12}>
                            <Card className="h-100">
                                <ProductDetail />
                            </Card>
                        </Col>
                        <Col span={12}>
                            <Card className="h-100">
                                <SKUDetail
                                    key={skuDetail?.id}
                                    skuDetail={skuDetail}
                                />
                            </Card>
                        </Col>
                    </Row>
                    <Card>
                        <ProvinceList viewMode={viewMode} />
                    </Card>
                </>
            </Content>
            {viewMode === 'edit' && (
                <PageFooter>
                    <div className="right">
                        <Button
                            size="large"
                            className="mr-md"
                            key="2"
                            data-testid="button-cancel"
                            onClick={handleCancel}
                        >
                            {t('common.button.cancel')}
                        </Button>
                        <Button
                            size="large"
                            key="1"
                            type="primary"
                            data-testid="button-save"
                            onClick={handleSave}
                            loading={isSaving}
                        >
                            {t('common.button.save')}
                        </Button>
                    </div>
                </PageFooter>
            )}
        </>
    );
};
export default PriceConfigPage;
