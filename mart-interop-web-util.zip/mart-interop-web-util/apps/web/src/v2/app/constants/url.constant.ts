// master data
export const MASTER_DATA_API_URL = '/mart-sp-mgmt/1.0/portal/master';
export const CREATE_BRAND_API_URL = '/mart-sp-mgmt/1.0/portal/brand/create';
export const CREATE_CATEGORY_API_URL = '/mart-sp-mgmt/1.0/portal/category/create';

// product
export const SEARCH_PRODUCTS_API_URL = '/mart-sp-mgmt/1.0/portal/sku/search';
export const SEARCH_PRODUCTS_BY_PRICE_OPTION_API_URL = '/mart-sp-mgmt/1.0/portal/sku/price/search';
export const GET_PRODUCT_DETAILS_API_URL = '/mart-sp-mgmt/1.0/portal/sku/:skuId';
export const GET_PRODUCT_DETAILS_ALT_API_URL = '/mart-sp-mgmt/1.0/portal/sku/detail';
export const CREATE_PRODUCT_API_URL = '/mart-sp-mgmt/1.0/portal/sku/create';
export const UPDATE_PRODUCT_API_URL = '/mart-sp-mgmt/1.0/portal/sku/:skuId';
export const DISABLE_PRODUCT_API_URL = '/mart-sp-mgmt/1.0/portal/sku/:skuId/disable';
export const ENABLE_PRODUCT_API_URL = '/mart-sp-mgmt/1.0/portal/sku/:skuId/enable';

// pricing
export const UPDATE_SELLING_PRICE_API_URL = '/mart-sp-mgmt/1.0/portal/sku/config/:uomId/price';

// po
export const CREATE_PO_API_URL = '/mart-sp-mgmt/1.0/portal/po';
export const UPDATE_PO_API_URL = '/mart-sp-mgmt/1.0/portal/po/:id';
export const SEARCH_PO_API_URL = '/mart-sp-mgmt/1.0/portal/po';
export const GET_PO_DETAILS_API_URL = '/mart-sp-mgmt/1.0/portal/po/:id';

//order
export const CANCEL_UNCOMPLETED_ORDER_API_URL = '/mart-sp-mgmt/1.0/portal/orders/:id/cancel';
export const CANCEL_COMPLETED_ORDER_API_URL =
    '/mart-sp-mgmt/1.0/portal/orders/:id/cancel/complete-order';
export const UPDATE_CANCELLATION_REQUEST_API_URL =
    '/mart-sp-mgmt/1.0/portal/orders/:id/request-cancel';
