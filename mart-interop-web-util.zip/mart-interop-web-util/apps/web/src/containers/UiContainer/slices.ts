import { createSlice } from '@reduxjs/toolkit'
import { AppState } from '../../store/store'

export const uiSliceName = 'ui'
export const initialState = {
  showTopBar: true
}

const uiSlice = createSlice({
  name: uiSliceName,
  initialState,
  reducers: {
    showTopBar: (state) => ({
      ...state,
      showTopBar: true
    }),
    hideTopBar: (state) => ({
      ...state,
      showTopBar: false
    })
  }
})

const showTopBar = (state: AppState) => state[uiSliceName]?.showTopBar

const uiSelector = {
  showTopBar
}

const { reducer, actions: uiActions } = uiSlice

export { reducer, uiActions, uiSelector }
