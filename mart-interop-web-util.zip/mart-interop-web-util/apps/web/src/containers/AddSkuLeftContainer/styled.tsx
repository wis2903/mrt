import { Button } from 'antd';
import styled from 'styled-components';

export const NewBrandButton = styled(Button)`
    font-weight: 600;
    border: 0;
    width: 100%;
    text-align: left;
    color: #c31424;
    padding: 10px 8px;
    display: flex;
    align-items: center;
    justify-content: flex-start;
    gap: 6px;
    border-top: 1px solid #e5e5e5 !important;
    height: 40px;
`;
