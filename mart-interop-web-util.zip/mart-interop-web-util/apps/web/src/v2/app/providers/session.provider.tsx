import React from 'react';
import Dialog, { IOnDialogLoadedAPI } from '../components/dialog/dialog';
import { useLocale } from '../hooks/useLocale.hook';

export const SessionProvider = ({ children }: { children?: React.ReactNode }): JSX.Element => {
    const { translate } = useLocale();

    const dialogAPIRef = React.useRef<IOnDialogLoadedAPI>();
    const intervalHandlerRef = React.useRef<ReturnType<typeof setInterval>>();

    const handleOnDialogLoaded = (api: IOnDialogLoadedAPI): void => {
        dialogAPIRef.current = api;
        dialogAPIRef.current.addOnOkListener(() => {
            window.location.reload();
        });
    };

    // const handleCheckSession = (): void => {
    //     intervalHandlerRef.current = setInterval(() => {
    //         getMasterData().catch((e) => {
    //             if (Object(e).response?.status === 401 || Object(e).response?.status === 403) {
    //                 dialogAPIRef.current?.requestOpenDialog();
    //                 clearInterval(intervalHandlerRef.current);
    //             }
    //         });
    //     }, 1000 * 60 * 15);
    // };

    React.useEffect(() => {
        // handleCheckSession();

        return (): void => {
            clearInterval(intervalHandlerRef.current);
        };
    }, []);

    return (
        <>
            {children}
            <Dialog
                onLoaded={handleOnDialogLoaded}
                title={translate('common.dialog.sessionExpiredTitle')}
                disabledButton={['cancel']}
                okButtonText={translate('common.label.refresh')}
            >
                <span className="text-yellow-600 font-medium">
                    {translate('common.dialog.sessionExpiredMessage')}
                </span>
            </Dialog>
        </>
    );
};
