import { TagProps } from 'antd';
import { OrderStatus } from 'types/Orders';
export const ORDER_STATUS_MAPPING_COLOR: Record<OrderStatus, TagProps['color']> = {
  CREATED: 'geekblue',
  DELIVERY: 'cyan',
  PLACED: 'magenta',
  COMPLETED: 'success',
  CANCELED: 'default',
  PROCESSING: 'gold'
};

export interface OrderStatusMasterData {
  code: OrderStatus;
  name: string;
  color: TagProps['color'];
}

export const ORDER_STATUS_MASTER_DATA: OrderStatusMasterData[] = [
  {
    code: 'CREATED',
    name: 'orders.orderCreated',
    color: 'geekblue'
  },
  {
    code: 'PLACED',
    name: 'orders.orderPlaced',
    color: 'magenta'
  },
  {
    code: 'PROCESSING',
    name: 'orders.orderProcessing',
    color: 'gold'
  },
  {
    code: 'DELIVERY',
    name: 'orders.orderDelivery',
    color: 'cyan'
  },
  {
    code: 'COMPLETED',
    name: 'orders.orderCompleted',
    color: 'success'
  },
  {
    code: 'CANCELED',
    name: 'orders.orderCanceled',
    color: 'default'
  }
];
