import { SearchOutlined } from '@ant-design/icons';
import { Col, Divider, Form, Input, Row } from 'antd';
import InputNumber from 'components/InputNumber';
import { DEFAULT_PAGE_SIZE, DELAY_INPUT_TIME, MAX_LENGTH_INPUT } from 'constants/common';
import useLocales from 'hooks/useLocales';
import { debounce } from 'lodash';
import { reducer, saga, sliceName } from 'pages/AddSkuPage/slice';
import { useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useInjectReducer, useInjectSaga } from 'redux-injectors';
import { useAppSelector } from 'store/hooks';
import { selectors as masterDataSelectors } from 'store/masterData/slice';
import { SkuListSearchForm } from 'types/SKUDetail';
import { DEFAULT_PAGE_NUMBER } from '../../constants/common';
import Select from 'components/Select';
import Button from 'components/Button'

const { Option } = Select;

const Filters = () => {
  useInjectReducer({ key: sliceName, reducer });
  useInjectSaga({ key: sliceName, saga });
  const [searchParams, setSearchParams] = useSearchParams();

  const { t } = useLocales();

  const [form] = Form.useForm<SkuListSearchForm>();

  const brandList = useAppSelector(masterDataSelectors.selectorByKey('brandList'));
  const categoryList = useAppSelector(masterDataSelectors.selectorCategoryListAllLevel);
  const handleChange = debounce(
    () => {
      const values: any = form.getFieldsValue();
      const _values: any = {
        cat: values.category,
        bi: values.brandId,
        tf: values.totalFrom,
        tt: values.totalTo,
        s: values.search
      };
      Object.keys(_values).forEach((key) => {
        return !_values[key] ? searchParams.delete(key) : searchParams.set(key, _values[key]);
      });
      searchParams.set('pn', DEFAULT_PAGE_NUMBER.toString());
      searchParams.set('ps', DEFAULT_PAGE_SIZE.toString());
      setSearchParams(searchParams);
    },
    DELAY_INPUT_TIME,
    { trailing: true }
  );

  const handleChangeCategory = debounce(
    (value: string | number) => {
      const selectedCategory = categoryList?.find((category) => category.id === value);
      const categoryId = selectedCategory?.parentId ? selectedCategory.parentId : selectedCategory?.id;
      const subCategoryId = selectedCategory?.parentId ? selectedCategory.id : selectedCategory?.parentId;
      value ? searchParams.set('cat', value?.toString()) : searchParams.delete('cat');
      categoryId ? searchParams.set('ci', categoryId.toString()) : searchParams.delete('ci');
      subCategoryId ? searchParams.set('sci', subCategoryId.toString()) : searchParams.delete('sci');
      searchParams.set('pn', DEFAULT_PAGE_NUMBER.toString());
      searchParams.set('ps', DEFAULT_PAGE_SIZE.toString());
      setSearchParams(searchParams);
    },
    DELAY_INPUT_TIME,
    { trailing: true }
  );

  const onReset = () => {
    setSearchParams({ ps: DEFAULT_PAGE_SIZE.toString(), pn: DEFAULT_PAGE_NUMBER.toString() });
    form.resetFields();
  };
  useEffect(() => {
    form.setFieldsValue({
      category: searchParams.get('cat') ? parseInt(searchParams.get('cat') as any) : undefined,
      brandId: searchParams.get('bi') ? parseInt(searchParams.get('bi') as any) : undefined,
      totalFrom: searchParams.get('tf') as any,
      totalTo: searchParams.get('tt') as any,
      search: searchParams.get('s') as any
    });
  }, [searchParams]);

  return (
    <>
      <Form form={form} layout='vertical' labelWrap labelAlign='left' onChange={handleChange}>
        <Row gutter={32}>
          <Col>
            <Form.Item name='category' label={t('sku.category')}>
              <Select
                allowClear
                onChange={handleChangeCategory}
                placeholder={t('Select')}
                style={{ width: 250 }}
                showSearch
                optionFilterProp='children'
                filterOption={(input, option) => (option?.children as unknown as string)?.toLowerCase()?.includes(input?.toLowerCase())}>
                {categoryList?.map((x) => (
                  <Option key={x.id} value={x.id} onChange={handleChangeCategory}>
                    {x.name}
                  </Option>
                ))}
              </Select>
            </Form.Item>
          </Col>
          <Col>
            <Form.Item name='brandId' label={t('sku.brand')}>
              <Select
                allowClear
                onChange={handleChange}
                placeholder={t('Select')}
                style={{ width: 180 }}
                showSearch
                optionFilterProp='children'
                filterOption={(input, option) => (option?.children as unknown as string)?.toLowerCase()?.includes(input?.toLowerCase())}>
                {brandList?.map((x) => (
                  <Option key={x.id} value={x.id}>
                    {x.name}
                  </Option>
                ))}
              </Select>
            </Form.Item>
          </Col>
          <Col flex='auto'>
            <div className='justify-content-between'>
              <Form.Item label={t('sku.price')} className='mb-0 site-input-group-wrapper'>
                <Input.Group compact>
                  <Form.Item name='totalFrom'>
                    <InputNumber style={{ width: '150px' }} className='site-input-left' placeholder={t('From')} />
                  </Form.Item>
                  <Input className='site-input-split' placeholder='~' disabled />
                  <Form.Item name='totalTo'>
                    <InputNumber style={{ width: '150px' }} className='site-input-right' placeholder={t('To')} />
                  </Form.Item>
                </Input.Group>
              </Form.Item>
              <Button htmlType='button' onClick={onReset} className='mt-30 ml-md'>
                {t('Reset')}
              </Button>
            </div>
          </Col>
        </Row>
        <Divider dashed className='mt-0' />
        <Row justify='end'>
          <Form.Item name='search'>
            <Input
              suffix={<SearchOutlined />}
              placeholder={t('Search')}
              style={{ width: 200 }}
              allowClear
              onChange={handleChange}
              maxLength={MAX_LENGTH_INPUT}
            />
          </Form.Item>
        </Row>
      </Form>
    </>
  );
};
export default Filters;
