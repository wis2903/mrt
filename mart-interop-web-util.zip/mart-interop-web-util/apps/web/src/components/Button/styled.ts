import { Button } from 'antd'
import styled from 'styled-components'
import { defaultTheme } from 'styles/defaultTheme.styles'

export const StyledButton = styled(Button)`
  & {
    display: inline-flex;
    align-items: center;
    background-color: #ffffff;

    &.ant-btn-primary {
      background: ${defaultTheme.colors.PRIMARY};

      &[disabled] {
        background: #f5f5f5;
      }
    }
  }
`
