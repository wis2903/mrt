import { Select, SelectProps } from 'antd';
import { useAppSelector } from 'store/hooks';
import { selectors } from 'store/masterData/slice';
import { MasterDataKey } from 'types/MasterDataKey';
import OptionItem from 'types/OptionItem';

type ComboBoxType = {
  type: MasterDataKey;
  value?: string;
};
const { Option } = Select;

const ComboBox = ({ type, value }: ComboBoxType & SelectProps) => {
  const data = useAppSelector(selectors.selectorByKey(type));
  const options = data?.map(
    (x) =>
      ({
        value: x.code,
        label: x.name
      } as OptionItem)
  );

  return (
    <Select labelInValue defaultValue={value} style={{ minWidth: '100px' }}>
      {options?.map((x) => (
        <Option key={x.value} value={x.value}>
          {x.label}
        </Option>
      ))}
    </Select>
  );
};
export default ComboBox;
