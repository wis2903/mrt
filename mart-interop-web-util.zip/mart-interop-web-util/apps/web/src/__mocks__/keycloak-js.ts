export const initMock = jest.fn().mockResolvedValue(true);
const mock = jest.fn().mockImplementation(() => {
  return {
    init: initMock,
    keycloak: null,
    logout: jest.fn().mockResolvedValue(true),
    onTokenExpired: jest.fn().mockResolvedValue(true),
    updateToken: jest.fn().mockResolvedValue(true),
    loadUserProfile: jest.fn().mockResolvedValue(true)
  };
});

export default mock;
