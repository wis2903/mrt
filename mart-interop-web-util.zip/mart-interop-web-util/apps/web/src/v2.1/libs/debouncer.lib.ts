interface IConfigs {
    isTriggerFirstTimeActionRightAway?: boolean;
}

class Debouncer {
    private _handler: number | undefined;
    private _timeout: number;
    private _isBlocking: boolean;
    private _configs: IConfigs | undefined;

    constructor(timeoutInMilliseconds: number, configs?: IConfigs) {
        this._handler = undefined;
        this._timeout = timeoutInMilliseconds;
        this._isBlocking = false;
        this._configs = configs;
    }

    public destroy = (): void => {
        clearTimeout(this._handler);
    };

    public execute = (callback?: Function): void => {
        if (!callback) return;

        if (!this._configs?.isTriggerFirstTimeActionRightAway) {
            this.destroy();
            this._handler = setTimeout(callback, this._timeout);
            return;
        }

        if (this._isBlocking) return;
        callback();

        this._isBlocking = true;
        const customCallback: Function = (): void => {
            this._isBlocking = false;
        };
        this._handler = setTimeout(customCallback, this._timeout);
    };
}

export default Debouncer;
