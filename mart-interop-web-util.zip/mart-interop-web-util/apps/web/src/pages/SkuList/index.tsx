import React from 'react';
import SkuDetail from 'types/SKUDetail';
import Filters from './Filters';
import useLocales from 'hooks/useLocales';
import Content from 'layouts/components/Content';
import PageHeader from 'layouts/components/PageHeader';
import { Empty, Table } from 'antd';
import { isNumber } from 'lodash';
import { selectors } from 'pages/AddSkuPage/slice';
import { FormattedNumber } from 'react-intl';
import { Link, useSearchParams } from 'react-router-dom';
import { PRICE_CONFIGURATION_URI } from 'routes/routes';
import { useAppSelector } from 'store/hooks';
import { OrdersStyled } from './styled';
import { useFetchSkuList } from './useFetchSkuList';
import type { ColumnsType } from 'antd/es/table';
import { AbilityContext } from 'casl/can';
import {
    DEFAULT_PAGE_NUMBER,
    DEFAULT_PAGE_SIZE,
    PAGE_SIZE_OPTIONS,
} from 'constants/common';
import { Action, Page } from 'constants/ability';

const SkuList: React.FC = () => {
    const { t } = useLocales();
    const [searchParams, setSearchParams] = useSearchParams();

    const ability = React.useContext(AbilityContext);
    const skuList = useAppSelector(selectors.selectSkuList);
    const pageNumber = parseInt(
        searchParams.get('pn') || DEFAULT_PAGE_NUMBER.toString()
    );
    const pageSize = parseInt(
        searchParams.get('ps') || DEFAULT_PAGE_SIZE.toString()
    );
    const { loading, total } = useFetchSkuList(pageNumber, pageSize);

    const columns: ColumnsType<SkuDetail> = [
        {
            title: t('sku.no'),
            dataIndex: 'no',
            key: 'no',
        },
        {
            title: t('sku.skuCode'),
            dataIndex: 'code',
            key: 'code',
            width: 180,
            render: (text, { id }) => <Link to={id.toString()}>{text}</Link>,
        },
        {
            title: t('sku.name'),
            key: 'name',
            dataIndex: 'name',
        },
        {
            title: t('sku.category'),
            key: 'category',
            dataIndex: 'category',
            render: (_, { categoryName, subcategoryName }) =>
                subcategoryName
                    ? `${categoryName} \\ ${subcategoryName}`
                    : categoryName,
        },
        {
            title: t('sku.brand'),
            key: 'brand',
            dataIndex: 'brandName',
        },
        {
            title: t('sku.uoms'),
            key: 'uoms',
            dataIndex: 'uoms',
            align: 'right',
            render: (_, { numberUom }) =>
                isNumber(numberUom) ? (
                    <FormattedNumber value={numberUom} />
                ) : undefined,
        },
        {
            title: t('sku.tax'),
            key: 'tax',
            dataIndex: 'tax',
            align: 'right',
        },
        {
            title: t('sku.price'),
            key: 'price',
            dataIndex: 'price',
            width: 200,
            align: 'right',
            render: (_, { id, minGrossPrice, maxGrossPrice }) => {
                const isAbleToEditPrice = ability.can(Action.Edit, Page.PriceConfiguration);

                const PriceWrapper = ({
                    children,
                }: {
                    children: React.ReactNode;
                }): JSX.Element => {
                    return (
                        <Link
                            to={`${PRICE_CONFIGURATION_URI}/${id}?viewMode=${
                              isAbleToEditPrice ? 'edit' : 'view'
                            }`}
                        >
                            {children}
                        </Link>
                    );
                };

                if (
                    isNumber(minGrossPrice) &&
                    isNumber(maxGrossPrice) &&
                    minGrossPrice === maxGrossPrice
                )
                    return (
                        <PriceWrapper>
                            <FormattedNumber value={minGrossPrice} />
                        </PriceWrapper>
                    );
                if (isNumber(minGrossPrice) && isNumber(maxGrossPrice))
                    return (
                        <PriceWrapper>
                            <FormattedNumber value={minGrossPrice} /> -{' '}
                            <FormattedNumber value={maxGrossPrice} />
                        </PriceWrapper>
                    );

                if (!isAbleToEditPrice) return ' ';

                return (
                    <Link to={`${PRICE_CONFIGURATION_URI}/${id}?viewMode=edit`}>
                        {t('sku.setPrice')}
                    </Link>
                );
            },
        },
    ];

    return (
        <OrdersStyled>
            <PageHeader title={t('sku.products')} />
            <Content>
                <Filters />
                <Table
                    locale={{
                        emptyText: (
                            <Empty
                                image={Empty.PRESENTED_IMAGE_SIMPLE}
                                description={t('common.No Data')}
                            />
                        ),
                    }}
                    loading={loading}
                    columns={columns}
                    dataSource={skuList?.map((sku, index) => ({
                        ...sku,
                        no: (index % pageSize) + 1,
                    }))}
                    rowKey={'id'}
                    pagination={{
                        total,
                        showTotal: (_total, range) =>
                            t('common.message.showingFromTo', {
                                from: range[0].toString(),
                                to: range[1].toString(),
                                total: _total.toString(),
                            }),
                        pageSize: pageSize,
                        current: pageNumber,
                        showLessItems: true,
                        hideOnSinglePage:
                            !!total && total <= PAGE_SIZE_OPTIONS[0],
                        pageSizeOptions: PAGE_SIZE_OPTIONS,
                        onChange: (_pageNumber, _pageSize) => {
                            searchParams.set('pn', _pageNumber.toString());
                            searchParams.set('ps', _pageSize.toString());
                            setSearchParams(searchParams);
                        },
                    }}
                />
            </Content>
        </OrdersStyled>
    );
};

export default SkuList;
