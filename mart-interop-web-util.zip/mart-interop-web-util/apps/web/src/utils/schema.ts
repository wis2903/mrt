import { intl } from 'containers/LanguageProvider'

export const genRequiredError = (names: Array<string>): { [key: string]: string } =>
  names.reduce((acc: { [key: string]: string }, name) => {
    acc[name] = intl.formatMessage({ id: 'field_required' }, { name: intl.formatMessage({ id: name }) })
    return acc
  }, {})
