import { prepareGetSkuListParams } from 'pages/SkuList/helpers';
import { GetSkuListParams, UpdatePriceConfigApi } from 'types/SKUDetail';
import apiClient from './apiClient';
import { CREATE_SKU, DELETE_SKU, GET_SKU, SELLING_PRICE, GET_SKU_LIST, UPDATE_SKU, SKU_CONFIGURATIONS, GET_SKU_LIST_V2 } from './apiUrl';

export interface CreateSkuParams {
  name?: string;
  description: string;
  countryId: number | string;
  tax: number;
  categoryId: number | string;
  subcategoryId: number | string;
  brandId: number | string;
  usageDays: number | string;
  configurations: {
    name?: string;
    quantity?: number;
    grossWeight?: number;
    netWeight?: number;
    volume?: number;
    isPrimary?: boolean;
    imageUrls?: string[];
  }[];
}

export interface UpdateSkuSellingPriceParams {
  skuConfigurationId: number;
  sellingPrices: UpdatePriceConfigApi[];
  skuId: string;
}

export interface GetSkuDetailParams {
  skuId: string;
  t: (key: string) => string;
}

export interface DeleteSkuParams {
  skuId: string;
  t: (key: string) => string;
}

export interface UpdateSkuParams extends CreateSkuParams, GetSkuDetailParams {}

export interface SourceOptionsParams {
  skuId: string;
  sourceList: string[];
}

export const createSku = (params: CreateSkuParams) => apiClient.post(CREATE_SKU, params);

export const getSkuDetail = (params: GetSkuDetailParams) => apiClient.get(`${GET_SKU}/${params.skuId}`);

export const updateSkuWithSource = (params: UpdateSkuParams, sourceParams: SourceOptionsParams) =>
  Promise.all([updateSku(params), updateSkuSource(sourceParams)]);
export const updateSku = (params: UpdateSkuParams) => {
  const { skuId, ...data } = params;
  return apiClient.put(`${UPDATE_SKU}\\${skuId}`, data);
};
export const updateSkuSource = (params: SourceOptionsParams) => {
  const { skuId, ...data } = params;
  return apiClient.put(`${UPDATE_SKU}\\${skuId}/display`, data);
};

export const deleteSku = (params: DeleteSkuParams) => apiClient.delete(`${DELETE_SKU}/${params.skuId}`);

export const updateSkuSellingPrice = (params: UpdateSkuSellingPriceParams) =>
  apiClient.put(`${SKU_CONFIGURATIONS}/${params.skuConfigurationId}/${SELLING_PRICE}`, params.sellingPrices);

export const getSkuList = (params: GetSkuListParams) => {
  return apiClient.post(GET_SKU_LIST, prepareGetSkuListParams(params));
};

export const getSkuListV2 = (params: GetSkuListParams) => {
  return apiClient.post(GET_SKU_LIST_V2, prepareGetSkuListParams(params));
};

export const validateBarcode = (params: { barcode: string | null; skuId?: number }) => {
  return apiClient.post(`${UPDATE_SKU}/validate-barcode`, params);
};

export const exportSKUs = () => {
  return apiClient.get(`${UPDATE_SKU}/export-file`, {responseType: 'blob'});
};
