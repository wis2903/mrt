import useLocales from 'hooks/useLocales'
import { useLocation } from 'react-router-dom'
import { ADD_SKU_URI, ORDERS_URI, PROMOTION_URI, SKUS_URI } from '../routes/routes'

const removeSlashFromURI = (obj: any) => Object.fromEntries(Object.entries(obj).map(([key, value]) => [key?.substring(1), value]))
const BREADCRUMB_TITLE_MAPPING = {
  [ADD_SKU_URI]: 'sku.addProductSku',
  [ORDERS_URI]: 'orders.title',
  [SKUS_URI]: 'sku.skuList',
  'order-activity-logs': 'orders.orderActivityLogs',
  [PROMOTION_URI]: 'Promo'
}

const breadcrumbTitleMapping = removeSlashFromURI(BREADCRUMB_TITLE_MAPPING)

const keys = Object.keys(breadcrumbTitleMapping)

type Pathname = keyof typeof breadcrumbTitleMapping

export const useBreadcrumbRoutes = () => {
  const { t } = useLocales()
  const location = useLocation()
  const pathSnippets = location.pathname.split('/').filter((i) => i)

  const routes = pathSnippets.map((path, index) => {
    const url = `${pathSnippets.slice(0, index + 1).join('/')}`

    return {
      path: url,
      breadcrumbName: keys.includes(path) ? t(breadcrumbTitleMapping[path as Pathname] as string) : path
    }
  })

  return [{ path: '', breadcrumbName: t('common.home') }].concat(routes)
}
