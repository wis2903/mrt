import { useState, useCallback, useEffect, useMemo } from 'react'
export enum RequestStatus {
  Idle = 'idle',
  Pending = 'pending',
  Success = 'success',
  Error = 'error'
}
export const useAsync = (asyncFunction: (params?: any) => Promise<any>, immediate = true, initValue: any = null) => {
  const [status, setStatus] = useState(RequestStatus.Idle)
  const [value, setValue] = useState(initValue)
  const [error, setError] = useState(null)
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const _initialValue = useMemo(() => initValue, [JSON.stringify(initValue)])
  const execute = useCallback(
    (_params?: any) => {
      setStatus(RequestStatus.Pending)
      setValue(_initialValue)
      setError(null)
      return asyncFunction(_params)
        .then((response) => {
          setValue(response)
          setStatus(RequestStatus.Success)
        })
        .catch((_error) => {
          setError(_error)
          setStatus(RequestStatus.Error)
        })
    },
    [_initialValue, asyncFunction]
  )
  useEffect(() => {
    if (immediate) {
      execute()
    }
  }, [execute, immediate])
  return { execute, status, value, error }
}
