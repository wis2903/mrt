import { printOrder, exportOrders } from './orders'
jest.mock('./orders', () => {
  return {
    ...jest.requireActual('./orders'),
    printOrder: jest.fn(() => 'print'),
    exportOrders: jest.fn(() => [])
  }
})
describe('printOrder', () => {
  it('Should export data', async () => {
    const result = printOrder('testId')
    expect(result).toEqual('print')
    expect(printOrder).toBeCalledWith('testId')
  })
})
describe('exportOrders', () => {
  it('Should export data', async () => {
    const result = exportOrders({})
    expect(result).toEqual([])
    expect(exportOrders).toBeCalledWith({})
  })
})
