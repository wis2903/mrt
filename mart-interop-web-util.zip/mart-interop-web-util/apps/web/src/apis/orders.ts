import { apiClientV2 } from './apiClient';
import { prepareGetOrdersParams } from 'pages/Orders/helpers';
import { ChangeOrderStatusParams, GetOrdersParams } from 'types/Orders';
import { GET_ORDERSV2, ORDERS, ORDERSV2 } from './apiUrl';

export const getOrders = (params: GetOrdersParams) => {
    return apiClientV2.post(GET_ORDERSV2, prepareGetOrdersParams(params));
};

export const getOrder = (id: string) => {
    return apiClientV2.get(`${ORDERSV2}/${id}`);
};

export const printOrder = (id: string) => {
    return apiClientV2.get(`${ORDERS}/print?orderId=${id}`);
};

export const exportOrders = (params: GetOrdersParams) => {
    return apiClientV2.post(
        `${ORDERS}/export`,
        prepareGetOrdersParams(params),
        {
            responseType: 'blob',
        }
    );
};

export const exportOrdersV2 = (params: GetOrdersParams) => {
    return apiClientV2.post(
        `${ORDERSV2}/export`,
        prepareGetOrdersParams(params),
        { responseType: 'blob' }
    );
};

export const createDeliveryOrder = ({
    id,
    action,
    reason,
}: ChangeOrderStatusParams) => {
    const putData: Record<string, unknown> = { action };
    if (reason) putData.cancellationReason = reason;
    apiClientV2.put(`${ORDERSV2}/${id}`, putData);
};

export const createDeliveryOrderAsync = ({
    id,
    action,
    reason,
}: ChangeOrderStatusParams) => {
    const putData: Record<string, unknown> = { action };
    if (reason) putData.cancellationReason = reason;
    return apiClientV2.put(`${ORDERSV2}/${id}`, putData);
};
