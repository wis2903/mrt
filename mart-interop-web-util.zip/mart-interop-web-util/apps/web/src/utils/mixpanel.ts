import mixpanel, { Callback, RequestOptions } from 'mixpanel-browser'
import { MixpanelEvent, MixpanelEventProperty } from '../constants/mixpanelEvents'
import { Order, OrderDetail } from 'types/Orders'
import { genOrderNumber } from 'pages/Orders/helpers'

export const initMixpanel = () => {
  mixpanel.init(process.env.VITE_MIXPANEL_TOKEN || '', {
    debug: process.env.NODE_ENV === 'development'
  })
}
export const trackOrdersMenuClicked = () => {
  mixpanel.track(MixpanelEvent.CLICKED_ORDER_LIST)
}
export const trackOrdersDetailClicked = (order: Order) => {
  mixpanel.track(MixpanelEvent.CLICKED_ORDER_DETAIL, {
    [MixpanelEventProperty.ORDER_ID]: genOrderNumber(order),
    [MixpanelEventProperty.PROVINCE]: order?.shippingAddressDetails?.shippingProvince
  })
}
export const trackOrderConfirmed = (order: Order | OrderDetail) => {
  mixpanel.track(MixpanelEvent.CONFIRMED_ORDER, {
    [MixpanelEventProperty.ORDER_ID]: genOrderNumber(order),
    [MixpanelEventProperty.PROVINCE]: order?.shippingAddressDetails?.shippingProvince,
    [MixpanelEventProperty.PAGE]: location?.pathname
  })
}
export const trackOrderClickActionMenu = (order: Order) => {
  mixpanel.track(MixpanelEvent.CLICKED_ON_ACTION_MENU, {
    [MixpanelEventProperty.ORDER_ID]: genOrderNumber(order),
    [MixpanelEventProperty.PROVINCE]: order?.shippingAddressDetails?.shippingProvince,
    [MixpanelEventProperty.PAGE]: location?.pathname
  })
}
