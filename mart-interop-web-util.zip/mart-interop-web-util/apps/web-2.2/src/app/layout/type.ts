export interface ILayoutProps {
    isPrivate?: boolean;
    hasSidebar?: boolean;
    children?: React.ReactNode;
    autoHeight?: boolean;
}
