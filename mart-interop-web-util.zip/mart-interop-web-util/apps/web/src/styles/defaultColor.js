module.exports = {
  '@primary-color': '#c31424',
  '@black': 'black',
  '@blue-base': '#6606E0',
  '@red-base': '#EE002A',
  '@green-base': '#38CB89',
  '@pink-base': '#EB5757',
  '@yellow-base': '#DAA608',
  '@link-color': '#EE002A',
  '@text-color': '#323B4B',
  '@text-color-secondary': '#4E5D78'
}
