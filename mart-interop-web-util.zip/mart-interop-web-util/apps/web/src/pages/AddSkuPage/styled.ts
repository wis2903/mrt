import { Table } from 'antd';
import styled from 'styled-components';

export const ProvinceItemStyled = styled.div`
  .ant-form-item {
    margin-bottom: 0;
  }

  border-bottom: 1px dashed #ddd;
  margin-bottom: 32px;
`;

export const TableNoBorder = styled(Table)`
  .ant-table-thead > tr > th {
    background: none;
    border-bottom: none;

    &:before {
      background-color: none;
    }
  }
  .ant-table-tbody > tr > td {
    border: none;
  }
`;
