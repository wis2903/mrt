import useLocales from 'hooks/useLocales';
import Content from 'layouts/components/Content';
import PageHeader from 'layouts/components/PageHeader';

const HomePage = () => {
  const { t } = useLocales();
  // RENDER
  return (
    <Content>
      <PageHeader title={t('common.home')} />
    </Content>
  );
};
export default HomePage;
