import styled from 'styled-components';

import { Layout } from 'antd';
import { defaultTheme } from 'styles/defaultTheme.styles';
import { getGlobalDesignToken } from 'v2/kit/design-tokens';

export const NVLayout = styled(Layout)`
    .content-layout {
        background: ${defaultTheme.colors.BACKGROUND};
    }
    aside,
    ul.ant-menu {
        background: ${defaultTheme.colors.PRIMARY_BROWN} !important;
    }

    .ant-menu-dark.ant-menu-dark:not(.ant-menu-horizontal) .ant-menu-item a {
        color: ${getGlobalDesignToken('color.grey-3')};
        font-family: NotoSans;
        font-weight: 500;
    }

    .ant-menu-dark.ant-menu-dark:not(.ant-menu-horizontal) .ant-menu-item.ant-menu-item-selected {
        background: rgba(256, 256, 256, 0.1) !important;

        a {
            color: #ffffff;
        }
    }
`;
