import { fm } from '../../../../../web-2.2/src/app/provider/feature';
import { FeatureCodeEnum } from '../../../../../web-2.2/src/app/provider/feature/type';

import {
    PromotionCategoryEnum,
    PromotionDiscountTypeEnum,
    PromotionStatusEnum,
    PromotionTypeEnum,
} from '../@types/enum.type';

export const PROMOTION_TYPE_TO_STRING = {
    [PromotionTypeEnum.CartAmountFlat]: 'promotion.category.orderDiscount',
    [PromotionTypeEnum.CartAmountPercentage]: 'promotion.category.orderDiscount',
    [PromotionTypeEnum.ComboFlat]: 'promotion.category.comboDiscount',
    [PromotionTypeEnum.ComboItemFlat]: 'promotion.category.comboDiscount',
    [PromotionTypeEnum.ComboPercentage]: 'promotion.category.comboDiscount',
    [PromotionTypeEnum.ComboItemPercent]: 'promotion.category.comboDiscount',
    [PromotionTypeEnum.MoqItemFlat]: 'promotion.category.moqDiscount',
    [PromotionTypeEnum.MoqItemPercentage]: 'promotion.category.moqDiscount',
    [PromotionTypeEnum.Coupon]: 'promotion.category.coupon',
    [PromotionTypeEnum.MovSkuPercentage]: 'promotion.category.movSku',
    [PromotionTypeEnum.MovSkuDiscountAmount]: 'promotion.category.movSku',
    [PromotionTypeEnum.DynamicBundlingFlat]: 'promotion.category.comd',
    [PromotionTypeEnum.DynamicBundlingItemFlat]: 'promotion.category.comdItems',
    [PromotionTypeEnum.GroupDiscountPercentage]: 'promotion.category.group',
    [PromotionTypeEnum.GroupItemDiscountAmount]: 'promotion.category.group',
    [PromotionTypeEnum.GroupDiscountV2]: 'promotion.category.groupV2',
    [PromotionTypeEnum.MovcataArchived]: 'promotion.category.movcataArchived',
};

export const PROMOTION_STATUS_TO_STRING = {
    [PromotionStatusEnum.active]: 'common.label.active',
    [PromotionStatusEnum.inactive]: 'common.label.inactive',
    [PromotionStatusEnum.expired]: 'common.label.expired',
};

export const PROMOTION_CATEGORY = (() => {
    const cats = [
        {
            name: PROMOTION_TYPE_TO_STRING[PromotionTypeEnum.CartAmountFlat],
            value: PromotionCategoryEnum.order,
        },
        {
            name: PROMOTION_TYPE_TO_STRING[PromotionTypeEnum.ComboFlat],
            value: PromotionCategoryEnum.combo,
        },
        {
            name: PROMOTION_TYPE_TO_STRING[PromotionTypeEnum.MoqItemFlat],
            value: PromotionCategoryEnum.moq,
        },
        {
            name: PROMOTION_TYPE_TO_STRING[PromotionTypeEnum.MovSkuPercentage],
            value: PromotionCategoryEnum.movsku,
        },
        {
            name: PROMOTION_TYPE_TO_STRING[PromotionTypeEnum.DynamicBundlingFlat],
            value: PromotionCategoryEnum.comd,
        },
    ];

    if (fm.enabled(FeatureCodeEnum.promoDynamicBundlingBySKU)) {
        cats.push({
            name: PROMOTION_TYPE_TO_STRING[PromotionTypeEnum.DynamicBundlingItemFlat],
            value: PromotionCategoryEnum.comdItems,
        });
    }

    cats.push({
        name: PROMOTION_TYPE_TO_STRING[PromotionTypeEnum.GroupDiscountPercentage],
        value: PromotionCategoryEnum.group,
    });
    if (fm.enabled(FeatureCodeEnum.groupDiscountV2)) {
        cats.push({
            name: PROMOTION_TYPE_TO_STRING[PromotionTypeEnum.GroupDiscountV2],
            value: PromotionCategoryEnum.groupV2,
        });
    }
    return cats;
})();

export const PROMOTION_CATEGORY_ALT = [
    ...PROMOTION_CATEGORY,
    {
        name: PROMOTION_TYPE_TO_STRING[PromotionTypeEnum.MovcataArchived],
        value: PromotionCategoryEnum.movcataArchived,
    },
];

export const PROMOTION_STATUS = [
    {
        name: 'promotion.status.activePromos',
        value: PromotionStatusEnum.active,
    },
    {
        name: 'promotion.status.inactivePromos',
        value: PromotionStatusEnum.inactive,
    },
    {
        name: 'promotion.status.expiredPromos',
        value: PromotionStatusEnum.expired,
    },
];

export const CURRENTLY_SUPPORTED_PROMOTION_TYPE = [
    PromotionTypeEnum.CartAmountPercentage,
    PromotionTypeEnum.CartAmountFlat,
    PromotionTypeEnum.ComboFlat,
    PromotionTypeEnum.ComboItemFlat,
    PromotionTypeEnum.MoqItemPercentage,
    PromotionTypeEnum.MoqItemFlat,
    PromotionTypeEnum.MovSkuPercentage,
    PromotionTypeEnum.MovSkuDiscountAmount,
    PromotionTypeEnum.DynamicBundlingFlat,
    PromotionTypeEnum.DynamicBundlingItemFlat,
    PromotionTypeEnum.GroupDiscountPercentage,
    PromotionTypeEnum.GroupItemDiscountAmount,
    PromotionTypeEnum.GroupDiscountV2,
    PromotionTypeEnum.MovcataArchived,
];

export const PROMOTION_DISCOUNT_TYPE_TO_STRING = {
    [PromotionDiscountTypeEnum.setDiscountPercent]: 'promotion.formula.setDiscountPercent',
    [PromotionDiscountTypeEnum.setPriceAfterDiscount]: 'promotion.formula.setPriceAfterDiscount',
};
