export interface InventoryFilter {
    page: number;
    size: number;
    isGetAll: boolean;
    warehouseId?: number;
    greaterThanOnhand?: number;
    lessThanOnhand?: number;
    equalOnhand?: number;
    greaterThanOnhold?: number;
    lessThanOnhold?: number;
    equalOnhold?: number;
    greaterThanAvailable?: number;
    lessThanAvailable?: number;
    equalAvailable?: number;
    typeOfOnhandQuantity?: string;
    typeOfAvailableQuantity?: string;
    textSearch?: string;
}
export interface Inventory {
    id: number;
    skuId: number;
    skuCode: string;
    skuName: string;
    primaryUomName: string;
    barcode: string;
    warehouseId: number;
    onhandQuantity: number;
    onholdQuantity: number;
    availableQuantity: number;
}

export enum TypeOfQuantity {
    GreaterThan0 = 'GreaterThan0',
    EqualTo0 = 'EqualTo0',
}

export const TYPE_OF_QUANTITY = [
    {
        key: TypeOfQuantity.GreaterThan0,
        value: 'Greater than 0',
    },
    {
        key: TypeOfQuantity.EqualTo0,
        value: 'Equal to 0',
    },
];
