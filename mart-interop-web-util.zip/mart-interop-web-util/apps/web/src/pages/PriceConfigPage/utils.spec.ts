import { mockProvinces } from './mockProvinces';
import { prepareTableData } from './utils';

describe('prepareTableData', () => {
  it('Should return []', () => {
    expect(prepareTableData([{ provinceId: '1' }], { region: '1' }, mockProvinces)).toEqual([]);
  });
  it('Should return result', () => {
    expect(
      prepareTableData(
        [{ provinceId: '999', isNew: true, province: { value: 'test', label: 'test', region: 'test' } }],
        { region: '1' },
        mockProvinces
      )
    ).toBeTruthy();
  });
  it('Should return result', () => {
    expect(prepareTableData([{ provinceId: '999', isNew: true, provinceName: 'test' }], { region: '1' }, mockProvinces)).toBeTruthy();
  });
});
