import { InputNumber as AntdInput, InputNumberProps } from 'antd';
import { InputStyled } from './styled';

export interface InputComponentProps extends InputNumberProps {
  suffix?: string;
}

const InputNumber: React.FC<InputComponentProps> = ({ suffix, ...props }) => {
  return (
    <InputStyled suffix={suffix}>
      <AntdInput controls={false} {...props} />
      <div className='suffix'>{suffix}</div>
    </InputStyled>
  );
};

export default InputNumber;
