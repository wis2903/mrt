import { IMasterData } from 'v2/app/@types/data.type';
import {
    AmastUomEnum,
    LangEnum,
    MonthEnEnum,
    ReportTypeEnum,
    WeekDayEnEnum,
} from '../@types/enum.type';

export const EMPTY_MASTER_DATA: IMasterData = {
    provinces: [],
    countries: [],
    categories: [],
    warehouses: [],
    brands: [],
};

export const EMPTY_INVENTORY = {
    onhand: 0,
    onhold: 0,
    available: 0,
};

export const DEFAULT_PAGINATION_SIZING = 10;

export const STORAGE_KEY = {
    lang: 'lang',
    token: 'kc_token',
    refreshToken: 'kc_refreshToken',
};

export const DEFAULT_LANG = LangEnum.en;

export const WEEKDAYS = [
    WeekDayEnEnum.sunday,
    WeekDayEnEnum.monday,
    WeekDayEnEnum.tuesday,
    WeekDayEnEnum.wednesday,
    WeekDayEnEnum.thursday,
    WeekDayEnEnum.friday,
    WeekDayEnEnum.saturday,
];

export const MONTHS = [
    MonthEnEnum.january,
    MonthEnEnum.february,
    MonthEnEnum.march,
    MonthEnEnum.april,
    MonthEnEnum.may,
    MonthEnEnum.june,
    MonthEnEnum.july,
    MonthEnEnum.august,
    MonthEnEnum.september,
    MonthEnEnum.october,
    MonthEnEnum.november,
    MonthEnEnum.december,
];

export const MONTHS_SHORT = [
    MonthEnEnum.jan,
    MonthEnEnum.feb,
    MonthEnEnum.mar,
    MonthEnEnum.apr,
    MonthEnEnum['may-s'],
    MonthEnEnum.jun,
    MonthEnEnum.jul,
    MonthEnEnum.aug,
    MonthEnEnum.sep,
    MonthEnEnum.oct,
    MonthEnEnum.nov,
    MonthEnEnum.dec,
];

export const DEFAULT_SUPPORT_DISTANCE_FROM_CURRENT_YEAR = 30;

export const CURRENCY: Record<string, string> = {
    VN: '₫',
    MY: ' RM',
};

export const CURRENCY_ISO_TO_SYMBOL: Record<string, string> = {
    VND: '₫',
    MYR: ' RM',
};

export const AMAST_UOM_CODE = [
    {
        label: 'Unit',
        value: AmastUomEnum.un,
    },
    {
        label: 'Carton',
        value: AmastUomEnum.ct,
    },
    {
        label: 'Pack',
        value: AmastUomEnum.pk,
    },
    {
        label: 'Stick',
        value: AmastUomEnum.stk,
    },
    {
        label: 'Bag',
        value: AmastUomEnum.bg,
    },
    {
        label: 'Piece',
        value: AmastUomEnum.pc,
    },
    {
        label: 'Gram',
        value: AmastUomEnum.gm,
    },
    {
        label: 'Each',
        value: AmastUomEnum.ea,
    },
];

export const REPORT_TYPE = [
    {
        label: 'report.type.order',
        value: ReportTypeEnum.order,
    },
    {
        label: 'report.type.inventory',
        value: ReportTypeEnum.inventory,
    },
    {
        label: 'report.type.sku',
        value: ReportTypeEnum.sku,
    },
];

export const COUNTRY_CODE_TO_TRANSLATION_KEY: Record<string, string> = {
    vn: 'common.country.vn',
    my: 'common.country.my',
};

export const NO_PHOTO_IMAGE_URL = 'https://interop.ninjamart.com/assets/no-photo.jpeg';

export const URL_REGEX =
    /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)/;
export const CX_URL_REGEX = /^(cxApp:\/\/co.ninjavan.ninjaMartLoyaltyApp\/spendAndWin)$/;

export const SOURCE_MAPPING: { [key: string]: string } = {
    '5': 'AMAST',
    '6': 'CX',
    '4': 'Haravan',
};

export const BATM_BRAND_NAME_IN_LOWER_CASE = 'batm';

export const PRODUCT_TIERS = ['A', 'B', 'C', 'D'];
