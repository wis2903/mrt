import { Tag } from 'antd';
import { LOG_STATUS_MASTER_DATA } from 'constants/logs';
import useLocales from 'hooks/useLocales';

export const Status = ({ syncStatus, isTag }: { syncStatus: string; isTag: boolean }) => {
  const { t } = useLocales();
  const _syncStatus = LOG_STATUS_MASTER_DATA.find((status) => status.code === syncStatus);
  return (
    <Tag color={_syncStatus?.color} style={isTag ? {} : { background: 'transparent', border: 'none', fontSize: '14px' }}>
      {_syncStatus?.name ? t(_syncStatus?.name) : ''}
    </Tag>
  );
};
