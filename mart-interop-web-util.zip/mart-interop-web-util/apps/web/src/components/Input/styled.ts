import styled from 'styled-components';
import { InputComponentProps } from '.';

export const InputStyled = styled.div<InputComponentProps>`
  ${(props) =>
    props.suffix &&
    `
    display: flex; align-items: center;gap: 16px;
    .suffix {
        white-space: nowrap;
    }
  `}
`;
