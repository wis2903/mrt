import userEvent from '@testing-library/user-event';
import { fireEvent, renderWithProvider, screen, waitFor } from 'test';
import * as slice from './slice';

import Component from '.';
import { mockOrder } from './mockData';

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useParams: () => {
    return {
      orderId: '596'
    };
  }
}));

describe('Render component', () => {
  afterEach(() => {
    jest.clearAllMocks();
    jest.restoreAllMocks();
  });

  it('should render without crash', () => {
    const { container } = renderWithProvider(<Component />);

    expect(container).toBeTruthy();
  });

  it('should back to list order when cancel', async () => {
    jest.spyOn(slice.selectors, 'selectOrder').mockReturnValue(mockOrder);
    const { container } = renderWithProvider(<Component />);

    await waitFor(() => screen.getByTestId('button-cancel'));
    const cancelButton = screen.getByTestId('button-cancel');
    await waitFor(async () => await userEvent.click(cancelButton));

    expect(container).toBeTruthy();
  });

  it('should back to list order when action', async () => {
    jest.spyOn(slice.selectors, 'selectOrder').mockReturnValue(mockOrder);
    const { container } = renderWithProvider(<Component />);

    await waitFor(() => screen.getByTestId('select-onChange'));
    const selectAction = screen.getByTestId('select-onChange');
    await waitFor(async () => await userEvent.click(selectAction));

    expect(container).toBeTruthy();
  });

  it('should have Confirm action when order status is CREATE', async () => {
    jest.spyOn(slice.selectors, 'selectOrder').mockReturnValue(mockOrder);
    renderWithProvider(<Component />);

    expect(screen.getByTitle('CONFIRM')).toBeTruthy();
  });
  it('should close popup when click cancel', async () => {
    jest.spyOn(slice.selectors, 'selectOrder').mockReturnValue(mockOrder);
    const { container } = renderWithProvider(<Component />);
    const modeSelect = screen.getByTitle('CONFIRM');
    fireEvent.mouseDown(modeSelect);
    await waitFor(async () => await userEvent.click(modeSelect));
    await waitFor(() => screen.getByText(/do you want to continue\?/i));
    const cancel = screen.getByText('Cancel');
    await waitFor(async () => await userEvent.click(cancel.parentElement as any));
    expect(container).toBeTruthy();
  });
  it('should execute when click OK', async () => {
    jest.spyOn(slice.selectors, 'selectOrder').mockReturnValue(mockOrder);
    const { container } = renderWithProvider(<Component />);
    const modeSelect = screen.getByTitle('CONFIRM');
    fireEvent.mouseDown(modeSelect);
    await waitFor(async () => await userEvent.click(modeSelect));
    await waitFor(() => screen.getByText(/do you want to continue\?/i));
    const cancel = screen.getByText('OK');
    await waitFor(async () => await userEvent.click(cancel.parentElement as any));
    expect(container).toBeTruthy();
  });
  it('Should show "cancel" when status "placed"', async () => {
    jest.spyOn(slice.selectors, 'selectOrder').mockReturnValue({ ...mockOrder, currentStatus: 'PLACED' });
    const { container } = renderWithProvider(<Component />);
    expect(container).toBeTruthy();
  });
  it('Should show "cancel" when status "processing"', async () => {
    jest.spyOn(slice.selectors, 'selectOrder').mockReturnValue({ ...mockOrder, currentStatus: 'PROCESSING' });
    const { container } = renderWithProvider(<Component />);
    expect(container).toBeTruthy();
  });
  it('Should show "cancel" and "complete" when status "delivery"', async () => {
    jest.spyOn(slice.selectors, 'selectOrder').mockReturnValue({ ...mockOrder, currentStatus: 'DELIVERY' });
    const { container } = renderWithProvider(<Component />);
    expect(container).toBeTruthy();
  });
});
