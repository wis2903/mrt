import env from '../env.json';

import { PandaEvent } from '../../core/shared/event';
import { APIServiceEnum, EventTypeEnum, StorageKeyEnum } from '../shared/type';
import { SingletonRefreshTokenRequestInstance } from './token/refresh';

import {
    IResponse,
    PandaHTTPRequest,
    RequestConfigTypeEnum,
    RequestMethodEnum,
    TransformTypeEnum,
} from '../../core/shared/lib/request';

interface IHTTPRequestWithAuthorizationConstructor {
    url?: string;
    method?: RequestMethodEnum;
    params?: Record<string, unknown>;
    body?: FormData | URLSearchParams;
    transform?: TransformTypeEnum;
    timeoutInMilliseconds?: number;
    service?: APIServiceEnum;
    notifyAfterCall?: boolean;
    notifyAfterCallIfError?: boolean;
    notifyAfterCallIfSuccess?: boolean;
}
export interface IRequestWithPaginationParams {
    page: number;
    size: number;
}
export interface IRequestWithPaginationResponse {
    total: number;
    records: unknown[];
}

export class HTTPRequestWithAuthorization extends PandaHTTPRequest {
    private _retried401Count = 0;
    private _retriedNone401Count = 0;
    private _noRetry = false;

    constructor(props?: IHTTPRequestWithAuthorizationConstructor) {
        super();
        const {
            url,
            method,
            params,
            body,
            transform,
            timeoutInMilliseconds,
            service,
            notifyAfterCall,
            notifyAfterCallIfError,
            notifyAfterCallIfSuccess,
        } = props || {};
        this._noRetry = !!notifyAfterCallIfError || !!notifyAfterCall;
        this.setBaseURL(Object(env)[service || APIServiceEnum.mart]);
        this.setHeader(
            'Authorization',
            `Bearer ${localStorage.getItem(StorageKeyEnum.accessToken)}`
        );
        this.setConfig(RequestConfigTypeEnum.transformResponse, TransformTypeEnum.camelCase);
        if (transform) this.setConfig(RequestConfigTypeEnum.transformRequest, transform);
        if (timeoutInMilliseconds) this.setTimeout(timeoutInMilliseconds);
        if (url) this.extendsBaseURL(url);
        if (method) this.setMethod(method);
        if (body) this.setBody(body);
        if (params) this.setParams(Object(params));

        this.onCompleteCall((response): void => {
            if (!response.error && (notifyAfterCall || notifyAfterCallIfSuccess)) {
                PandaEvent.instance.triggerEventListeners(EventTypeEnum.responseSuccess);
                return;
            }

            if (response.error && (notifyAfterCall || notifyAfterCallIfError)) {
                PandaEvent.instance.triggerEventListeners(
                    EventTypeEnum.responseError,
                    response.data
                );
            }
        });
    }

    async call(): Promise<IResponse> {
        const response = await super.call();
        if (response.status === 401 && this._retried401Count < 1) {
            const { accessToken, refreshToken } = await SingletonRefreshTokenRequestInstance.call();
            if (!accessToken || !refreshToken) return response;
            this.setHeader('Authorization', `Bearer ${accessToken}`);
            this._retried401Count++;
            return await this.call();
        }
        if (
            !this._noRetry &&
            response.error &&
            response.status !== 401 &&
            this._retriedNone401Count < 4
        ) {
            this._retriedNone401Count++;
            return await this.call();
        }
        return response;
    }
}

export class BaseRequest {
    protected _instance: HTTPRequestWithAuthorization;
    protected _params: unknown;

    constructor(params?: unknown) {
        this._instance = new HTTPRequestWithAuthorization();
        this._params = params;
    }

    get instance(): HTTPRequestWithAuthorization {
        return this._instance;
    }

    get params(): unknown {
        return this._params;
    }

    public get aborted(): boolean {
        return this._instance.aborted;
    }

    public abort(): void {
        this._instance.abort();
    }

    async call(): Promise<unknown> {
        const response = await this._instance.call();
        return response;
    }
}

export class RequestWithPagination extends BaseRequest {
    constructor(params: IRequestWithPaginationParams) {
        super(params);
        this._params = params;
    }

    get params(): IRequestWithPaginationParams {
        return this._params as IRequestWithPaginationParams;
    }

    async call(): Promise<IRequestWithPaginationResponse> {
        return {
            total: 0,
            records: [],
        };
    }
}
