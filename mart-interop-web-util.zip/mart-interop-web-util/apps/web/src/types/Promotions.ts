import { PromotionStatus, InactivePromotionSubStatus } from '../constants/promotions';
import { Moment } from 'moment';

export interface CreatePromotionParams {
    name: string;
    dealType: number;
    provinceId: number;
    countryId: number;
    startDate: Moment;
    endDate: Moment;
    criteria: Record<string, unknown>;
    applyLimit?: number;
    cxMeta?: string;
}

export interface ExtendPromotionParams {
    endDate: string;
    applyLimit?: number;
    cxMeta?: string;
}

export interface GetPromotionsParams {
    page?: number;
    size?: number;
    search?: PromotionSearchForm;
}
export interface PromotionSearchApi {
    page?: number;
    size?: number;
    province_id?: string;
    status?: number;
    sub_status?: number;
    sort?: string;
}
export interface PromotionSearchForm {
    provinceId?: string;
    status?: number;
    subStatus?: number;
    sort?: string;
}
export interface Promotion {
    id: number;
    name: string;
    dealType: number;
    startDate: string;
    endDate: string;
    provinceId: number;
    countryId: number;
    status: PromotionStatusType;
    subStatus: Array<number>;
    isActive: boolean;
    createdAt: string;
}

export interface OrderDetail {
    orderId: number;
    haravanOrderNumber: string;
    source: string;
    total: number;
    createdDate: string;
    currentStatus: PromotionStatusType;
    warehouseId: number;
    countryId: number;
    status: string;
    warehouse: string;
    currency: string;
    totalAmount: number;
    discountAmount: number;
    taxAmount: number;
    doNumber: number;
    createdBy: string;
    lastModifiedBy: string;
    lastModifiedDate: string;
    paymentMethod: string;
    createdByUserName: string;
    createdByUserPhone: string;
    note: string;
    promotionCode: string;
    receiverDetails: {
        receiverName: string;
        receiverPhone: string;
    };
    shippingAddressDetails: {
        shippingCountry: string;
        shippingProvince: string;
        shippingDistrict: string;
        shippingAddress: string;
        shippingWard: string;
        shippingCountryId: string;
        shippingProvinceId: string;
        shippingDistrictId: string;
        shippingWardId: string;
    };
    itemListDetail: OrderItem[];
}
export interface OrderItem {
    orderItemId: number;
    userOrderId: string;
    price: number;
    salePrice: number;
    quantity: number;
    createdBy: string;
    lastModifiedBy: string;
    createdDate: string;
    lastModifiedDate: string;
    skuDetails: {
        skuId: number;
        skuCode: string;
        skuName: string;
        description: string;
        skuConfigurationId: number;
        skuConfigurationName: string;
        imageUrl: string;
        brandDetails: {
            brandName: string;
            brandId: string;
        };
    };
}

export type PromotionStatusType = PromotionStatus.Active | PromotionStatus.Inactive;
export type InactivePromotionSubStatusType =
    | InactivePromotionSubStatus.Expired
    | InactivePromotionSubStatus.SoldOut
    | InactivePromotionSubStatus.Discontinued;
export type OrderAction = 'CONFIRM' | 'CANCEL' | 'COMPLETE';

export interface ChangeOrderStatusParams {
    id: string | number;
    action: OrderAction;
    callback?: any;
    callbackFinally?: any;
}
