export enum InventoryType {
  PurchaseOrder = 'CREATE_PO',
  Sell = 'CREATE_SO',
  Delivery = 'ALLOCATE_DO',
  RemovePO = 'DELETE_PO',
  CancelOrder = 'CANCEL_ORDER',
  CancelPlacedSO = 'CANCEL_PLACED_SO',
  CancelProcessingSO = 'CANCEL_PROCESSING_SO'
}
export const CANCEL_ORDER_OPTION = ['CANCEL_PLACED_SO', 'CANCEL_PROCESSING_SO'];
export const INVENTORY_TYPES = [
  {
    key: InventoryType.PurchaseOrder,
    value: 'Purchase Order'
  },
  {
    key: InventoryType.Sell,
    value: 'Sell'
  },
  {
    key: InventoryType.Delivery,
    value: 'Delivery'
  },
  {
    key: InventoryType.RemovePO,
    value: 'Remove PO'
  },
  {
    key: InventoryType.CancelOrder,
    value: 'Cancel Order'
  }
];

export const INVENTORY_TYPES_FULL = [
  ...INVENTORY_TYPES,
  {
    key: InventoryType.CancelPlacedSO,
    value: 'Cancel Placed Order'
  },
  {
    key: InventoryType.CancelProcessingSO,
    value: 'Cancel Processing Order'
  }
];

export interface InventoryActivityLogsFilter {
  page: number;
  size: number;
  warehouseId?: number;
  type?: string[];
  syncStatus?: string;
  createdDateFrom?: string;
  createdDateTo?: string;
  filterSearch?: string;
}
