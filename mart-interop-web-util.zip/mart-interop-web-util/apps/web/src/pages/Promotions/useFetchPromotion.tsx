import { DEFAULT_PAGE_NUMBER, DEFAULT_PAGE_SIZE } from 'constants/common'
import { isUndefined } from 'lodash'
import { reducer, saga, sagaActions, selectors, sliceName } from './slice'
import { useEffect, useMemo } from 'react'
import { useSearchParams } from 'react-router-dom'
import { useAppDispatch, useAppSelector, useInjectReducer, useInjectSaga } from 'store/hooks'

export const useFetchPromotion = () => {
  useInjectReducer({ key: sliceName, reducer })
  useInjectSaga({ key: sliceName, saga })
  const [searchParams] = useSearchParams()

  const dispatch = useAppDispatch()

  const loading = useAppSelector(selectors.selectLoading)
  const promotions = useAppSelector(selectors.selectPromotions)
  const total = useAppSelector(selectors.selectTotal)
  const page = searchParams.get('page')
    ? parseInt(searchParams.get('page') as any)
    : DEFAULT_PAGE_NUMBER
  const size = searchParams.get('size') ? parseInt(searchParams.get('size') as any) : DEFAULT_PAGE_SIZE
  const search: any = useMemo(
    () => ({
      provinceId: searchParams.get('provinceId'),
      status: searchParams.get('status'),
      subStatus: searchParams.get('subStatus'),
      sort: searchParams.get('sort') || '-created_at'
    }),
    [searchParams]
  )

  const fetch = () => {
    dispatch(
      sagaActions.fetchPromotions({
        page,
        size,
        search
      })
    )
  }

  useEffect(() => {
    if (isUndefined(page)) return
    fetch()
  }, [dispatch, page, size, search])

  return { loading, promotions, total, search, fetch }
}
