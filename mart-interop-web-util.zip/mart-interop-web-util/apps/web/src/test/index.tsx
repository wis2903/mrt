import { ReactElement, ReactNode } from 'react'
import { render as baseRender, renderHook, RenderOptions } from '@testing-library/react'
import '@testing-library/jest-dom'
import 'jest-styled-components'
import LanguageProvider from 'containers/LanguageProvider'
import { Provider } from 'react-redux'
import store from 'store/store'
import { translationMessages } from 'i18n'
import { BrowserRouter } from 'react-router-dom'
import { ThemeProvider } from 'styled-components'
import GlobalStyle from 'globalStyle'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import LoadingContainer from 'containers/LoadingContainer'
import { defaultTheme } from 'styles/defaultTheme.styles'
import { AbilityContext } from 'casl/can'
import { ability } from 'casl/ability'
import { FormProvider, useForm } from 'react-hook-form'
const queryClient = new QueryClient()
const render = (ui: ReactElement, options?: Omit<RenderOptions, 'queries'>) => baseRender(ui, { ...options })

const renderWithProvider = (ui: ReactElement, options?: Omit<RenderOptions, 'queries'>) => {
  const element = (
    <BrowserRouter>
      <Provider store={store}>
        <AbilityContext.Provider value={ability}>
          <LanguageProvider messages={{ en: translationMessages.en }}>
            <QueryClientProvider client={queryClient}>
              <ThemeProvider theme={defaultTheme}>
                <GlobalStyle />
                <LoadingContainer>{ui}</LoadingContainer>
              </ThemeProvider>
            </QueryClientProvider>
          </LanguageProvider>
        </AbilityContext.Provider>
      </Provider>
    </BrowserRouter>
  )
  return baseRender(element, { ...options })
}

type FormWrapperProps = {
  children: ReactNode
}
const FormWrapper = ({ children }: FormWrapperProps) => {
  const methods = useForm()
  return <FormProvider {...methods}>{children}</FormProvider>
}

const sleep = (timeout: number): Promise<void> => {
  return new Promise((resolve, _reject) => {
    setTimeout(resolve, timeout)
  })
}

// re-export everything
export * from '@testing-library/react'

// override render method
export { render, renderWithProvider, renderHook, FormWrapper, sleep }
