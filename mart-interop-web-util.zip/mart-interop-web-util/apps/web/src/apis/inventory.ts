import apiClient, { apiClientV2 } from './apiClient';
import qs from 'qs';
import { INVENTORY } from './apiUrl';
import { InventoryFilter } from '../types/Inventory';

const _prepare = (params: InventoryFilter) => {
    return params;
};
export const fetchList = (params: InventoryFilter) => {
    return apiClient.post(`${INVENTORY}/search`, _prepare(params));
};
export const exportInventory = (params: { warehouseId: string }) => {
    return apiClient.get(`${INVENTORY}/export-file`, {
        params: {
            warehouseId: params.warehouseId,
        },
        paramsSerializer: (params) => qs.stringify(params, { arrayFormat: 'repeat' }),
        responseType: 'blob',
    });
};

export const exportInventoryV2 = (params: { warehouseId: string | number | number[] }) => {
    return apiClient.get(`${INVENTORY}/export-file/stream`, {
        params: {
            warehouseIdList: params.warehouseId,
        },
        paramsSerializer: (params) => qs.stringify(params, { arrayFormat: 'repeat' }),
        responseType: 'blob',
    });
};

export const syncInventory = ({
    productCode,
    warehouseId,
}: {
    productCode: string;
    warehouseId: number;
}) => {
    return apiClient.put(`/warehouse/inventory/sync`, {
        skuCode: productCode,
        warehouseId,
    });
};

export const syncInventoryForTheWholeWarehouse = ({ warehouseId }: { warehouseId: string }) => {
    return apiClientV2.get(`/mart-sp-mgmt/1.0/portal/inventories/sync/warehouse/${warehouseId}`);
};
