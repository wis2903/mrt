import { RangePickerDateProps } from 'antd/lib/date-picker/generatePicker';
import { OrderTypeEnum } from 'v2/app/@types/enum.type';

export interface GetOrdersParams {
    pageNumber?: number;
    pageSize?: number;
    search?: OrderSearchForm;
}
export interface OrderSearchApi {
    page?: number;
    size?: number;
    filterSearch?: string;
    provinceId?: string | number;
    districtId?: string | number;
    warehouseId?: string | number;
    grandTotalFrom?: number;
    grandTotalTo?: number;
    createdDateFrom?: string;
    createdDateTo?: string;
    status?: string[];
    statusList?: string[];
    isGetAll?: boolean;
    orderType?: string;
}
export interface OrderSearchForm {
    provinceId?: string | number;
    districtId?: string | number;
    warehouseId?: string | number;
    totalFrom?: number;
    totalTo?: number;
    createdDate?: RangePickerDateProps<any>['value'];
    createdDateFrom?: string;
    createdDateTo?: string;
    search?: string;
    statusId?: string[];
    isGetAll?: boolean;
    type?: OrderTypeEnum;
}
export interface Order {
    orderId: number | string;
    haravanOrderNumber: string;
    source: string;
    total: number;
    grandTotal: number;
    discount?: number;
    createdDate: string;
    totalItemCount: number;
    totalQuantity: number;
    currentStatus: OrderStatus;
    warehouseId: number;
    grossWeight: number;
    selfPickup: boolean;
    orderType: string;
    note?: string;
    salePersonId?: string;
    customerDetails: {
        customerId: number;
        customerZaloId: string;
        customerName: string;
        phoneNumber: string;
        email: string;
    };
    firstItemDetail: null;
    shippingAddressDetails: {
        shippingCountry: string;
        shippingProvince: string;
        shippingDistrict: string;
        shippingAddress: string;
        shippingWard: string;
        shippingCountryId: string;
        shippingProvinceId: string;
        shippingDistrictId: string;
        shippingWardId: string;
    };
}

export interface OrderDetail {
    orderId: number;
    haravanOrderNumber: string;
    source: string;
    total: number;
    grandTotal: number;
    createdDate: string;
    currentStatus: OrderStatus;
    warehouseId: number;
    warehouseName?: string;
    countryId: number;
    status: string;
    cancellationReason?: string;
    warehouse: string;
    currency: string;
    totalAmount: number;
    discountAmount: number;
    taxAmount: number;
    doNumber: number;
    createdBy: string;
    lastModifiedBy: string;
    lastModifiedDate: string;
    paymentMethod: string;
    createdByUserName: string;
    createdByUserPhone: string;
    note: string;
    promotionCode: string;
    cartDiscount: number;
    selfPickup: boolean;
    couponDiscount: number;
    receiverDetails: {
        receiverName: string;
        receiverPhone: string;
    };
    customerDetails: {
        customerId: number;
        customerZaloId: string;
        customerName: string;
        phoneNumber: string;
        email: string;
    };
    shippingAddressDetails: {
        shippingCountry: string;
        shippingProvince: string;
        shippingDistrict: string;
        shippingAddress: string;
        shippingWard: string;
        shippingCountryId: string;
        shippingProvinceId: string;
        shippingDistrictId: string;
        shippingWardId: string;
    };

    itemListDetail: OrderItem[];
}
export interface OrderItem {
    orderItemId: number;
    userOrderId: string;
    price: number;
    salePrice: number;
    quantity: number;
    createdBy: string;
    lastModifiedBy: string;
    createdDate: string;
    lastModifiedDate: string;
    grossWeight: number;
    cartDiscount: number;
    skuDetails: {
        skuId: number;
        skuCode: string;
        skuName: string;
        description: string;
        skuConfigurationId: number;
        skuConfigurationName: string;
        imageUrl: string;
        brandDetails: {
            brandName: string;
            brandId: string;
        };
    };
}

export type OrderStatus =
    | 'CREATED'
    | 'PLACED'
    | 'PROCESSING'
    | 'DELIVERY'
    | 'COMPLETED'
    | 'CANCELED';
export type OrderAction =
    | 'CONFIRM'
    | 'CANCEL'
    | 'COMPLETE'
    | 'RESCHEDULED'
    | 'DELIVERY'
    | 'PROCESSING'
    | 'REQUEST_CANCEL'
    | 'UNDO_CANCEL_RQUEST';

export interface ChangeOrderStatusParams {
    id: string | number;
    action: OrderAction;
    reason?: string;
    callback?: any;
    callbackFinally?: any;
}
