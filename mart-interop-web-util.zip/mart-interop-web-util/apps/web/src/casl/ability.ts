import { AbilityBuilder, Ability } from '@casl/ability'
import { ACCESS_RIGHTS, Role } from 'constants/ability'

export const ability = new Ability([])
export function updateAbility(_ability: Ability, jwtPayload: any) {
  const { can, rules } = new AbilityBuilder(Ability)
  const roles = jwtPayload.realm_access.roles
  roles.forEach((role: Role) => {
    const roleAccessRights: any = ACCESS_RIGHTS[role]
    return (
      roleAccessRights &&
      Object.keys(roleAccessRights).forEach((screen: string) => {
        const actions = roleAccessRights[screen]
        actions.forEach((action: string) => {
          can(action, screen)
        })
      })
    )
  })
  _ability.update(rules)
}
