import AbortableHttpRequestWithConfigs from './common.service';
import AbortableHttpRequest from 'v2.1/libs/abortable-http-request.lib';
import { IResponse } from 'v2.1/libs/abortable-http-request.lib';
import { GET_ORDERSV2_1_1 } from 'apis/apiUrl';
import {
    RequestMethodEnum,
    RequestConfigTypeEnum,
    TransformTypeEnum,
} from 'v2.1/libs/abortable-http-request.lib';

interface ISearchOrderRequestParams {
    page?: number;
    size?: number;
    search?: string;
    provinceId?: number;
    districtId?: number;
    warehouseId?: number;
    statusList?: string[];
    selfPickup?: number;
    source?: number[];
    grandTotalFrom?: number;
    grandTotalTo?: number;
    createdDateFrom?: number;
    createdDateTo?: number;
    completedAtFrom?: number;
    completedAtTo?: number;
}

export function generateSearchOrdersRequest(
    params?: ISearchOrderRequestParams
): AbortableHttpRequest {
    const request = new AbortableHttpRequestWithConfigs();
    request.extendsBaseURL(GET_ORDERSV2_1_1);
    request.setParams(Object(params));
    request.setMethod(RequestMethodEnum.post);
    request.setConfig(RequestConfigTypeEnum.transformRequest, TransformTypeEnum.snakeCase);
    return request;
}

export function parseOrdersListFromResponse(response: IResponse): Record<string, unknown>[] {
    if (response.hasError || !response.data) return [];

    try {
        const list = Object(response.data).data;
        if (Array.isArray(list)) return list;
        return [];
    } catch (e) {
        return [];
    }
}
