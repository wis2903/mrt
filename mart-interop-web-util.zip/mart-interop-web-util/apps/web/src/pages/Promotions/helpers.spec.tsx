import {
  genSkuSummary,
  genSubStatus,
  getDealTypeFromDiscountTypeAndDiscountAffection,
  getFinalFormData,
  getUOMsBySKUAndProvince,
  getValidationTriggerFields,
  prepareCreatePromotionsParams,
  prepareGetPromotionsParams,
  searchSKUByKeyword,
  shortenText,
  validateComboDiscountForEachSKU,
  validateComboDiscountForTheWholeCombo,
  validateComboDiscountFormData
} from './helpers'
import {
  DEAL_TYPE,
  InactivePromotionSubStatus,
  InactivePromotionSubStatusName,
  PromotionStatus
} from 'constants/promotions'
import { TIME_FORMAT_2 } from 'constants/common'
import { AMAST_UOM, ComboDiscountAffectionEnum, ComboDiscountTypeEnum, PromotionDealType } from './@types'
import moment from 'moment'
import apiClient from 'apis/apiClient'
import * as skuAPIs from 'apis/sku'

jest.mock('react-uuid', () => jest.fn().mockReturnValue(1))

const formValues = {
  name: 'Test promotion name',
  provinceId: 48,
  countryId: 6,
  criteria: {
    applyLimit: -1,
    excludeCategory: [],
    skuCode: 1
  },
  combo: [
    {
      sku: {
        id: 1,
        code: '1'
      },
      uom: {
        id: 1
      },
      qty: 1
    },
    {
      sku: {
        id: 2,
        code: '2'
      },
      uom: {
        id: 2
      },
      qty: 2
    }
  ],
  internalValues: {
    discountType: ComboDiscountTypeEnum.priceAfterDiscount,
    discountAffection: ComboDiscountAffectionEnum.theWholeCombo
  },
  startDate: moment(new Date('1970-01-02T00:00:00Z')),
  endDate: moment(new Date('2038-01-01T00:00:00Z'))
}

describe('Promotions helpers', () => {
  it('should return GET promotions params correctly', () => {
    const params1 = {
      page: 1,
      size: 10,
      search: {
        provinceId: '1',
        status: 1,
        subStatus: 1,
        sort: '-id'
      }
    }
    const actual1 = {
      page: 1,
      size: 10,
      province_id: '1',
      status: 1,
      sub_status: 1,
      sort: '-id'
    }

    expect(prepareGetPromotionsParams(params1)).toEqual(actual1)

    const params2 = {}
    const actual2 = {
      page: undefined,
      size: undefined,
      province_id: undefined,
      status: undefined,
      sub_status: undefined,
      sort: undefined
    }
    expect(prepareGetPromotionsParams(params2)).toEqual(actual2)
  })
  it('should return CREATE Order Discount promotions params correctly', () => {
    const startDate = moment('2021-07-01T00:00:00[Z]')
    const endDate = moment('2021-07-05T00:00:00[Z]')
    const expectedStartDate = startDate.startOf('day').utc().format(TIME_FORMAT_2)
    const expectedEndDate = endDate.endOf('day').utc().format(TIME_FORMAT_2)

    const params1 = {
      name: 'Promo name',
      dealType: DEAL_TYPE.ORDER,
      provinceId: 1,
      countryId: 6,
      startDate,
      endDate,
      criteria: {
        cartValue: 1000,
        discountPercent: 5,
        excludeCategory: [33],
        applyLimit: -1
      }
    }
    const actual1 = {
      name: 'Promo name',
      dealType: DEAL_TYPE.ORDER,
      provinceId: 1,
      countryId: 6,
      startDate: expectedStartDate,
      endDate: expectedEndDate,
      criteria: {
        cartValue: 1000,
        discountPercent: 5,
        excludeCategory: [33],
        applyLimit: -1
      }
    }
    expect(prepareCreatePromotionsParams(params1)).toEqual(actual1)
  })
  it('should generate promotion subStatus correctly', () => {
    const actual1 = genSubStatus(PromotionStatus.Active, [PromotionStatus.Active])
    const expected1 = {
      code: PromotionStatus.Active,
      name: 'Active',
      tagConfig: {
        tagClassName: 'bg-[#c7ffe9]',
        textClassName: 'text-[#077d52] whitespace-nowrap',
        borderClassName: ''
      }
    }

    expect(actual1).toEqual(expected1)

    const actual2 = genSubStatus(PromotionStatus.Inactive, [InactivePromotionSubStatus.Expired])
    const expected2 = {
      code: InactivePromotionSubStatus.Expired,
      name: InactivePromotionSubStatusName.EXPIRED,
      tagConfig: {
        textClassName: 'whitespace-nowrap'
      }
    }
    expect(actual2).toEqual(expected2)
  })
  it('should generate SKU summary correctly', () => {
    const skuList = [
      {
        sku: {
          id: 1162736,
          name: 'AutoTest-Larue - check add usageDays'
        },
        uom: {
          id: 963449,
          name: 'Lon'
        },
        qty: 1
      },
      {
        uom: {
          id: 963289,
          name: 'Thung'
        },
        qty: 11,
        sku: {
          id: 1162642,
          name: 'Phi beer 15'
        }
      }
    ]

    const actual = genSkuSummary(skuList)
    const expected = 'Combo: 1 lon AutoTest-Larue - check add usageDays + 11 thung Phi beer 15'
    expect(actual).toEqual(expected)
  })
  it('should get DealType from discountType and discountAffection correctly', () => {
    const actual1 = getDealTypeFromDiscountTypeAndDiscountAffection(
      ComboDiscountTypeEnum.priceAfterDiscount,
      ComboDiscountAffectionEnum.theWholeCombo
    )
    const expected1 = PromotionDealType.COMBO_SET_FLAT

    expect(actual1).toEqual(expected1)

    const actual2 = getDealTypeFromDiscountTypeAndDiscountAffection(
      ComboDiscountTypeEnum.priceAfterDiscount,
      ComboDiscountAffectionEnum.eachSKU
    )
    const expected2 = PromotionDealType.COMBO_ITEM_FLAT

    expect(actual2).toEqual(expected2)

    const actual3 = getDealTypeFromDiscountTypeAndDiscountAffection(
      ComboDiscountTypeEnum.discountPercent,
      ComboDiscountAffectionEnum.eachSKU
    )
    const expected3 = undefined

    expect(actual3).toEqual(expected3)
  })
  it('should return validation fields correctly', () => {
    const commonValidationFields = [
      'combo',
      'startDate',
      'endDate',
      'name',
      'dealType',
      'provinceId',
      'countryId',
      'criteria.applyLimit'
    ]

    const actual1 = getValidationTriggerFields(
      ComboDiscountTypeEnum.priceAfterDiscount,
      ComboDiscountAffectionEnum.theWholeCombo
    )
    const expected1 = [...commonValidationFields, 'criteria.discountForTheWholeCombo']
    expect(actual1).toEqual(expected1)

    const actual2 = getValidationTriggerFields(
      ComboDiscountTypeEnum.priceAfterDiscount,
      ComboDiscountAffectionEnum.eachSKU
    )
    const expected2 = [...commonValidationFields, 'criteria.discountForEachSKU']
    expect(actual2).toEqual(expected2)

    const actual3 = getValidationTriggerFields(
      ComboDiscountTypeEnum.discountPercent,
      ComboDiscountAffectionEnum.eachSKU
    )
    expect(actual3).toEqual(commonValidationFields)
  })
  it('should return final form data with combo_set_flat deal type correctly', () => {
    const actual = getFinalFormData(formValues)
    const expected = {
      name: 'Test promotion name',
      dealType: PromotionDealType.COMBO_SET_FLAT,
      criteria: {
        applyLimit: -1,
        excludeCategory: [],
        discountFlat: 0,
        skuCode: 1,
        combo: [
          {
            skuCode: '1',
            configurationId: 1,
            amastUom: AMAST_UOM.CT,
            quantity: 1
          },
          {
            skuCode: '2',
            configurationId: 2,
            amastUom: AMAST_UOM.CT,
            quantity: 2
          }
        ]
      },
      provinceId: formValues.provinceId,
      countryId: formValues.countryId,
      startDate: moment(new Date('1970-01-02T00:00:00Z')),
      endDate: moment(new Date('2038-01-01T00:00:00Z'))
    }

    expect(actual).toEqual(expected)
  })
  it('should return final form data with combo_item_flat deal type correctly', () => {
    const actual = getFinalFormData({
      ...formValues,
      criteria: {
        ...formValues.criteria,
        discountForEachSKU: [
          {
            price: 1
          },
          {
            price: 2
          }
        ]
      },
      internalValues: {
        discountType: ComboDiscountTypeEnum.priceAfterDiscount,
        discountAffection: ComboDiscountAffectionEnum.eachSKU
      }
    })
    const expected = {
      dealType: PromotionDealType.COMBO_ITEM_FLAT,
      criteria: {
        applyLimit: -1,
        excludeCategory: [],
        skuCode: 1,
        combo: [
          {
            skuCode: '1',
            configurationId: 1,
            amastUom: AMAST_UOM.CT,
            quantity: 1,
            priceSet: 1
          },
          {
            skuCode: '2',
            configurationId: 2,
            amastUom: AMAST_UOM.CT,
            quantity: 2,
            priceSet: 2
          }
        ]
      },
      name: 'Test promotion name',
      provinceId: formValues.provinceId,
      countryId: formValues.countryId,
      startDate: moment(new Date('1970-01-02T00:00:00Z')),
      endDate: moment(new Date('2038-01-01T00:00:00Z'))
    }

    expect(actual).toEqual(expected)
  })
  it('should validate combo discount for the whole combo correctly', () => {
    const callbackFn1 = jest.fn()
    const actual1 = validateComboDiscountForTheWholeCombo(
      {
        ...formValues,
        criteria: {
          ...formValues.criteria,
          discountForTheWholeCombo: 1
        }
      },
      callbackFn1
    )
    expect(actual1).toEqual(false)
    expect(callbackFn1).toBeCalled()

    const callbackFn2 = jest.fn()
    const actual2 = validateComboDiscountForTheWholeCombo(
      {
        ...formValues,
        criteria: {
          ...formValues.criteria,
          discountForTheWholeCombo: 0
        }
      },
      callbackFn2
    )
    expect(actual2).toEqual(true)
    expect(callbackFn2).not.toBeCalled()
  })
  it('should validate combo discount for each SKU correctly', () => {
    const callbackFn1 = jest.fn()
    const actual1 = validateComboDiscountForEachSKU(
      {
        ...formValues,
        criteria: {
          ...formValues.criteria,
          discountForEachSKU: [
            {
              price: 1
            },
            {
              price: 2
            }
          ]
        }
      },
      callbackFn1
    )
    expect(actual1).toEqual(false)
    expect(callbackFn1).toBeCalled()

    const callbackFn2 = jest.fn()
    const actual2 = validateComboDiscountForEachSKU(
      {
        ...formValues,
        criteria: {
          ...formValues.criteria,
          discountForEachSKU: [
            {
              price: 0
            },
            {
              price: 0
            }
          ]
        }
      },
      callbackFn2
    )
    expect(actual2).toEqual(true)
    expect(callbackFn2).not.toBeCalled()
  })
  it('should search skus by keyword correctly', async () => {
    const putSpy = jest.spyOn(apiClient, 'post')
    putSpy.mockReturnValueOnce(Promise.resolve({}))
    const result = await searchSKUByKeyword('test keyword')
    expect(result).toEqual({})
  })
  it('should get UOMs By SKU and province correctly', async () => {
    const results = await getUOMsBySKUAndProvince(1, 1)
    expect(Array.isArray(results)).toBe(true)
  })
  it('should validate ComboDiscount form data correctly', async () => {
    const commonFormValues = {
      combo: [{ sku: { id: 1 }, uom: { id: 1, defaultPrice: 0 }, qty: 1 }],
      internalValues: {
        discountType: ComboDiscountTypeEnum.priceAfterDiscount,
        discountAffection: undefined
      },
      criteria: {
        discountForTheWholeCombo: undefined,
        discountForEachSKU: [
          {
            skuId: 1,
            price: undefined
          }
        ]
      }
    }
    const formValues1 = {
      ...commonFormValues,
      criteria: {
        ...commonFormValues.criteria,
        discountForEachSKU: [
          {
            skuId: 1,
            price: 200000
          }
        ]
      },
      internalValues: {
        ...commonFormValues.internalValues,
        discountAffection: ComboDiscountAffectionEnum.eachSKU
      }
    }
    const formValues2 = {
      ...commonFormValues,
      criteria: {
        ...commonFormValues.criteria,
        discountForTheWholeCombo: 200000
      },
      internalValues: {
        ...commonFormValues.internalValues,
        discountAffection: ComboDiscountAffectionEnum.theWholeCombo
      }
    }

    const methods1 = {
      getValues: () => formValues1,
      trigger: () => true,
      setError: jest.fn()
    }
    const methods2 = {
      getValues: () => formValues2,
      trigger: () => true,
      setError: jest.fn()
    }
    const t = jest.fn()

    const { setError: setErrorMethods1 } = methods1
    const { setError: setErrorMethods2 } = methods2

    await validateComboDiscountFormData(methods1 as any, t)
    expect(setErrorMethods1).toHaveBeenCalled()

    await validateComboDiscountFormData(methods2 as any, t)
    expect(setErrorMethods2).toHaveBeenCalled()
  })
  it('should shortenText correctly', () => {
    const text = '123456789'
    const actual = shortenText(text, 4)
    expect(actual).toEqual('12...89')
  })
  it('should searchSKUByKeyword correctly', async () => {
    const mockGetSkuList = jest.spyOn(skuAPIs, 'getSkuList')
    mockGetSkuList.mockReturnValueOnce(Promise.resolve({}) as any)
    await searchSKUByKeyword('test')
    expect(mockGetSkuList).toHaveBeenCalled()
  })
})
