import { Button } from 'antd';
import styled from 'styled-components';
import { defaultTheme } from 'styles/defaultTheme.styles';

export const OrdersStyled = styled.div`
    .justify-end {
        display: flex;
        justify-content: end;
        margin-bottom: ${defaultTheme.spacing.md};
    }
    .actions {
        width: 25px;
        height: 25px;
        border-radius: 6px;
        border: 1px solid ${defaultTheme.colors.BLACK};
        background: ${defaultTheme.colors.WHITE};
        display: flex;
        justify-content: center;
        align-items: center;
    }
`;

export const ExportDropdownItem = styled(Button)`
    border: 0;
    background: transparent !important;
    box-shadow: none;
    padding: 0;
    width: 100%;
    text-align: left;
`;

export const ExportWrapper = styled.div`
    display: inline-block;
    position: relative;

    > span {
        padding: 2px 8px;
        background: #222222;
        color: #ffffff;
        border-radius: 4px;
        position: absolute;
        right: 0;
        top: calc(100% + 8px);
        display: none;
    }

    &:hover {
        > span {
            display: inline-block;
        }
    }
`;
