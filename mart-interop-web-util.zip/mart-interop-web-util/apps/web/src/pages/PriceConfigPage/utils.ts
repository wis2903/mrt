import { SellingPriceTable, UpdatePriceConfigApi } from 'types/SKUDetail';
import { ALL_OPTIONS } from './constant';
import { includeText } from 'utils/common';
import { isNil } from 'lodash';
import { ProvinceDataItem } from 'types/MasterDataKey';

export type TableFilter = {
  region?: string;
  searchValue?: string;
};

export const prepareTableData = (data: Partial<SellingPriceTable>[], filter: TableFilter, provincesMasterData: ProvinceDataItem[]) => {
  return data
    .filter((item) => {
      const isIncludeSearch = includeText(item.provinceName, filter.searchValue) || includeText(item.lastModifiedBy, filter.searchValue);

      const foundProvince = provincesMasterData?.find(
        (province) => province.id === item.province?.value || province.id === item.provinceId
      );
      const isIncludeProvince = foundProvince?.region === filter.region || filter.region === ALL_OPTIONS.name;

      const isNewRecord = item.isNew && !foundProvince;

      return (isIncludeProvince && isIncludeSearch) || isNewRecord;
    })
    .map((item) => {
      return {
        ...item,
        province: item.province || {
          value: item.provinceId,
          label: item.provinceName,
          region: item.region
        }
      };
    });
};

export const isInvalidFormData = (data: UpdatePriceConfigApi[]): boolean => {
  return data.some((item) => isNil(item.grossPrice) || isNil(item.provinceId));
};

export const prepareUpdateData = (data: Partial<SellingPriceTable>[]): UpdatePriceConfigApi[] => {
  return data.map((item) => {
    return {
      provinceId: item.province?.value || item.provinceId,
      id: item.isNew ? undefined : item.id,
      grossPrice: item.newPrice || item.grossPrice,
      note: item.note || '',
      isActive: !!item.isActive
    };
  });
};
