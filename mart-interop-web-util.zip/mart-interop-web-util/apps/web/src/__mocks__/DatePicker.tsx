import moment from "moment";

const DatePicker: React.FC<any> & { RangePicker: any } = ({ value, onChange, children }) => {
  const handleChange = (e: any) => {
    onChange(e);
  };
  return (
    <>
      <input data-testid='datePicker-onChange' value={value || ''} onChange={handleChange} />
      {children}
    </>
  );
};

const RangePicker: React.FC<any> = ({ value, onChange, onCalendarChange, disabledDate, children }) => {
  const handleChange = (e: any) => {
    onChange(e);
  };
  return (
    <>
      <input data-testid='rangePicker-onChange' value={value || ''} onChange={handleChange} />
      <button data-testid='btn-change-calendar' onClick={() => onCalendarChange([moment(), moment()])}>test</button>
      <button data-testid='btn-disable-date' onClick={() => disabledDate(moment())}>test</button>
      {children}
    </>
  );
};
DatePicker.RangePicker = RangePicker;

export default DatePicker;
