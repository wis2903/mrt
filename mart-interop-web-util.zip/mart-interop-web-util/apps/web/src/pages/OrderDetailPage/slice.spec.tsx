import { initialState, reducer, reducerActions, sagaOption, selectors, sliceName } from './slice';
import sinon from 'sinon';
import * as api from 'apis/orders';
import store from 'store/store';
import { runSaga } from 'redux-saga';
import { DEFAULT_PAGE_NUMBER, DEFAULT_PAGE_SIZE } from 'constants/common';

sinon.stub(api, 'getOrder').callsFake(
  () =>
    ({
      data: {
        data: {
          test: 1
        }
      }
    } as any)
);
sinon.stub(api, 'createDeliveryOrder').callsFake(
  () =>
    ({
      data: {}
    } as any)
);

describe('reducerActions', () => {
  it('fetchOrderSuccess', () => {
    expect(
      reducer(
        initialState,
        reducerActions.fetchOrderSuccess({
          id: 'test'
        })
      )
    ).toMatchObject({
      order: {
        id: 'test'
      }
    });
  });
  it('changeSearch', () => {
    expect(
      reducer(
        initialState,
        reducerActions.changeSearch({
          search: 'test'
        })
      )
    ).toMatchObject({
      search: {
        search: 'test'
      },
      pageNumber: DEFAULT_PAGE_NUMBER,
      pageSize: DEFAULT_PAGE_SIZE
    });
  });
  it('changePageNumber', () => {
    expect(reducer(initialState, reducerActions.changePageNumber(1))).toMatchObject({
      pageNumber: 1
    });
  });
  it('changePageSize', () => {
    expect(reducer(initialState, reducerActions.changePageSize(1))).toMatchObject({
      pageSize: 1
    });
  });
  it('removeStore', () => {
    expect(reducer(initialState, reducerActions.removeStore())).toMatchObject(initialState);
  });
});

describe('selectors', () => {
  const state = {
    [sliceName]: {
      loading: true,
      orderItems: [],
      total: [],
      search: {},
      pageNumber: 10,
      pageSize: 10
    }
  };
  it('selectLoading', () => {
    expect(selectors.selectLoading(state)).toEqual(true);
  });
  it('selectOrderItems', () => {
    expect(selectors.selectOrderItems(state)).toEqual([]);
  });
  it('selectTotal', () => {
    expect(selectors.selectTotal(state)).toEqual([]);
  });
  it('selectSearch', () => {
    expect(selectors.selectSearch(state)).toEqual({});
  });
  it('selectPageNumber', () => {
    expect(selectors.selectPageNumber(state)).toEqual(10);
  });
  it('selectPageSize', () => {
    expect(selectors.selectPageSize(state)).toEqual(10);
  });
});

describe('sagaActions', () => {
  it('fetchSkuDetail', async () => {
    const spyAction = jest.spyOn(reducerActions, 'fetchOrderSuccess');

    await store.runSaga(sagaOption.caseSagas.fetchOrderDetail, { payload: {} }).toPromise();
    expect(spyAction).toBeCalledTimes(1);
  });

  it('changeOrder success', async () => {
    const dispatchedActions = [];

    const fakeStore = {
      getState: () => {
        return {
          [sliceName]: {}
        };
      },
      dispatch: (action: any) => dispatchedActions.push(action)
    };

    const callback = jest.fn();
    const callbackFinally = jest.fn();

    await runSaga(fakeStore, sagaOption.caseSagas.changeOrder, {
      payload: {
        action: 'CONFIRM',
        id: 1,
        callback,
        callbackFinally
      },
      type: 'test'
    }).toPromise();

    expect(callback).toBeCalledTimes(1);
  });
});
