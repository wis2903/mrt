import userEvent from '@testing-library/user-event'
import { renderWithProvider, screen } from 'test'
import Component from '.'
import * as slice from './slice'
import sinon from 'sinon'
import { apiMartClient } from 'apis/apiClient'

sinon.stub(apiMartClient, 'post').callsFake(
  () =>
    ({
      data: {}
    } as any)
)
sinon.stub(apiMartClient, 'get').callsFake(
  () =>
    ({
      data: {}
    } as any)
)

const mockPromotions: any = [
  {
    id: 1,
    name: 'Khuyến mãi 1',
    dealType: 1,
    startDate: '2019-08-24T14:15:22Z',
    endDate: '2020-08-24T14:15:22Z',
    provinceId: 10,
    countryId: 1,
    status: 1,
    subStatus: [],
    isActive: true,
    createdAt: '2019-08-24T14:15:22Z'
  },
  {
    id: 2,
    name: 'Khuyến mãi 2',
    dealType: 2,
    startDate: '2020-08-24T14:15:22Z',
    endDate: '2021-08-24T14:15:22Z',
    provinceId: 10,
    countryId: 1,
    status: 2,
    subStatus: [1, 2],
    isActive: true,
    createdAt: '2019-08-24T14:15:22Z'
  },
  {
    id: 3,
    name: 'Khuyến mãi 3',
    dealType: 2,
    startDate: '2020-08-24T14:15:22Z',
    endDate: '2021-08-24T14:15:22Z',
    provinceId: 10,
    countryId: 1,
    status: 2,
    subStatus: [2, 1],
    isActive: true,
    createdAt: '2019-08-24T14:15:22Z'
  },
  {
    id: 4,
    name: 'Khuyến mãi 4',
    dealType: 2,
    startDate: '2020-08-24T14:15:22Z',
    endDate: '2021-08-24T14:15:22Z',
    provinceId: 10,
    countryId: 1,
    status: 2,
    subStatus: [3, 2],
    isActive: true,
    createdAt: '2019-08-24T14:15:22Z'
  }
]

describe('Render component', () => {
  afterEach(() => {
    jest.clearAllMocks()
    jest.restoreAllMocks()
  })

  it('should render without crash', () => {
    const { container } = renderWithProvider(<Component />)

    expect(container).toBeTruthy()
  })
  it('should render with data', () => {
    jest.spyOn(slice.selectors, 'selectPromotions').mockReturnValue(mockPromotions)
    jest.spyOn(slice.selectors, 'selectTotal').mockReturnValue(100)
    const { container } = renderWithProvider(<Component />)

    expect(container).toBeTruthy()
  })
})
describe('Actions', () => {
  beforeEach(() => {
    jest.spyOn(slice.selectors, 'selectPromotions').mockReturnValue(mockPromotions)
    jest.spyOn(slice.selectors, 'selectTotal').mockReturnValue(100)
  })
  afterEach(() => {
    jest.clearAllMocks()
    jest.restoreAllMocks()
  })
  it('should change pageNumber', async () => {
    const user = userEvent.setup()
    jest.spyOn(slice.reducerActions, 'changePageNumber')
    const { container } = renderWithProvider(<Component />)
    await user.click(screen.getAllByTitle('2')[0])
    expect(container).toBeTruthy()
  })
})
