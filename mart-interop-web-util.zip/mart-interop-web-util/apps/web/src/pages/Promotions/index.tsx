import dayjs from 'dayjs'
import useLocales from 'hooks/useLocales'
import Content from 'layouts/components/Content'
import PageHeader from 'layouts/components/PageHeader'
import Filters from './components/filters/Filters'
import Tag from 'components/Tag'
import Button from 'components/Button'
import PromotionActions from './components/common/promotionActions/PromotionActions'
import { PlusOutlined } from '@ant-design/icons'
import { Empty, Pagination, Spin, Table, Tooltip } from 'antd'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { useAppSelector } from 'store/hooks'
import { showTotalPaginationItemsAmount } from 'utils/common'
import { selectors } from './slice'
import { selectors as masterDataSelectors } from 'store/masterData/slice'
import { PromotionsStyled } from './styled'
import { useFetchPromotion } from './useFetchPromotion'
import { Promotion } from 'types/Promotions'
import { genSubStatus, shortenText } from './helpers'
import { snakeCase } from 'lodash'
import { useCallback, useEffect, useState } from 'react'
import { PROMOTION_CREATE_URI, PROMOTION_V2_URI } from 'routes/routes'
import { DEAL_TYPE_2_STRING, PromotionStatus } from 'constants/promotions'
import { DAY_MONTH_YEAR_FORMAT } from 'constants/common'
import type { ColumnsType } from 'antd/es/table'

// main
const Promotions: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams()
  const [isDeletingPromotion, setIsDeletingPromotion] = useState<boolean>(false)
  const { t } = useLocales()
  const { loading, total, fetch: fetchPromotions } = useFetchPromotion()
  const navigate = useNavigate()

  const promotions = useAppSelector(selectors.selectPromotions)
  const page = parseInt(searchParams.get('page') || '1')
  const allProvinces = useAppSelector(masterDataSelectors.selectorByKey('allProvinces'))

  const setDefaultSorter = useCallback(() => {
    searchParams.set('sort', '-created_at')
  }, [searchParams])
  const handleTableSorter = ({ order, field }: any) => {
    if (!order) {
      setDefaultSorter()
    } else {
      const direction = order === 'descend' ? '-' : ''
      searchParams.set('sort', `${direction}${snakeCase(field)}`.trim())
    }
    setSearchParams(searchParams)
  }
  const navigateToCreatePage = useCallback(() => {
    navigate(PROMOTION_CREATE_URI)
  }, [navigate])

  const columns: ColumnsType<Promotion> = [
    {
      title: t('Promo ID'),
      dataIndex: 'id',
      key: 'id',
      render: (id) => (
        <Tooltip placement='topLeft' title={id} overlayStyle={{ maxWidth: '400px' }}>
          <Link to={`${PROMOTION_V2_URI}/${id}`} className='font-medium'>
            {shortenText(id, 10)}
          </Link>
        </Tooltip>
      )
    },
    {
      title: t('Promo name'),
      dataIndex: 'name',
      key: 'name',
      render: (_, record) => {
        return (
          <span>
            <span>{record.name}</span>
            {DEAL_TYPE_2_STRING[record.dealType] && (
              <>
                <br />
                <span className='opacity-40'>{t(DEAL_TYPE_2_STRING[record.dealType])}</span>
              </>
            )}
          </span>
        )
      }
    },
    {
      title: t('Province'),
      dataIndex: 'provinceId',
      key: 'province',
      render: (provinceId) => {
        return allProvinces.find((province) => Number(province.id) === Number(provinceId))?.name
      }
    },
    {
      title: t('Start date'),
      key: 'startDate',
      dataIndex: 'startDate',
      render: (startDate) => dayjs(startDate).format(DAY_MONTH_YEAR_FORMAT),
      sorter: true
    },
    {
      title: t('End date'),
      key: 'endDate',
      dataIndex: 'endDate',
      render: (endDate) => dayjs(endDate).format(DAY_MONTH_YEAR_FORMAT),
      sorter: true
    },
    {
      title: t('Status'),
      key: 'status',
      dataIndex: 'status',
      align: 'center',
      render: (status, { subStatus }) => {
        const promotionSubStatus = genSubStatus(status, subStatus)
        return <Tag {...promotionSubStatus?.tagConfig}>{t(promotionSubStatus?.name || '-')}</Tag>
      }
    },
    {
      title: t('common.button.actions'),
      key: 'action',
      align: 'center',
      render: (_, record) => {
        if (record.status !== PromotionStatus.Active) return <span />

        return (
          <span className='flex justify-center'>
            <PromotionActions
              promotionId={record.id}
              onBeforeProccessing={() => {
                setIsDeletingPromotion(true)
              }}
              onSuccess={() => {
                fetchPromotions()
              }}
              onCompleted={() => {
                setIsDeletingPromotion(false)
              }}
            />
          </span>
        )
      }
    }
  ]

  useEffect(() => {
    searchParams.set('sort', '-created_at')
    searchParams.set('page', '1')
    setSearchParams(searchParams)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <PromotionsStyled>
      <PageHeader
        title={t('Promo')}
        extra={[
          <Button
            className='rounded-3xl'
            icon={<PlusOutlined />}
            key='createPromo'
            loading={false}
            onClick={navigateToCreatePage}
          >
            {t('Create promo')}
          </Button>
        ]}
      />
      <Content className='bg-white !p-0 mx-6 border border-[#e5e5e5]'>
        <Filters />
        <Spin spinning={loading || isDeletingPromotion}>
          <Table
            locale={{ emptyText: <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description={t('common.No Data')} /> }}
            columns={columns}
            dataSource={promotions}
            rowKey={'id'}
            pagination={false}
            onChange={(pagination, filters, sorter) => {
              handleTableSorter(sorter)
            }}
          />
          <Pagination
            className='inline-flex justify-end mt-4 px-4'
            showTotal={showTotalPaginationItemsAmount}
            total={total}
            current={page}
            showSizeChanger={false}
            showLessItems={true}
            onChange={(_page) => {
              searchParams.set('page', _page.toString())
              setSearchParams(searchParams)
            }}
          />
        </Spin>
      </Content>
    </PromotionsStyled>
  )
}

export default Promotions
