import { Input as AntdInput } from 'antd';
import { TextAreaProps } from 'antd/lib/input';
import { MAX_LENGTH_TEXT_AREA } from 'constants/common';
const { TextArea } = AntdInput;

const Input: React.FC<TextAreaProps> = ({ ...props }) => {
  return <TextArea maxLength={MAX_LENGTH_TEXT_AREA} {...props} />;
};

export default Input;
