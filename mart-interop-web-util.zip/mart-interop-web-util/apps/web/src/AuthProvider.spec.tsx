import { renderWithProvider, screen } from 'test';
import userEvent from '@testing-library/user-event';
import { AuthProvider, AuthContext } from 'AuthProvider';
import { initMock } from './__mocks__/keycloak-js';
jest.mock('keycloak-js');
describe('Render component', () => {
  it('should render without crash', async () => {
    initMock.mockResolvedValue(true);
    const { container } = renderWithProvider(
      <AuthProvider>
        <AuthContext.Consumer>
          {(auth) => {
            return (
              <>
                <button data-testid='login' onClick={() => auth?.signin({})}></button>
                <button data-testid='logout' onClick={() => auth?.signout({})}></button>
                <button data-testid='expire' onClick={auth?.onTokenExpired}></button>
              </>
            );
          }}
        </AuthContext.Consumer>
      </AuthProvider>
    );
    await userEvent.click(screen.getByTestId('login'));
    await userEvent.click(screen.getByTestId('logout'));
    await userEvent.click(screen.getByTestId('expire'));
    expect(container).toBeTruthy();
  });
  it('should render without crash', async () => {
    initMock.mockResolvedValue(false);
    const { container } = renderWithProvider(
      <AuthProvider>
        <div></div>
      </AuthProvider>
    );
    expect(container).toBeTruthy();
  });
});
