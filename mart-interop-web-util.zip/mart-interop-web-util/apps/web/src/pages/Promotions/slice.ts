import { createSlice, PayloadAction } from '@reduxjs/toolkit'
import { DEFAULT_PAGE_NUMBER, DEFAULT_PAGE_SIZE } from 'constants/common'
import { showNotification } from 'containers/NotificationContainer/Notification'
import { call, put } from 'redux-saga/effects'
import { createSliceSaga, SagaType } from 'redux-toolkit-saga'
import { AppState } from 'store/store'
import { getPromotions } from 'apis/promotions'
import { GetPromotionsParams, Promotion, PromotionSearchForm } from 'types/Promotions'
import { getErrorMessage } from 'apis/helpers'

// ---------------------------------------
const sliceName = 'promotions'

export interface PromotionsState {
  loading?: boolean
  promotions?: Promotion[]
  total?: number
  page: number
  size: number
  search?: PromotionSearchForm
}

const initialState: PromotionsState = {
  page: DEFAULT_PAGE_NUMBER,
  size: DEFAULT_PAGE_SIZE
}

// ---------------------------------------
const reducers = {
  changeLoading: (state: PromotionsState, action: PayloadAction<boolean>) => ({
    ...state,
    loading: action.payload
  }),
  fetchPromotionsSuccess: (state: PromotionsState, action: PayloadAction<any>) => ({
    ...state,
    promotions: action.payload.promotions,
    total: action.payload.total
  }),
  changePageNumber: (state: PromotionsState, action: PayloadAction<number>) => {
    return {
      ...state,
      page: action.payload
    }
  }
}

const sliceOption = {
  name: sliceName,
  initialState,
  reducers
}
const slice = createSlice(sliceOption)
const { reducer, actions: reducerActions } = slice

// -----------------------------------------------------

const selectLoading = (state: AppState) => {
  const dataSelected = state[sliceName] as PromotionsState
  return dataSelected?.loading
}

const selectPromotions = (state: AppState) => {
  const dataSelected = state[sliceName] as PromotionsState
  return dataSelected?.promotions || []
}

const selectTotal = (state: AppState) => {
  const dataSelected = state[sliceName] as PromotionsState
  return dataSelected?.total
}

const selectors = {
  selectLoading,
  selectPromotions,
  selectTotal
}

// ---------------------------------------

export const sagaOption = {
  name: sliceName,
  sagaType: SagaType.TakeLatest,
  caseSagas: {
    *fetchPromotions(action: PayloadAction<GetPromotionsParams>): any {
      try {
        yield put(slice.actions.changeLoading(true))

        const { data } = yield call(getPromotions, action.payload)
        yield put(slice.actions.fetchPromotionsSuccess({ promotions: data?.data?.data, total: data?.data?.total }))
      } catch (e: any) {
        showNotification({
          type: 'error',
          message: getErrorMessage(e, 'promotions.failedToFetch')
        })
      } finally {
        yield put(slice.actions.changeLoading(false))
      }
    }
  }
}
const sliceSaga = createSliceSaga(sagaOption)
const { saga, actions: sagaActions } = sliceSaga
// ---------------------------------------

export { initialState, sliceName, reducer, saga, reducerActions, sagaActions, selectors }
