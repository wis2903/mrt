import useLocales from 'hooks/useLocales';
import { reducer, saga, sliceName, sagaActions, reducerActions, selectors } from 'pages/AddSkuPage/slice';
import { useEffect, useCallback } from 'react';
import { useParams } from 'react-router';
import { useAppDispatch, useAppSelector, useInjectReducer, useInjectSaga } from 'store/hooks';

export const useFetchSkuDetail = () => {
  useInjectReducer({ key: sliceName, reducer });
  useInjectSaga({ key: sliceName, saga });

  const { t } = useLocales();

  const dispatch = useAppDispatch();
  const { skuId } = useParams();

  const loading = useAppSelector(selectors.selectLoadingDetail);
  const error = useAppSelector(selectors.selectErrorDetail);
  const skuDetail = useAppSelector(selectors.selectSkuDetail);
  const execute = useCallback(
    () =>
      skuId &&
      dispatch(
        sagaActions.fetchSkuDetail({
          skuId,
          t
        })
      ),
    [dispatch, skuId]
  );
  useEffect(() => {
    if (!skuId) return;

    dispatch(
      sagaActions.fetchSkuDetail({
        skuId,
        t
      })
    );

    return function cleanup() {
      dispatch(reducerActions.removeStore());
    };
  }, [dispatch, skuId]);

  return { loading, error, skuDetail, execute };
};
