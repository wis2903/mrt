export const mockUser = {
  exp: 1671153155,
  iat: 1671152855,
  auth_time: 1671152836,
  jti: 'fe889a13-745c-4f06-b474-20108ea4dc0e',
  iss: 'https://keycloak-ninjamart.apac.positivethinking.tech/realms/InterOp',
  aud: 'account',
  sub: '4cbb86b9-7e53-42a3-ac9c-394168711fc9',
  typ: 'Bearer',
  azp: 'react-auth',
  nonce: '042bba62-36ce-40a8-bad7-6df8eed7fdb5',
  session_state: '17f9d105-597e-40c2-a736-4a5014e35db2',
  acr: '1',
  'allowed-origins': ['https://web-ninjamart-qa-bo.apac.positivethinking.tech', 'http://localhost:3000'],
  realm_access: {
    roles: [
      'OPERATION_HEAD',
      'REPORT_ALL_EXPORTS',
      'default-roles-interop',
      'WAREHOUSE_MANAGER',
      'OPERATION_EXECUTIVE',
      'HEAD_OF_SUPPLY',
      'DEFAULT_INTEROP'
    ]
  },
  resource_access: { account: { roles: ['manage-account', 'manage-account-links', 'view-profile'] } },
  scope: 'openid email profile',
  sid: '17f9d105-597e-40c2-a736-4a5014e35db2',
  email_verified: false,
  name: 'Huy Tran Quoc',
  preferred_username: 'huy.tq@apac.positivethinking.tech',
  given_name: 'Huy',
  family_name: 'Tran Quoc',
  email: 'huy.tq@apac.positivethinking.tech'
};
