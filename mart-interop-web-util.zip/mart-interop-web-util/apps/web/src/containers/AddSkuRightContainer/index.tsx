import { Col, Form, FormInstance, Input, Row, Typography } from 'antd';
import InputNumber from 'components/InputNumber';
import Select from 'components/Select';
import useLocales from 'hooks/useLocales';
import { AddSkuFormFields } from 'pages/AddSkuPage/const';
import { AddSkuForm } from 'pages/AddSkuPage/types';
import React from 'react';
import { useAppSelector } from 'store/hooks';
import { selectors } from 'store/masterData/slice';
import Switch from 'components/Form/Switch';
const { Option } = Select;
const { Title } = Typography;
export interface AddSkuRightContainerProps {
    form: FormInstance<AddSkuForm>;
    readOnly?: boolean;
    showHintText?: boolean;
    canEditSourceOptions?: boolean;
}

const AddSkuRightContainer: React.FC<AddSkuRightContainerProps> = ({
    showHintText,
    form,
    readOnly,
    canEditSourceOptions,
}) => {
    const { t } = useLocales();
    // const countryList = useAppSelector(selectors.selectorByKey('countryList'))
    // const countryOptions: SelectOptions[] = countryList?.map((x) => ({
    //   value: x.id,
    //   label: x.name,
    //   code: x.code
    // }))

    const source = useAppSelector(selectors.selectorByKey('sourceList'));
    const sourceOptions: SelectOptions[] = source?.map((x) => ({
        value: x.id,
        label: t(x.name),
    }));

    return (
        <>
            <Title level={5}>{t('sku.skuDetails')}</Title>
            <Col span={18} offset={6}>
                <Row>
                    <Col span={24}>
                        <Form.Item
                            help={
                                showHintText
                                    ? t('sku.skuCodeDescription')
                                    : undefined
                            }
                            label={t('sku.skuCode')}
                        >
                            <Input
                                value={form.getFieldValue('code')}
                                readOnly
                            />
                        </Form.Item>
                        <Form.Item
                            labelCol={{ span: 8 }}
                            name={AddSkuFormFields.tax}
                            rules={[{ required: true }]}
                            label={t('sku.tax')}
                        >
                            <InputNumber
                                suffix="%"
                                min={0}
                                readOnly={readOnly}
                            />
                        </Form.Item>
                        {/* <Form.Item name={AddSkuFormFields.country} rules={[{ required: true }]} label={t('sku.country')}>
              <Select
                readOnly={readOnly}
                labelInValue
                showSearch
                optionFilterProp='children'
                placeholder='Select (but able to type to search)'
                filterOption={(input, option) =>
                  (option?.children as unknown as string)?.toLowerCase()?.includes(input?.toLowerCase())
                }>
                {countryOptions?.map((x) => (
                  <Option key={x.value} value={x.value}>
                    {x.label}
                  </Option>
                ))}
              </Select>
            </Form.Item> */}
                        <Form.Item
                            name={AddSkuFormFields.usageDays}
                            label={t('No. of usage days.')}
                        >
                            <InputNumber
                                readOnly={readOnly}
                                parser={(value) =>
                                    Number(value) > 0 ? String(value) : ''
                                }
                            />
                        </Form.Item>
                    </Col>
                </Row>
            </Col>
            {/* <Title level={5}>{t('sku.enableSkuFor')}</Title>
      <Row>
        <Col span={18} offset={6}>
          <Row>
            {sourceOptions?.map((sourceOption) => (
              <Col span={12} key={sourceOption.value}>
                <Form.Item
                  labelCol={{ span: 16 }}
                  wrapperCol={{ span: 16 }}
                  colon={false}
                  name={['sources', `${sourceOption.value}`]}
                  valuePropName='checked'
                  label={sourceOption.label}>
                  <Switch disabled={!canEditSourceOptions} />
                </Form.Item>
              </Col>
            ))}
          </Row>
        </Col>
      </Row> */}
        </>
    );
};

export default AddSkuRightContainer;
