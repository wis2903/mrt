import { notification } from 'antd';
import { ArgsProps } from 'antd/lib/notification';
import { intl } from 'containers/LanguageProvider';

type ShowNotificationProps = {
  type: 'success' | 'error' | 'info' | 'warning';
  message: string;
} & ArgsProps;
export function showNotification({ type, message, ...options }: ShowNotificationProps) {
  notification[type]({
    message: intl.formatMessage({
      id: `notification.messageTitle.${type}`
    }),
    description: intl.formatMessage({
      id: message
    }),
    ...options,
    duration: 3,
    placement: 'top'
  });
}

export default showNotification;
