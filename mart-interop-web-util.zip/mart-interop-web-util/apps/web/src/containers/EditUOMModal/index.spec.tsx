import userEvent from '@testing-library/user-event';
import { Form } from 'antd';
import { useForm } from 'antd/lib/form/Form';
import { AddSkuForm } from 'pages/AddSkuPage/types';
import { renderWithProvider, screen } from 'test';
import Component from '.';
import { SKUConfigurationForm } from '../../pages/AddSkuPage/types';

describe('Render component', () => {
  it('should render without crash', async () => {
    const Wrapper = () => {
      const [form] = useForm<AddSkuForm>();
      const configs: SKUConfigurationForm[] = [{ id: 1, name: 'test', generatedName: 'test', quantity: 1, isPrimary: true, image: 'test' }];
      return (
        <Form form={form}>
          <Component
            index={0}
            parentForm={form}
            configurations={configs}
            onSetConfigurations={jest.fn()}
            onChange={jest.fn()}
            onClose={jest.fn()}
          />
        </Form>
      );
    };
    const { container } = renderWithProvider(<Wrapper />);
    await userEvent.click(screen.getByText(/save/i));
    expect(container).toBeTruthy();
  });
});
