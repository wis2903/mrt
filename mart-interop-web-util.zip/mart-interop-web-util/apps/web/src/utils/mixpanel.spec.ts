import { trackOrdersMenuClicked, trackOrdersDetailClicked, trackOrderConfirmed, trackOrderClickActionMenu, initMixpanel } from './mixpanel'
import { MixpanelEvent, MixpanelEventProperty } from 'constants/mixpanelEvents'
import mixpanel from 'mixpanel-browser'
import dotenv from 'dotenv'
import { mockOrder } from 'pages/Orders/mockData'
import { genOrderNumber } from '../pages/Orders/helpers'

dotenv.config({ path: '.env.test' })

jest.mock('mixpanel-browser')
const mockInit = jest.fn()
const mockTrack = jest.fn()
jest.mocked(mixpanel).init.mockImplementation(mockInit)
jest.mocked(mixpanel).track.mockImplementation(mockTrack)

describe('mixpanel utils', () => {
  it('should init successfully', () => {
    initMixpanel()
    expect(mockInit).toBeCalledWith(process.env.VITE_MIXPANEL_TOKEN, { debug: false })
  })
  it('should track "Clicked order list" event correctly', () => {
    trackOrdersMenuClicked()
    expect(mockTrack).toBeCalledWith(MixpanelEvent.CLICKED_ORDER_LIST)
  })
  it('should track "Clicked order detail" event correctly', () => {
    const expectedProperties = {
      [MixpanelEventProperty.ORDER_ID]: genOrderNumber(mockOrder),
      [MixpanelEventProperty.PROVINCE]: mockOrder?.shippingAddressDetails?.shippingProvince
    }

    trackOrdersDetailClicked(mockOrder)

    expect(mockTrack).toBeCalledWith(MixpanelEvent.CLICKED_ORDER_DETAIL, expectedProperties)
  })
  it('should track "Order Confirmed" event correctly', () => {
    const expectedProperties = {
      [MixpanelEventProperty.ORDER_ID]: genOrderNumber(mockOrder),
      [MixpanelEventProperty.PROVINCE]: mockOrder?.shippingAddressDetails?.shippingProvince,
      [MixpanelEventProperty.PAGE]: '/'
    }

    trackOrderConfirmed(mockOrder)

    expect(mockTrack).toBeCalledWith(MixpanelEvent.CONFIRMED_ORDER, expectedProperties)
  })
  it('should track "Clicked on Action menu" event correctly', () => {
    const expectedProperties = {
      [MixpanelEventProperty.ORDER_ID]: genOrderNumber(mockOrder),
      [MixpanelEventProperty.PROVINCE]: mockOrder?.shippingAddressDetails?.shippingProvince,
      [MixpanelEventProperty.PAGE]: '/'
    }

    trackOrderClickActionMenu(mockOrder)

    expect(mockTrack).toBeCalledWith(MixpanelEvent.CLICKED_ON_ACTION_MENU, expectedProperties)
  })
})
