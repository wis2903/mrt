import Forbidden from 'pages/Forbidden';
import LoginPage from 'pages/Login';
import NotAuthorized from 'pages/NotAuthorized';
import React from 'react';
import PrivateRoute from 'routes/PrivateRoute';

import { StyledSpin } from 'components/StyledSpin';
import { AppV2ModuleEnum, AppV2Permission } from 'constants/ability';
import { useAuth } from 'hooks/useAuth';
import { Navigate, Route, Routes, useLocation, useNavigate } from 'react-router-dom';
import { WithSidebarLayoutContainer } from 'v2/app/layouts/with-sidebar-layout/with-sidebar.layout';
import { AppProvider as AppV2Provider } from 'v2/app/providers/app.provider';

import {
    FORBIDDEN,
    HOME_URI,
    INVENTORIES_V2_URI,
    LOGIN_URI,
    NOTIFICATION_V2_CREATE_URI,
    NOTIFICATION_V2_URI,
    NOT_AUTHORIZED,
    ORDER_V2_DETAILS_URI,
    ORDER_V2_URI,
    PRICING_V2_URI,
    PRODUCT_V2_CREATE_URI,
    PRODUCT_V2_DETAILS_URI,
    PRODUCT_V2_URI,
    PROMOTION_V2_CLONE_URI,
    PROMOTION_V2_CREATE_URI,
    PROMOTION_V2_DETAILS_URI,
    PROMOTION_V2_EXTEND_URI,
    PROMOTION_V2_URI,
    RECONCILIATION_V2_URI,
    REPORTS_V2_URI,
    TSP_V2_URI,
} from './routes';

// v2
import PermissionContainer from 'v2/app/layouts/permission-container/permission-container';
import Home from 'v2/app/pages/home/home';
import Inventories from 'v2/app/pages/inventories/inventories';
import NotificationCreator from 'v2/app/pages/notifications/create/create';
import NotificationsList from 'v2/app/pages/notifications/list/list';
import OrderDetails from 'v2/app/pages/orders/details/details';
import Pricing from 'v2/app/pages/pricing/pricing';
import ProductCreator from 'v2/app/pages/products/create/create';
import ProductDetails from 'v2/app/pages/products/details/details';
import PromotionCloneV2 from 'v2/app/pages/promotions/clone/clone';
import PromotionCreatorV2 from 'v2/app/pages/promotions/create/create';
import PromotionDetailsV2 from 'v2/app/pages/promotions/details/details';
import PromotionExtendV2 from 'v2/app/pages/promotions/extend/extend';
import Reconciliation from 'v2/app/pages/reconciliation/reconciliation';
import ReportsPage from 'v2/app/pages/reports/reports';
import Tsp from 'v2/app/pages/tsp/tsp';

// web-2.2
import { Layout } from '../../../web-2.2/src/app/layout';
import { NotFound } from '../../../web-2.2/src/app/page/error/not-found';
import { fm } from '../../../web-2.2/src/app/provider/feature';
import { FeatureCodeEnum } from '../../../web-2.2/src/app/provider/feature/type';
import { ROUTE as ROUTE_2, ROUTE_PATH } from '../../../web-2.2/src/app/router/route';
import { IRoute } from '../../../web-2.2/src/app/router/type';

const [ROUTE_2_WITH_SIDEBAR, ROUTE_2_WITHOUT_SIDEBAR] = (() => {
    const withSidebar: IRoute[] = [];
    const withoutSidebar: IRoute[] = [];

    Object.keys(ROUTE_2).forEach((key) => {
        const item = ROUTE_2[key];
        try {
            if (!item.path || item.path.startsWith('/n')) throw new Error();
            if (item.hasSidebar) withSidebar.push(item);
            else withoutSidebar.push(item);
        } catch (e) {
            // handle error
        } finally {
            item.children?.forEach((child) => {
                if (!child.path || child.path.startsWith('/n')) return;
                if (child.hasSidebar) withSidebar.push(child);
                else withoutSidebar.push(child);
            });
        }
    });

    return [withSidebar, withoutSidebar];
})();

const RedirectComp = ({ url }: { url: string }): JSX.Element => {
    const navigate = useNavigate();

    React.useEffect(() => {
        navigate(url);
    }, []);
    return <></>;
};

const Router = () => {
    const auth = useAuth();
    const location = useLocation();

    return (
        <Routes>
            <Route
                path={LOGIN_URI}
                element={
                    auth?.initialing ? (
                        <StyledSpin size="large" />
                    ) : auth?.user ? (
                        <Navigate to={HOME_URI} state={{ from: location }} replace />
                    ) : (
                        <LoginPage />
                    )
                }
            />
            <Route path={HOME_URI} element={<PrivateRoute />}>
                <Route path={HOME_URI} element={<AppV2Provider />}>
                    <Route path={HOME_URI} element={<WithSidebarLayoutContainer />}>
                        <Route path={HOME_URI} element={<Home />} />

                        <Route
                            path={PRODUCT_V2_URI}
                            element={<RedirectComp url={ROUTE_PATH.productList} />}
                        />

                        <Route
                            path={ORDER_V2_URI}
                            element={<RedirectComp url={ROUTE_PATH.orderList} />}
                        />

                        <Route
                            path={ORDER_V2_DETAILS_URI}
                            element={
                                <PermissionContainer
                                    actionOnInvalid="redirect"
                                    abilities={[
                                        {
                                            module: AppV2ModuleEnum.Order,
                                            permission: AppV2Permission.Details,
                                        },
                                    ]}
                                >
                                    <OrderDetails />
                                </PermissionContainer>
                            }
                        />

                        <Route
                            path={PROMOTION_V2_URI}
                            element={<RedirectComp url={ROUTE_PATH.promoList} />}
                        />

                        <Route
                            path={PRICING_V2_URI}
                            element={
                                <PermissionContainer
                                    actionOnInvalid="redirect"
                                    abilities={[
                                        {
                                            module: AppV2ModuleEnum.Price,
                                            permission: AppV2Permission.Update,
                                        },
                                    ]}
                                >
                                    <Pricing />
                                </PermissionContainer>
                            }
                        />

                        <Route
                            path={INVENTORIES_V2_URI}
                            element={
                                <PermissionContainer
                                    actionOnInvalid="redirect"
                                    abilities={[
                                        {
                                            module: AppV2ModuleEnum.Inventory,
                                            permission: AppV2Permission.List,
                                        },
                                    ]}
                                >
                                    <Inventories />
                                </PermissionContainer>
                            }
                        />

                        <Route
                            path={REPORTS_V2_URI}
                            element={
                                <PermissionContainer
                                    actionOnInvalid="redirect"
                                    abilities={[
                                        {
                                            module: AppV2ModuleEnum.Product,
                                            permission: AppV2Permission.Export,
                                        },
                                        {
                                            module: AppV2ModuleEnum.Order,
                                            permission: AppV2Permission.Export,
                                        },
                                        {
                                            module: AppV2ModuleEnum.Inventory,
                                            permission: AppV2Permission.Export,
                                        },
                                    ]}
                                >
                                    <ReportsPage />
                                </PermissionContainer>
                            }
                        />

                        <Route
                            path={NOTIFICATION_V2_URI}
                            element={
                                <PermissionContainer
                                    actionOnInvalid="redirect"
                                    abilities={[
                                        {
                                            module: AppV2ModuleEnum.Notification,
                                            permission: AppV2Permission.List,
                                        },
                                    ]}
                                >
                                    <NotificationsList />
                                </PermissionContainer>
                            }
                        />

                        {/* Start of router web-2.2 */}
                        <Route path="/v-2.2.0" element={<Layout hasSidebar isPrivate />}>
                            {ROUTE_2_WITH_SIDEBAR.map((item) => (
                                <Route key={item.path} path={item.path} element={item.element} />
                            ))}
                        </Route>
                        {/* End of router web-2.2 */}
                    </Route>

                    {/* Start of router web-2.2 */}
                    <Route path="/v-2.2.0" element={<Layout isPrivate />}>
                        {ROUTE_2_WITHOUT_SIDEBAR.map((item) => (
                            <Route key={item.path} path={item.path} element={item.element} />
                        ))}
                    </Route>
                    {/* End of router web-2.2 */}

                    <Route
                        path={PRODUCT_V2_CREATE_URI}
                        element={
                            <PermissionContainer
                                actionOnInvalid="redirect"
                                abilities={[
                                    {
                                        module: AppV2ModuleEnum.Product,
                                        permission: AppV2Permission.Create,
                                    },
                                ]}
                            >
                                <ProductCreator />
                            </PermissionContainer>
                        }
                    />

                    <Route
                        path={PRODUCT_V2_DETAILS_URI}
                        element={
                            <PermissionContainer
                                actionOnInvalid="redirect"
                                abilities={[
                                    {
                                        module: AppV2ModuleEnum.Product,
                                        permission: AppV2Permission.Details,
                                    },
                                ]}
                            >
                                <ProductDetails />
                            </PermissionContainer>
                        }
                    />

                    <Route
                        path={PROMOTION_V2_CREATE_URI}
                        element={
                            <PermissionContainer
                                actionOnInvalid="redirect"
                                abilities={[
                                    {
                                        module: AppV2ModuleEnum.Promotion,
                                        permission: AppV2Permission.Create,
                                    },
                                ]}
                            >
                                <PromotionCreatorV2 />
                            </PermissionContainer>
                        }
                    />

                    <Route
                        path={PROMOTION_V2_DETAILS_URI}
                        element={
                            <PermissionContainer
                                actionOnInvalid="redirect"
                                abilities={[
                                    {
                                        module: AppV2ModuleEnum.Promotion,
                                        permission: AppV2Permission.Details,
                                    },
                                ]}
                            >
                                <PromotionDetailsV2 />
                            </PermissionContainer>
                        }
                    />

                    <Route
                        path={PROMOTION_V2_EXTEND_URI}
                        element={
                            <PermissionContainer
                                actionOnInvalid="redirect"
                                abilities={[
                                    {
                                        module: AppV2ModuleEnum.Promotion,
                                        permission: AppV2Permission.Update,
                                    },
                                ]}
                            >
                                <PromotionExtendV2 />
                            </PermissionContainer>
                        }
                    />

                    <Route
                        path={PROMOTION_V2_CLONE_URI}
                        element={
                            <PermissionContainer
                                actionOnInvalid="redirect"
                                abilities={[
                                    {
                                        module: AppV2ModuleEnum.Promotion,
                                        permission: AppV2Permission.Create,
                                    },
                                ]}
                            >
                                <PromotionCloneV2 />
                            </PermissionContainer>
                        }
                    />

                    <Route path={RECONCILIATION_V2_URI} element={<Reconciliation />} />

                    <Route
                        path={NOTIFICATION_V2_CREATE_URI}
                        element={
                            <PermissionContainer
                                actionOnInvalid="redirect"
                                abilities={[
                                    {
                                        module: AppV2ModuleEnum.Notification,
                                        permission: AppV2Permission.Create,
                                    },
                                ]}
                            >
                                <NotificationCreator />
                            </PermissionContainer>
                        }
                    />
                </Route>
            </Route>

            {fm.enabled(FeatureCodeEnum.tsp) && <Route path={TSP_V2_URI} element={<Tsp />} />}

            <Route path={NOT_AUTHORIZED} element={<NotAuthorized />} />

            <Route path={FORBIDDEN} element={<Forbidden />} />

            <Route
                path="*"
                element={
                    <Layout>
                        <NotFound />
                    </Layout>
                }
            />
        </Routes>
    );
};

export default Router;
