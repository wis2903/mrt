import { useIntl } from 'react-intl';

// ----------------------------------------------------------------------
export const useTranslate = (id: string, params?: any) => {
  const { formatMessage } = useIntl();
  let values = {};
  if (params) {
    Object.keys(params).forEach((key) => {
      values = {
        ...values,
        [key]: formatMessage({ id: params[key] })
      };
    });
  }
  return formatMessage({ id }, values);
};

export type LocalizationKey = 'vi' | 'en';

export default function useLocales() {
  const intl = useIntl();
  const t = (id: string, values?: Record<string, string>) => {
    if (values) {
      Object.keys(values).forEach(function (key) {
        const isId = values[key].indexOf('.');
        values[key] = isId !== -1 ? intl.formatMessage({ id: values[key] }) : values[key];
      });
      return intl.formatMessage({ id }, values);
    }
    return intl.formatMessage({ id });
  };

  return { t };
}
