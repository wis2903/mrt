import { getOrderActivityLog } from './reports';

describe('getOrderActivityLog', () => {
  it('Should export data', async () => {
    getOrderActivityLog('test');
  });
});
