import { css } from 'styled-components'

export const baseInputStyle = css`
  & .ant-input-number-group {
    border: 1px solid #d9d9d9;
    &:hover {
      border-color: #cf363d;
    }

    &-addon {
      border: none;
      color: #8f8f8f;

      &:first-child {
        background-color: #ffffff;
        padding-right: 0;
      }
      &:last-child {
        background-color: #ffffff;
        padding-left: 0;
      }
    }
    .ant-input-number {
      border: none;

      &:hover {
        border: none;
      }
      &:focus,
      &.ant-input-number-focused {
        box-shadow: none;
        outline: 0;
      }

      .ant-input-number-input {
        text-align: right;
        padding-right: 4px;
      }
    }
  }
`
