import * as authHook from 'hooks/useAuth';
import { renderWithProvider } from 'test';
import Component from '.';
const data = {
  user: {},
  province: [],
  keycloak: null,
  initialing: false,
  signin: jest.fn(),
  signout: jest.fn()
};
describe('PrivateRoute', () => {
  it('should render normally with truthy user', () => {
    jest.spyOn(authHook, 'useAuth').mockReturnValueOnce(data);
    const { container } = renderWithProvider(<Component />);
    expect(container).toBeTruthy();
  });
  it('should render normally with user null', () => {
    jest.spyOn(authHook, 'useAuth').mockReturnValueOnce({ ...data, user: null });
    const { container } = renderWithProvider(<Component />);
    expect(container).toBeTruthy();
  });
});
