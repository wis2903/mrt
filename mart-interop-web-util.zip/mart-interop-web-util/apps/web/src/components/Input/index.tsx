import { Input as AntdInput, InputProps } from 'antd';
import { MAX_LENGTH_INPUT } from 'constants/common';
import { InputStyled } from './styled';

export interface InputComponentProps extends InputProps {
  suffix?: string;
}

const Input: React.FC<InputComponentProps> = ({ suffix, ...props }) => {
  return (
    <InputStyled suffix={suffix}>
      <AntdInput maxLength={MAX_LENGTH_INPUT} {...props} />
      <div className='suffix'>{suffix}</div>
    </InputStyled>
  );
};

export default Input;
