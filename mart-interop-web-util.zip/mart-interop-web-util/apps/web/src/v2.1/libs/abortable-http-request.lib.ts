import { toCaseTransformed } from 'v2.1/common/util';

export enum TransformTypeEnum {
    camelCase = 'camelCase',
    snakeCase = 'snakeCase',
}

export enum RequestMethodEnum {
    get = 'GET',
    post = 'POST',
    put = 'PUT',
    patch = 'PATCH',
    delete = 'DELETE',
}

export enum RequestConfigTypeEnum {
    transformRequest = 'transformRequest',
    transformResponse = 'transformResponse',
}

interface IRequestConfigs {
    [RequestConfigTypeEnum.transformRequest]?: TransformTypeEnum;
    [RequestConfigTypeEnum.transformResponse]?: TransformTypeEnum;
}

interface IRequest extends IRequestConfigs {
    url?: string;
    method?: RequestMethodEnum;
}

export interface IResponse {
    status: number;
    hasError?: boolean;
    message?: string;
    data?: Record<string, unknown> | string;
}

class AbortableHttpRequest {
    private _baseURL: string;
    private _headers: Record<string, string>;
    private _controller: AbortController;
    private _params: Record<string, unknown>;
    private _method: RequestMethodEnum;
    private _configs: IRequestConfigs;

    constructor() {
        this._baseURL = '';
        this._headers = {};
        this._controller = new AbortController();
        this._params = {};
        this._method = RequestMethodEnum.get;
        this._configs = {};
    }

    public setBaseURL(url: string): void {
        this._baseURL = url;
    }

    public extendsBaseURL(value: string): void {
        this._baseURL += value;
    }

    public setMethod(method: RequestMethodEnum): void {
        this._method = method;
    }

    public setHeader(key: string, value: string): void {
        this._headers[key] = value;
    }

    public setConfig(key: RequestConfigTypeEnum, value: TransformTypeEnum): void {
        this._configs[key] = value;
    }

    public setParams(params: Record<string, unknown>): void {
        this._params = params;
    }

    public call(props?: IRequest): Promise<IResponse> {
        const { url, method, ...configs } = props || {};

        return new Promise((resolve) => {
            const _configs = configs || this._configs;
            const _method = method || this._method;
            let _url = `${this._baseURL}${url || ''}`;
            let _params: Record<string, unknown> = { ...this._params };

            if (_configs.transformRequest) {
                _params = toCaseTransformed(_params, _configs.transformRequest) as Record<
                    string,
                    unknown
                >;
            }

            if ([RequestMethodEnum.get, RequestMethodEnum.delete].includes(_method)) {
                let search = '';
                Object.keys(_params).forEach((key) => {
                    if (Array.isArray(_params[key])) {
                        (_params[key] as unknown[]).forEach((item) => {
                            search += `&${key}=${item}`;
                        });
                    } else {
                        search += `&${key}=${_params[key]}`;
                    }
                });
                if (search) search = `?${search.substring(1)}`;
                _url = `${_url}${search}`;
            }

            fetch(_url, {
                method: method || this._method,
                headers: this._headers,
                body: [
                    RequestMethodEnum.post,
                    RequestMethodEnum.put,
                    RequestMethodEnum.patch,
                ].includes(_method)
                    ? JSON.stringify(_params)
                    : undefined,
                signal: this._controller.signal,
            })
                .then((response) => {
                    this._processResponse(response, _configs).then((result) => {
                        resolve(result);
                    });
                })
                .catch((e) => {
                    resolve({
                        status: 500,
                        message: Object(e).message,
                        hasError: true,
                    });
                });
        });
    }

    public abort(): void {
        this._controller.abort();
    }

    private _processResponse(response: Response, configs?: IRequestConfigs): Promise<IResponse> {
        return new Promise((resolve) => {
            response
                .text()
                .then((text) => {
                    let json: Record<string, unknown> | undefined;
                    try {
                        json = JSON.parse(text);
                        if (configs?.transformResponse) {
                            json = toCaseTransformed(json, configs.transformResponse) as Record<
                                string,
                                unknown
                            >;
                        }
                    } catch (e) {
                        json = undefined;
                    }

                    if (response.status !== 200) {
                        resolve({
                            status: response.status,
                            message: `Request failed with status ${response.status}`,
                            data: json || text,
                            hasError: true,
                        });
                    } else {
                        resolve({
                            status: 200,
                            data: json || text,
                        });
                    }
                })
                .catch((e) => {
                    resolve({
                        status: 500,
                        message: Object(e).message,
                        hasError: true,
                    });
                });
        });
    }
}

export default AbortableHttpRequest;
