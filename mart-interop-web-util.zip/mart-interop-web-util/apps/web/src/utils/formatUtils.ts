import numeral from 'numeral';
export const formatterMoney = (val: any) => {
  return numeral(val).format('0,0');
};

export const parserMoney = (val: any) => {
  return Math.ceil(Number.parseFloat(val.replace(/\$\s?|(,*)/g, '')));
};

export const formatUOMName = (index: number, name: string) => {
  return `Type ${index + 1} UOM ${name}`;
};

export const formatUOMNameForm = (name: string, quantity: string) => {
  if (name && quantity) {
    const _quantity = parseInt(quantity);
    if (_quantity === 1) {
      return `${name} - Unit - 1`;
    } else if (_quantity > 1) {
      return `${name} - Carton - ${quantity}`;
    }
  }
};
