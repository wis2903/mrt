/* istanbul ignore file */
import { SKUS_URI } from '../../routes/routes';
import {
  createSku,
  CreateSkuParams,
  deleteSku,
  getSkuDetail,
  GetSkuDetailParams,
  UpdateSkuParams,
  DeleteSkuParams,
  getSkuList,
  SourceOptionsParams,
  updateSkuWithSource
} from '../../apis/sku';
import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { call, put } from 'redux-saga/effects';
import { createSliceSaga, SagaType } from 'redux-toolkit-saga';
import { AppState } from 'store/store';
import { notification } from 'antd';
import { NavigateFunction } from 'react-router';
import SkuDetail, { GetSkuListParams, SkuListSearchForm } from 'types/SKUDetail';
import { DEFAULT_PAGE_NUMBER, DEFAULT_PAGE_SIZE } from 'constants/common';
import { AddSkuForm } from './types';

// ---------------------------------------
const sliceName = 'sku';

type SkuState = {
  loading?: boolean;
  skuDetail?: SkuDetail;
  loadingDetail?: boolean;
  errorDetail?: string | null;
  skuList?: SkuDetail[];
  total?: number;
  search?: SkuListSearchForm;
  pageNumber: number;
  pageSize: number;
  formData?: AddSkuForm;
  saving?: boolean;
};

export interface CreateSkuAction {
  params: CreateSkuParams;
  navigate: NavigateFunction;
  t: (key: string) => string;
}

export interface UpdateSkuAction {
  params: UpdateSkuParams;
  sourceOptionsParams: SourceOptionsParams;
  callback: () => void;
  t: (key: string) => string;
}

const initialState: SkuState = {
  pageNumber: DEFAULT_PAGE_NUMBER,
  pageSize: DEFAULT_PAGE_SIZE
};

// ---------------------------------------
const reducers = {
  changeLoading: (state: SkuState, action: PayloadAction<boolean>) => ({
    ...state,
    loading: action.payload
  }),
  changeLoadingDetail: (state: SkuState, action: PayloadAction<boolean>) => ({
    ...state,
    loadingDetail: action.payload
  }),
  changeErrorDetail: (state: SkuState, action: PayloadAction<string | null>) => ({
    ...state,
    errorDetail: action.payload
  }),
  changeSaving: (state: SkuState, action: PayloadAction<boolean>) => ({
    ...state,
    saving: action.payload
  }),
  fetchSkuDetailSuccess: (state: SkuState, action: PayloadAction<SkuDetail>) => ({
    ...state,
    skuDetail: action.payload
  }),
  fetchSkuListSuccess: (state: SkuState, action: PayloadAction<any>) => ({
    ...state,
    skuList: action.payload.data,
    total: action.payload.totalElement
  }),
  changeSearch: (state: SkuState, action: PayloadAction<SkuListSearchForm>) => {
    return {
      ...state,
      search: { ...state.search, ...action.payload },
      pageNumber: DEFAULT_PAGE_NUMBER,
      pageSize: DEFAULT_PAGE_SIZE
    };
  },
  changePageNumber: (state: SkuState, action: PayloadAction<number>) => {
    return {
      ...state,
      pageNumber: action.payload
    };
  },
  changePageSize: (state: SkuState, action: PayloadAction<number>) => {
    return {
      ...state,
      pageSize: action.payload
    };
  },
  changeFormData: (state: SkuState, action: PayloadAction<AddSkuForm>) => {
    return {
      ...state,
      formData: action.payload
    };
  },
  removeStore: () => initialState
};

const sliceOption = {
  name: sliceName,
  initialState,
  reducers
};
const slice = createSlice(sliceOption);
const { reducer, actions: reducerActions } = slice;

// -----------------------------------------------------

const selectLoading = (state: AppState) => {
  const dataSelected = state[sliceName] as SkuState;
  return dataSelected?.loading;
};

const selectLoadingDetail = (state: AppState) => {
  const dataSelected = state[sliceName] as SkuState;
  return dataSelected?.loadingDetail;
};

const selectErrorDetail = (state: AppState) => {
  const dataSelected = state[sliceName] as SkuState;
  return dataSelected?.errorDetail;
};

const selectSaving = (state: AppState) => {
  const dataSelected = state[sliceName] as SkuState;
  return dataSelected?.saving;
};

const selectSkuDetail = (state: AppState) => {
  const dataSelected = state[sliceName] as SkuState;
  return dataSelected?.skuDetail;
};

const selectSkuList = (state: AppState) => {
  const dataSelected = state[sliceName] as SkuState;
  return dataSelected?.skuList;
};

const selectTotal = (state: AppState) => {
  const dataSelected = state[sliceName] as SkuState;
  return dataSelected?.total;
};

const selectSearch = (state: AppState) => {
  const dataSelected = state[sliceName] as SkuState;
  return dataSelected?.search;
};

const selectPageNumber = (state: AppState) => {
  const dataSelected = state[sliceName] as SkuState;
  return dataSelected?.pageNumber;
};

const selectPageSize = (state: AppState) => {
  const dataSelected = state[sliceName] as SkuState;
  return dataSelected?.pageSize;
};

const selectFormData = (state: AppState) => {
  const dataSelected = state[sliceName] as SkuState;
  return dataSelected?.formData;
};

const selectors = {
  selectLoading,
  selectLoadingDetail,
  selectErrorDetail,
  selectSaving,
  selectSkuDetail,
  selectSkuList,
  selectTotal,
  selectSearch,
  selectPageNumber,
  selectPageSize,
  selectFormData
};

// ---------------------------------------

const sagaOption = {
  name: sliceName,
  sagaType: SagaType.TakeLatest,
  caseSagas: {
    *createSku(action: PayloadAction<CreateSkuAction>): any {
      try {
        yield put(slice.actions.changeLoading(true));

        const { data } = yield call(createSku, action.payload.params);

        notification.success({
          message: action.payload.t('Success'),
          description: action.payload.t('Product SKU created successfully.'),
          placement: 'top'
        });

        const navigate = action.payload.navigate;
        navigate(`${SKUS_URI}/${data.data.id}`);
      } catch (err: any) {
        notification.error({
          message: action.payload.t('Failed'),
          description: err.response?.data?.title || action.payload.t('Failed to create Product SKU, please try again.'),
          placement: 'top'
        });
      } finally {
        yield put(slice.actions.changeLoading(false));
      }
    },
    *updateSku(action: PayloadAction<UpdateSkuAction>): any {
      try {
        yield put(slice.actions.changeSaving(true));

        yield call(updateSkuWithSource, action.payload.params, action.payload.sourceOptionsParams);

        notification.success({
          message: action.payload.t('Success'),
          description: action.payload.t('Product SKU updated successfully.'),
          placement: 'top'
        });
        action.payload.callback();
      } catch (err: any) {
        notification.error({
          message: `Failed`,
          description: err.response?.data?.title || action.payload.t('Failed to update Product SKU, please try again.'),
          placement: 'top'
        });
      } finally {
        yield put(slice.actions.changeSaving(false));
      }
    },
    *deleteSku(action: PayloadAction<DeleteSkuParams & { callback: () => void }>): any {
      try {
        yield put(slice.actions.changeLoading(true));

        yield call(deleteSku, action.payload);

        notification.success({
          message: action.payload.t('Success'),
          description: action.payload.t('Product SKU deleted successfully.'),
          placement: 'top'
        });
        yield action.payload.callback?.();
      } catch (err: any) {
        notification.error({
          message: action.payload.t('Failed'),
          description: err?.response?.data?.title || action.payload.t('Failed to delete Product SKU, please try again.'),
          placement: 'top'
        });
      } finally {
        yield put(slice.actions.changeLoading(false));
      }
    },
    *fetchSkuDetail(action: PayloadAction<GetSkuDetailParams>): any {
      try {
        yield put(slice.actions.changeLoadingDetail(true));
        yield put(slice.actions.changeErrorDetail(null));

        const { data } = yield call(getSkuDetail, action.payload);

        yield put(slice.actions.fetchSkuDetailSuccess(data.data));
      } catch (e: any) {
        notification.error({
          message: action.payload.t('Failed'),
          description: e.response?.data?.title || action.payload.t('Failed to fetch Product SKU detail, please try again.'),
          placement: 'top'
        });
        yield put(slice.actions.changeErrorDetail(action.payload.t('Failed to fetch Product SKU detail, please try again.')));
      } finally {
        yield put(slice.actions.changeLoadingDetail(false));
      }
    },
    *fetchSkuList(action: PayloadAction<GetSkuListParams>): any {
      try {
        yield put(slice.actions.changeLoading(true));

        const { data } = yield call(getSkuList, action.payload);

        yield put(slice.actions.fetchSkuListSuccess(data));
      } catch (e: any) {
        notification.error({
          message: action.payload.t('Failed'),
          description: e.response?.data?.title || action.payload.t('Failed to fetch SKU list, please try again.'),
          placement: 'top'
        });
      } finally {
        yield put(slice.actions.changeLoading(false));
      }
    }
  }
};
const sliceSaga = createSliceSaga(sagaOption);
const { saga, actions: sagaActions } = sliceSaga;
// ---------------------------------------

export { initialState, sliceName, reducer, saga, reducerActions, sagaActions, selectors };
