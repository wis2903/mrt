import { FilterComparisonEnum } from './@types/filter.type'

export const FILTER_COMPARISION_FOR_STRING = [
  FilterComparisonEnum.stringContains,
  FilterComparisonEnum.stringEquals,
  FilterComparisonEnum.stringNotEquals,
  FilterComparisonEnum.empty,
  FilterComparisonEnum.notEmpty
]

export const FILTER_COMPARISION_FOR_NUMBER = [
  FilterComparisonEnum.numberEquals,
  FilterComparisonEnum.numberNotEquals,
  FilterComparisonEnum.numberSmaller,
  FilterComparisonEnum.numberSmallerOrEquals,
  FilterComparisonEnum.numberGreater,
  FilterComparisonEnum.numberGreaterOrEquals,
  FilterComparisonEnum.empty,
  FilterComparisonEnum.notEmpty
]

export const FILTER_COMPARISION_FOR_PRESET = [
  FilterComparisonEnum.stringEquals,
  FilterComparisonEnum.stringNotEquals,
  FilterComparisonEnum.empty,
  FilterComparisonEnum.notEmpty
]

export const DEFAULT_NUMBER_ITEMS_PER_PAGE = 12
export const DEFAULT_MAX_DISPLAYED_NAVIGATION_NAV_NUMBER = 6
