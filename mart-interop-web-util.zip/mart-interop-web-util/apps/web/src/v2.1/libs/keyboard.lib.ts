export enum KeyboardEventEnum {
    enter = 'Enter',
    arrowUp = 'ArrowUp',
    arrowDown = 'ArrowDown',
    escape = 'Escape',
}

class Keyboard {
    private _onEnterListener?: VoidFunction;
    private _onArrowUpListener?: VoidFunction;
    private _onArrowDownListener?: VoidFunction;
    private _onEscapeListener?: VoidFunction;

    constructor() {
        this._onEnterListener = undefined;
        this._onArrowUpListener = undefined;
        this._onArrowDownListener = undefined;
        this._onEscapeListener = undefined;
    }

    public register(event: KeyboardEventEnum, callback: VoidFunction): void {
        switch (event) {
            case KeyboardEventEnum.enter:
                this._onEnterListener = callback;
                break;
            case KeyboardEventEnum.arrowUp:
                this._onArrowUpListener = callback;
                break;
            case KeyboardEventEnum.arrowDown:
                this._onArrowDownListener = callback;
                break;
            case KeyboardEventEnum.escape:
                this._onEscapeListener = callback;
                break;
            default:
                break;
        }
    }

    public trigger(): void {
        window.addEventListener('keyup', this._handleOnKeyUp);
    }

    public unregister(): void {
        window.removeEventListener('keyup', this._handleOnKeyUp);
    }

    _handleOnKeyUp = (e: KeyboardEvent): void => {
        switch (e.key) {
            case KeyboardEventEnum.enter:
                this._onEnterListener?.();
                break;
            case KeyboardEventEnum.arrowUp:
                this._onArrowUpListener?.();
                break;
            case KeyboardEventEnum.arrowDown:
                this._onArrowDownListener?.();
                break;
            case KeyboardEventEnum.escape:
                this._onEscapeListener?.();
                break;
            default:
                break;
        }
    };
}

export default Keyboard;
