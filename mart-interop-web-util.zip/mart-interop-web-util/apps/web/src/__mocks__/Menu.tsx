const Menu: React.FC<any> = ({ items }) => {
  return (
    <div>
      {items.map((it: any) => (
        <span key={it.key} data-testid={`${it.key}`} onClick={() => it.onClick?.(it)}>
          {it.label}
        </span>
      ))}
    </div>
  );
};

export default Menu;
