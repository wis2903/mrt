// date format
export const FULL_DATE_FORMAT = 'YYYY-MM-DD HH:mm:ss';
export const DATE_TIME_NO_SECONDS_FORMAT = 'YYYY-MM-DD HH:mm';
export const ISO_DATE_FORMAT = 'YYYY/MM/DD';
export const DOT_DATE_FORMAT = 'YYYY.MM.DD';
export const NORMAL_DATE_FORMAT = 'YYYY-MM-DD';
export const MONTH_FORMAT = 'YYYY-MM';
export const YEAR_MONTH_FORMAT = 'yyyy-MM';
export const NORMAL_TIME_FORMAT = 'HH:mm';
export const YEAR_FORMAT = 'YYYY';
export const DAY_MONTH_YEAR_FORMAT = 'DD/MM/YYYY';
export const DAY_MONTH_YEAR_TIME_FORMAT = 'DD/MM/YYYY HH:mm';
export const TIME_FORMAT = 'YYYY-MM-DDTHH:mm:ssZ';
export const TIME_FORMAT_2 = 'YYYY-MM-DDTHH:mm:ss[Z]';
export const ABBREVIATED_MONTH_FORMAT = 'DD MMM YYYY hh:mma';

// token
export const ACCESS_TOKEN = 'token';
export const REFRESH_TOKEN = 'refreshToken';

// Api time = 0 => no timeout
export const API_TIMEOUT = 0;

export const CURRENCY = 'VND';
export const MAX_QUANTITY = 99;

// local storage key
export const LOCAL_STORAGE_KEY = {
    LOCATION: 'location',
    KC_TOKEN: 'kc_token',
    KC_REFRESH_TOKEN: 'kc_refreshToken',
    LAST_ACCESS_URL: 'last_access_url',
};

export const RESEND_OTP_TIME_SECONDS = 300;
export const STATUS_CODE_OK = 'OK';

export const MAX_LENGTH_TEXT_AREA = 1000;
export const MAX_LENGTH_INPUT = 100;

export enum COUNTRY_CODE {
    VIETNAM = 'VN',
}

export const PAGE_SIZE_OPTIONS = [10, 20, 50, 100];
export const DEFAULT_PAGE_SIZE = PAGE_SIZE_OPTIONS[0];
export const DEFAULT_PAGE_NUMBER = 1;

export const DELAY_INPUT_TIME = 300;
export const LANG_KEY = 'lang';

export const SOURCE_MAPPING: Record<string, string> = {
    '4': 'Haravan',
    '5': 'AMAST',
};

export const PAYMENT_METHOD: Record<string, string> = {
    COD: 'Thanh toán khi giao hàng (COD)',
};
