import apiClient from './apiClient';
import { exportInventory } from './inventory';

describe('exportInventory', () => {
  it('Should export data', async () => {
    const data = {
      warehouseId: 'test'
    };
    const spy = jest.spyOn(apiClient, 'get');
    spy.mockReturnValueOnce(Promise.resolve({}));
    const result = await exportInventory(data);
    spy.mockReturnValueOnce(Promise.resolve({}));
    await exportInventory({ warehouseId: '' });
    expect(result).toEqual({});
  });
});
