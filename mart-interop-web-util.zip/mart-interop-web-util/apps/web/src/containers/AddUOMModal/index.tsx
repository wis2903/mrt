import { PlusOutlined } from '@ant-design/icons';
import { FormInstance, Modal } from 'antd';
import React, { FormEvent, useState } from 'react';
import UOMForm from 'containers/UOMForm';
import { AddSkuForm, SKUConfigurationForm } from 'pages/AddSkuPage/types';
import Button from 'components/Button'
import useLocales from 'hooks/useLocales';
export interface AddUOMModalProps {
  hidden: boolean;
  disabled: boolean;
  parentForm: FormInstance<AddSkuForm>;
  configurations: SKUConfigurationForm[];
  onSetConfigurations: (configurations: SKUConfigurationForm[]) => void;
  onChange: (event: FormEvent<HTMLFormElement>) => void;
  isNew?: boolean;
}
const AddUOMModal: React.FC<AddUOMModalProps> = ({
  isNew,
  hidden,
  disabled,
  parentForm,
  configurations,
  onChange,
  onSetConfigurations
}) => {
  const { t } = useLocales();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const showModal = () => {
    setIsModalOpen(true);
  };
  const handleFinish = (values: SKUConfigurationForm) => {
    onSetConfigurations([...configurations, values]);
    setIsModalOpen(false);
  };

  const handleCancel = () => {
    setIsModalOpen(false);
  };
  const disableQuantity = !configurations.length;
  const initialValues = {
    quantity: disableQuantity ? 1 : undefined
  };
  return (
    <>
      <Button type='primary' onClick={showModal} hidden={hidden} disabled={disabled} data-testid='add-uom'>
        <PlusOutlined className='align-[inherit]' /> {t('common.Add UOM')}
      </Button>
      <Modal
        title={t('common.Add new a unit of measurement')}
        width={1000}
        visible={isModalOpen}
        destroyOnClose
        onCancel={handleCancel}
        footer={[
          <Button key='back' onClick={handleCancel}>
            {t('common.button.cancel')}
          </Button>,
          <Button key='submit' form='modalForm' type='primary' htmlType='submit'>
            {t('common.button.save')}
          </Button>
        ]}>
        <UOMForm
          selected={-1}
          isNew={isNew}
          parentForm={parentForm}
          disableQuantity={disableQuantity}
          initialValues={initialValues}
          configurations={configurations}
          onChange={onChange}
          onFinish={handleFinish}
        />
      </Modal>
    </>
  );
};

export default AddUOMModal;
