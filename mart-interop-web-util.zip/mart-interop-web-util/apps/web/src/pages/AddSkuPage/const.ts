import { AddSkuForm } from './types';

export type IAddSkuFormFields = {
  [key in keyof AddSkuForm]: key;
};

export const AddSkuFormFields: IAddSkuFormFields = {
  name: 'name',
  description: 'description',
  brand: 'brand',
  usageDays: 'usageDays',
  category: 'category',
  code: 'code',
  country: 'country',
  source: 'source',
  tax: 'tax',
  skuConfigurations: 'skuConfigurations',
  displayDms: 'displayDms',
  displayHaravan: 'displayHaravan',
  displayNinjaMartOnZalo: 'displayNinjaMartOnZalo',
  displayNinjaMartOnWhatsapp: 'displayNinjaMartOnWhatsapp'
};

export const HINT_TEXT = 'NJM123456';
