import { fireEvent, renderWithProvider, screen, waitFor } from 'test';
import Component from '.';
import * as slice from 'store/masterData/slice';
import * as skuSlice from './slice';
import userEvent from '@testing-library/user-event';
import sinon from 'sinon';

sinon.stub(slice.selectors, 'selectLoading').returns(false);

describe('Render component', () => {
  it('should render without crash', () => {
    jest.spyOn(slice.selectors, 'selectLoading').mockReturnValueOnce(() => true);
    const { container } = renderWithProvider(<Component />);

    expect(container).toBeTruthy();
  });
  it('should render without crash', () => {
    jest.spyOn(slice.selectors, 'selectorByKey').mockReturnValue(() => [
      {
        id: 1,
        code: 'test',
        name: 'test',
        parentId: 2,
        parentName: 'test'
      }
    ]);
    const { container } = renderWithProvider(<Component />);

    expect(container).toBeTruthy();
  });
});
describe('actions', () => {
  afterEach(() => {
    jest.clearAllMocks();
    jest.restoreAllMocks();
  });
  it('should add', async () => {
    jest.spyOn(slice.selectors, 'selectorByKey').mockImplementation(() => () => [
      {
        id: 1,
        code: 'test',
        name: 'test',
        parentId: 2,
        parentName: 'test'
      }
    ]);
    const spyCreateSku = jest.spyOn(skuSlice.sagaActions, 'createSku');
    const user = userEvent.setup();
    renderWithProvider(<Component />);
    await user.type(screen.getByLabelText(/Product Name/), 'name');
    await user.type(screen.getByLabelText(/Description/), 'Description');
    await user.type(screen.getByLabelText(/Tax/), '3');
    await user.type(screen.getAllByTestId('select-onChange')[0], 'test');
    await user.type(screen.getAllByTestId('select-onChange')[1], 'test');
    await user.type(screen.getAllByTestId('select-onChange')[2], 'test');
    const addFormBtn = screen.getByRole('button', {
      name: /plus add uom/i
    });
    await user.click(addFormBtn);
    await user.type(screen.getByTestId('uom-name'), 'Name (UOM)');
    await user.type(
      screen.getByRole('textbox', {
        name: /quantity/i
      }),
      '1'
    );
    await user.click(
      screen.getByRole('checkbox', {
        name: /primary/i
      })
    );
    const uploadBeforeUpload = screen.queryByTestId('upload-onChange');
    const file = new File(['hello'], 'hello.png', { type: 'image/svg+xml' });
    uploadBeforeUpload && fireEvent.change(uploadBeforeUpload, { file: file, files: [file] });
    await user.click(
      screen.getAllByRole('button', {
        name: /save/i
      })[1]
    );
    await waitFor(() =>
      screen.getByRole('cell', {
        name: /check/i
      })
    );
    const saveBtn = screen.getAllByText(/Save/)[0];
    await userEvent.click(saveBtn);

    expect(spyCreateSku).toBeCalledTimes(1);
  });
});
