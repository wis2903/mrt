import { Col, Form, Row, Typography, Checkbox } from 'antd';
import Input from 'components/Input';
import InputNumber from 'components/InputNumber';
import React, { FormEvent, useEffect, useState } from 'react';
import UploadImage from 'components/UploadImage';
import { FormInstance, Rule } from 'antd/lib/form';
import { SKUConfigurationForm } from 'pages/AddSkuPage/types';
import { formatUOMNameForm } from 'utils/formatUtils';
import { AddSkuForm } from '../../pages/AddSkuPage/types';
import useLocales from 'hooks/useLocales';
import { validateBarcode } from 'apis/sku';
import { useAppSelector } from 'store/hooks';
import { selectors } from 'pages/AddSkuPage/slice';
export interface UOMFormProps {
  isNew?: boolean;
  parentForm: FormInstance<AddSkuForm>;
  disableQuantity: boolean;
  initialValues: Partial<SKUConfigurationForm>;
  selected: null | number;
  configurations: SKUConfigurationForm[];
  onFinish: (configurations: SKUConfigurationForm) => void;
  onChange: (e: FormEvent<HTMLFormElement>) => void;
}
const UOMForm: React.FC<UOMFormProps> = ({
  isNew,
  parentForm,
  initialValues,
  disableQuantity,
  selected,
  configurations,
  onChange,
  onFinish
}) => {
  const { t } = useLocales();
  const skuDetail = useAppSelector(selectors.selectSkuDetail);
  const [modalForm] = Form.useForm<SKUConfigurationForm>();
  const [, setFormValues] = useState({});
  const cannotSameNameValidator: Rule = () => ({
    validator(_, value) {
      const remainingConfigurations = configurations.filter((_, i) => i !== Number(selected));
      const isExisted = remainingConfigurations.find((skuConfigurationsField) => skuConfigurationsField.name === value);
      if (isExisted) {
        return Promise.reject(new Error(t('common.Name is duplicated.')));
      }
      return Promise.resolve();
    }
  });
  const cannotBeLessThanOneValidator: Rule = () => ({
    validator(_, value) {
      if (value && value.length && value < 1) {
        return Promise.reject(new Error(t('common.Quantity must greater than 0.')));
      }
      return Promise.resolve();
    }
  });
  const wasExisted: Rule = () => ({
    validateTrigger: 'onBlur',
    validator: async (_, value) => {
      if (!value) {
        return Promise.resolve();
      }
      const {
        data: { data: isValid }
      } = await validateBarcode({ skuId: isNew ? undefined : skuDetail?.id, barcode: value });
      return isValid ? Promise.resolve() : Promise.reject(new Error(t('common.The barcode is duplicated with another SKU.')));
    }
  });
  useEffect(() => {
    setFormValues({});
  }, []);
  return (
    <>
      <Form
        id='modalForm'
        form={modalForm}
        layout='horizontal'
        labelWrap
        labelCol={{ span: 8 }}
        wrapperCol={{ span: 16 }}
        labelAlign='left'
        initialValues={initialValues}
        onValuesChange={setFormValues}
        onChange={(e) => {
          e.stopPropagation();
          onChange(e);
        }}
        onFinish={onFinish}
        validateTrigger={['onBlur', 'onChange']}
        validateMessages={{
          required: t('common.message.required')
        }}>
        <Row gutter={40}>
          <Col span={12}>
            <Form.Item name='id' hidden></Form.Item>
            <Form.Item label={t('common.Display Name')} name='name' rules={[{ required: true }, cannotSameNameValidator]}>
              <Input placeholder='' data-testid='uom-name' />
            </Form.Item>
            <Form.Item label={t('common.Name')} tooltip={t('common.This field is auto-generated')}>
              {formatUOMNameForm(parentForm.getFieldValue('name'), modalForm.getFieldValue('quantity'))}
            </Form.Item>
            <Form.Item
              label={t('common.Quantity')}
              name='quantity'
              rules={[{ required: true }, cannotBeLessThanOneValidator]}
              tooltip={
                <>
                  <div>{t("common.The first UOM is set 1 by default and can't be updated.")}</div>
                  <div>{t('common.Other UOMs can be edited.')}</div>
                </>
              }>
              <Input placeholder='' disabled={disableQuantity} data-testid='quantity' />
            </Form.Item>
            <Form.Item label={t('common.Barcode')} name='barcode' rules={[wasExisted]}>
              <Input placeholder='' data-testid='barcode' />
            </Form.Item>
            <Form.Item label={t('common.Gross weight')} name='grossWeight' rules={[{required: true}]}>
              <InputNumber suffix={t('grams')} />
            </Form.Item>
            <Form.Item label={t('common.Net weight')} name='netWeight'>
              <InputNumber suffix={t('grams')} />
            </Form.Item>
            <Form.Item label={t('common.Volume')} name='volume'>
              <InputNumber suffix={t('milliliters')} />
            </Form.Item>
            <Form.Item label={t('common.Primary')} name='isPrimary' valuePropName='checked'>
              <Checkbox />
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item label={t('common.Image')} labelCol={{ span: 24 }} wrapperCol={{ span: 24 }} required>
              <Typography.Text type='secondary'>
                <small>
                  {t('common.Thumbnail Requirements')}:
                  <br />
                  <ul>
                    <li>{t('common.Only .jpg, .jpeg and .png are supported')}</li>
                    <li>{t('common.Max file-size should be 10MB')}</li>
                  </ul>
                </small>
              </Typography.Text>
              <Form.Item name='image' rules={[{ required: true }]}>
                <UploadImage />
              </Form.Item>
            </Form.Item>
          </Col>
        </Row>
      </Form>
    </>
  );
};

export default UOMForm;
