import styled from 'styled-components';
import { getGlobalDesignToken } from 'v2/kit/design-tokens';

export const Container = styled.div<{
    isAlwaysShowVerticalScrollbar?: boolean;
    isRelativePosition?: boolean;
}>`
    overflow-x: auto;
    overflow-y: ${(props): string =>
        props.isAlwaysShowVerticalScrollbar ? 'scroll' : 'auto'};
    scrollbar-width: thin;
    scrollbar-color: ${getGlobalDesignToken('color.grey-6')} #fbfbfb;

    ${(props): string => {
        if (!props.isRelativePosition) return '';
        return `position: relative;`;
    }}

    &::-webkit-scrollbar {
        width: 6px;
        height: 6px;
    }

    &::-webkit-scrollbar-track {
        box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.15);
    }

    &::-webkit-scrollbar-thumb {
        background-color: ${getGlobalDesignToken('color.grey-6')};
        border-radius: 25px;
        height: 6px;

        &:hover {
            background-color: ${getGlobalDesignToken('color.grey-4')};
        }
    }
`;
