import AddSkuLeftContainer from 'containers/AddSkuLeftContainer';
import AddSkuRightContainer from 'containers/AddSkuRightContainer';
import useLocales from 'hooks/useLocales';
import Content from 'layouts/components/Content';
import PageFooter from 'layouts/components/PageFooter';
import PageHeader from 'layouts/components/PageHeader';
import SKUConfigurationsContainer from 'containers/SKUConfigurationsContainer';
import confirmModal from 'components/ConfirmModal';
import Select from 'components/Select';
import Button from 'components/Button';
import { DeleteOutlined, EditOutlined, EyeOutlined } from '@ant-design/icons';
import { Card, Col, Form, Result, Row, Spin } from 'antd';
import { isUndefined } from 'lodash';
import { reducerActions, sagaActions, selectors } from 'pages/AddSkuPage/slice';
import { AddSkuForm, SKUConfigurationForm } from 'pages/AddSkuPage/types';
import { useContext, useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { Link } from 'react-router-dom';
import { useAppDispatch, useAppSelector } from 'store/hooks';
import { selectors as masterDataSelectors } from 'store/masterData/slice';
import { useFetchSkuDetail } from './useFetchSkuDetail';
import { prepareSKUConfigurations } from './helper';
import { validateSKUConfig } from 'utils/common';
import { AbilityContext } from 'casl/can';
import { Action, Page } from 'constants/ability';
import { SKUS_URI } from 'routes/routes';
import { Modal } from 'antd';
import {
    prepareFormData,
    prepareUpdateData,
    prepareUpdateSourceOptionsData,
} from 'pages/AddSkuPage/helpers';

const { Option } = Select;

const SkuDetailPage = () => {
    const ability = useContext(AbilityContext);
    const navigate = useNavigate();
    const [submitted, setSubmitted] = useState(false);
    const [action, setAction] = useState<Actions>('view');

    const loading = useAppSelector(selectors.selectLoading);
    const {
        loading: loadingDetail,
        error,
        skuDetail,
        execute,
    } = useFetchSkuDetail();

    const [configurations, setConfigurations] = useState<
        SKUConfigurationForm[]
    >([]);
    const dispatch = useAppDispatch();
    const { t } = useLocales();
    const { skuId } = useParams();

    const [form] = Form.useForm<AddSkuForm>();

    const categories = useAppSelector(
        masterDataSelectors.selectorCategoryListLevel2
    );
    const brands = useAppSelector(
        masterDataSelectors.selectorByKey('brandList')
    );
    const countries = useAppSelector(
        masterDataSelectors.selectorByKey('countryList')
    );
    const loadingMasterData = useAppSelector(masterDataSelectors.selectLoading);
    const saving = useAppSelector(selectors.selectSaving);
    const formData = useAppSelector(selectors.selectFormData);

    const handleSave = async (values: AddSkuForm) => {
        const amastSellableConfigurations = configurations.filter(
            (item) => item.amastSellable
        );
        if (!amastSellableConfigurations.length) {
            return Modal.info({
                title: t('This action cannot be done!'),
                content: t('At least 1 UOM is sellable on AMAST'),
                okButtonProps: {
                    className: 'bg-red-600',
                },
            });
        }

        let skuConfigurations = configurations;
        await form.validateFields();
        setSubmitted(true);
        if (!!validateSKUConfig(configurations)) return;
        if (configurations.length === 1) {
            skuConfigurations = [{ ...configurations[0], isPrimary: true }];
            setConfigurations(skuConfigurations);
        }
        const _values = { ...values, skuConfigurations };
        if (skuId) {
            dispatch(
                sagaActions.updateSku({
                    params: {
                        ...prepareUpdateData(_values, categories),
                        skuId,
                        t,
                    },
                    sourceOptionsParams: {
                        ...prepareUpdateSourceOptionsData(values),
                        skuId,
                    },
                    callback: () => setAction('view'),
                    t,
                })
            );
        }
    };

    const handleCancel = () => {
        window.location.reload();
    };

    const handleSelect = (value: Actions) => {
        switch (value) {
            case 'view':
            case 'edit':
                setAction(value);
                execute();
                return;
            case 'delete':
            default:
                return confirmModal({
                    t,
                    title: t('Delete SKU?'),
                    content: (
                        <>
                            <div>
                                {t(
                                    'By clicking on OK, this SKU will be deleted'
                                )}
                            </div>
                            <div>{t('This action cannot be undone!')}</div>
                        </>
                    ),
                    onOk: () =>
                        Promise.resolve(
                            dispatch(
                                sagaActions.deleteSku({
                                    skuId: skuId || '',
                                    t,
                                    callback: () => navigate(SKUS_URI),
                                })
                            )
                        ),
                });
        }
    };

    const handleChange = () => {
        dispatch(reducerActions.changeFormData(form.getFieldsValue()));
    };

    useEffect(() => {
        if (!skuDetail || !!formData) return;

        const preparedFormData = prepareFormData(
            skuDetail,
            categories,
            brands,
            countries
        );
        dispatch(reducerActions.changeFormData(preparedFormData));
    }, [skuDetail, dispatch, formData, categories, brands, countries]);
    useEffect(() => {
        if (skuDetail) {
            form.setFieldsValue(
                prepareFormData(skuDetail, categories, brands, countries)
            );
            setConfigurations(
                prepareSKUConfigurations(skuDetail.configurations)
            );
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [brands.length, categories.length, countries.length, skuDetail]);
    if (
        loadingDetail ||
        loadingMasterData ||
        isUndefined(loadingDetail) ||
        isUndefined(loadingMasterData)
    )
        return <Spin size="large" />;
    else if (error)
        return (
            <Result
                status="warning"
                title={t('common.message.somethingWrong')}
            />
        );

    const canEditSourceOptions = action === 'edit' && !!skuId;

    return (
        <>
            <PageHeader
                title={t('sku.skuDetails')}
                extra={[
                    <Link key="back" to={SKUS_URI}>
                        <Button>{t('Back')}</Button>
                    </Link>,
                    <Select
                        key="dropdown"
                        style={{ width: 120 }}
                        value={action}
                        placeholder={t('common.button.actions')}
                        onSelect={handleSelect}
                        loading={loading}
                    >
                        <Option key="view" value="view" onChange={handleSelect}>
                            <EyeOutlined /> {t('common.button.view')}
                        </Option>
                        {ability.can(Action.Edit, Page.SKU) && (
                            <Option
                                key="edit"
                                value="edit"
                                onChange={handleSelect}
                            >
                                <EditOutlined /> {t('common.button.edit')}
                            </Option>
                        )}
                        {ability.can(Action.Delete, Page.SKU) && (
                            <Option
                                key="delete"
                                value="delete"
                                onChange={handleSelect}
                            >
                                <DeleteOutlined /> {t('common.button.delete')}
                            </Option>
                        )}
                    </Select>,
                ]}
            />
            <Form
                form={form}
                labelWrap
                labelCol={{ span: 8 }}
                wrapperCol={{ span: 16 }}
                labelAlign="left"
                initialValues={prepareFormData(
                    skuDetail!,
                    categories,
                    brands,
                    countries
                )}
                onFinish={handleSave}
                onChange={handleChange}
                validateMessages={{
                    required: t('common.message.required'),
                }}
            >
                <Content>
                    <Row gutter={32}>
                        <Col span={12}>
                            <Card className="h-100">
                                <AddSkuLeftContainer
                                    readOnly={action === 'view'}
                                    form={form}
                                />
                            </Card>
                        </Col>
                        <Col span={12}>
                            <Card className="h-100">
                                <AddSkuRightContainer
                                    form={form}
                                    readOnly={action === 'view'}
                                    canEditSourceOptions={canEditSourceOptions}
                                />
                            </Card>
                        </Col>
                    </Row>
                    <br />
                    <br />
                    <Card>
                        <SKUConfigurationsContainer
                            readOnly={action === 'view'}
                            parentForm={form}
                            submitted={submitted}
                            configurations={configurations}
                            onSetConfigurations={setConfigurations}
                            onChange={() => setSubmitted(false)}
                            isEditable={action === 'edit'}
                            isEnableAmastSellableColumn
                        />
                    </Card>
                </Content>
                {action === 'edit' && (
                    <PageFooter>
                        <div className="right">
                            <Button
                                size="large"
                                className="mr-md"
                                onClick={handleCancel}
                            >
                                {t('common.button.cancel')}
                            </Button>
                            <Form.Item>
                                <Button
                                    size="large"
                                    type="primary"
                                    htmlType="submit"
                                    loading={loadingDetail || saving}
                                >
                                    {t('common.button.save')}
                                </Button>
                            </Form.Item>
                        </div>
                    </PageFooter>
                )}
            </Form>
        </>
    );
};

export default SkuDetailPage;
