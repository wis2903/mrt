import React from 'react';
import Debouncer from '../../libs/debouncer.lib';
import Keyboard from '../../libs/keyboard.lib';
import { KeyboardEventEnum } from '../../libs/keyboard.lib';
import { useReference } from '../../hooks/useReference.hook';
import { isPromise } from 'v2.1/common/util';
import {
    HocReturnType,
    IExtendedProperties,
    ISelectComponentOption,
} from './type';

export const hoc =
    (Comp: React.ComponentType<IExtendedProperties>): HocReturnType =>
    (properties: IExtendedProperties): JSX.Element => {
        const {
            value,
            options: optionsFromProps = [],
            searchFn,
            findByValueFn,
            onChange,
            onBlur,
        } = properties;

        const [options, setOptions] = React.useState<ISelectComponentOption[]>(optionsFromProps);
        const [ssrSearchCallbackDebouncer] = React.useState<Debouncer>(new Debouncer(100));
        const [clearTriggerDebouncer] = React.useState<Debouncer>(new Debouncer(200));
        const [searchDebouncer] = React.useState<Debouncer>(new Debouncer(300));
        const [keyboard] = React.useState<Keyboard>(new Keyboard());
        const [isShowDropdown, setIsShowDropdown] = React.useState<boolean>(false);
        const [preSelectedOption, setPreSelectedOption] = React.useState<ISelectComponentOption>();
        const [search, setSearch] = React.useState<string>('');
        const [optionFoundBySsr, setOptionFoundBySsr] = React.useState<ISelectComponentOption>();
        const [isSsrSearching, setIsSsrSearching] = React.useState<boolean>(!!searchFn);
        const [isReadyToShowDropdownContent, setIsReadyToShowDropdownContent] =
            React.useState<boolean>(false);

        const activeOption = optionFoundBySsr || options.find((opt) => opt.value === value);
        const filteredOptions = !!searchFn
            ? options
            : options.filter((opt) => opt.label.toLowerCase().indexOf(search.toLowerCase()) >= 0);

        const scrollableAreaRef = React.useRef<HTMLDivElement>(null);
        const triggerRef = React.useRef<HTMLInputElement>(null);
        const preSelectedOptionRef = useReference(preSelectedOption);
        const isShowDropdownRef = useReference(isShowDropdown);
        const activeOptionRef = useReference(activeOption);
        const filteredOptionsRef = useReference(filteredOptions);

        const handleToggleDropdown = (status?: boolean): void => {
            const newStatus = status !== undefined ? status : !isShowDropdownRef.current;
            setIsShowDropdown(newStatus);
            setPreSelectedOption(activeOptionRef.current);

            if (newStatus) {
                keyboard.trigger();
                if (!!searchFn) {
                    handleSsrSearch().then(handleScrollToActiveOption);
                } else {
                    setIsReadyToShowDropdownContent(false);
                    ssrSearchCallbackDebouncer.execute((): void => {
                        handleScrollToActiveOption().then((): void => {
                            setIsReadyToShowDropdownContent(true);
                        });
                    });
                }
            } else {
                keyboard.unregister();
            }
        };

        const handleOnSelectOption =
            (option: ISelectComponentOption): VoidFunction =>
            (): void => {
                if (activeOptionRef.current?.value !== option.value) {
                    onChange?.(option);
                }
                handleToggleDropdown();
                // triggerRef.current?.blur();
            };

        const handlePreSelectNextOption = (): void => {
            const currentPreSelectedOptionIdx = filteredOptionsRef.current.findIndex(
                (item) => item.value === preSelectedOptionRef.current?.value
            );
            setPreSelectedOption(
                filteredOptionsRef.current[
                    Math.min(currentPreSelectedOptionIdx + 1, filteredOptionsRef.current.length - 1)
                ]
            );
        };

        const handlePreSelectPreviousOption = (): void => {
            const currentPreSelectedOptionIdx = filteredOptionsRef.current.findIndex(
                (item) => item.value === preSelectedOptionRef.current?.value
            );
            setPreSelectedOption(
                filteredOptionsRef.current[Math.max(currentPreSelectedOptionIdx - 1, 0)]
            );
        };

        const handleActivePreSelectedOption = (): void => {
            if (!preSelectedOptionRef.current) return;
            handleOnSelectOption(preSelectedOptionRef.current)();
        };

        const handleCloseDropdown = (): void => {
            handleToggleDropdown(false);
            triggerRef.current?.blur();
        };

        const handleClearPreSelectedOption = (): void => {
            setPreSelectedOption(activeOptionRef.current);
        };

        const handleClearTriggerValue = (): void => {
            clearTriggerDebouncer.execute((): void => {
                setSearch('');
            });
        };

        const handleOnSearchChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
            setSearch(e.target.value);
            searchDebouncer.execute((): void => {
                handleSsrSearch(e.target.value).then(handleScrollToActiveOption);
            });
        };

        const handleSsrSearch = (keyword?: string): Promise<void> => {
            return new Promise((resolve) => {
                if (!searchFn) {
                    return resolve();
                }

                setIsReadyToShowDropdownContent(false);
                const _keyword = keyword === undefined ? search : keyword;

                const response = searchFn(_keyword);

                if (!isPromise(response)) {
                    setOptions(response as ISelectComponentOption[]);
                    setIsSsrSearching(false);
                    ssrSearchCallbackDebouncer.execute(() => {
                        resolve();
                        setIsReadyToShowDropdownContent(true);
                    });
                    return;
                }
                setIsSsrSearching(true);
                (response as Promise<ISelectComponentOption[]>)
                    .then((response) => {
                        setOptions(response);
                    })
                    .catch(() => {
                        setOptions([]);
                    })
                    .finally(() => {
                        setIsSsrSearching(false);
                        ssrSearchCallbackDebouncer.execute(() => {
                            resolve();
                            setIsReadyToShowDropdownContent(true);
                        });
                    });
            });
        };

        const handleSsrFindByValue = (): void => {
            if (!value) return;

            const defaultResponse: ISelectComponentOption = {
                label: String(value),
                value,
            };

            if (!findByValueFn) {
                setOptionFoundBySsr(defaultResponse);
                return;
            }

            const response = findByValueFn(value);

            if (!isPromise(response)) {
                setOptionFoundBySsr((response as ISelectComponentOption) || defaultResponse);
                return;
            }

            (response as Promise<ISelectComponentOption>)
                .then((data) => {
                    setOptionFoundBySsr(data || defaultResponse);
                })
                .catch(() => {
                    setOptionFoundBySsr(defaultResponse);
                });
        };

        const handleScrollToActiveOption = (): Promise<void> => {
            return new Promise((resolve) => {
                // if (!scrollableAreaRef.current) return resolve();
                // if (!activeOptionRef.current) return resolve();

                // const preSelectedOptionHTMLElement = scrollableAreaRef.current.querySelector(
                //     `[data-value="${preSelectedOptionRef.current?.value}"]`
                // ) as HTMLButtonElement;

                // if (preSelectedOptionHTMLElement) {
                //     scrollableAreaRef.current.scrollTop = preSelectedOptionHTMLElement.offsetTop;
                //     return resolve();
                // }

                // const activeOptionHTMLElement = scrollableAreaRef.current.querySelector(
                //     `[data-value="${activeOptionRef.current.value}"]`
                // ) as HTMLButtonElement;

                // if (activeOptionHTMLElement) {
                //     scrollableAreaRef.current.scrollTop = activeOptionHTMLElement.offsetTop;
                // }

                resolve();
            });
        };

        const handleOnTriggerBlur = (): void => {
            handleClearTriggerValue();
            onBlur?.();
        }

        // React.useEffect(() => {
        //     handleScrollToActiveOption();
        // }, [preSelectedOption?.value]);

        React.useEffect(() => {
            handleSsrFindByValue();
            // keyboard.register(KeyboardEventEnum.arrowDown, handlePreSelectNextOption);
            // keyboard.register(KeyboardEventEnum.arrowUp, handlePreSelectPreviousOption);
            // keyboard.register(KeyboardEventEnum.enter, handleActivePreSelectedOption);
            keyboard.register(KeyboardEventEnum.escape, handleCloseDropdown);

            return (): void => {
                keyboard.unregister();
                clearTriggerDebouncer.destroy();
                searchDebouncer.destroy();
                ssrSearchCallbackDebouncer.destroy();
            };
        }, []);

        return (
            <Comp
                {...{
                    ...properties,
                    isShowDropdown,
                    isSsrSearching,
                    isReadyToShowDropdownContent,
                    activeOption,
                    filteredOptions,
                    preSelectedOption,
                    search,
                    scrollableAreaRef,
                    triggerRef,
                    handleToggleDropdown,
                    handleCloseDropdown,
                    handleOnSelectOption,
                    handleClearPreSelectedOption,
                    handleClearTriggerValue,
                    handleOnSearchChange,
                    handleOnTriggerBlur,
                }}
            />
        );
    };
