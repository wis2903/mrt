import userEvent from '@testing-library/user-event';
import { renderWithProvider, screen } from 'test';
import Component from '.';
import * as slice from '../AddSkuPage/slice';
import sinon from 'sinon';
import apiClient from 'apis/apiClient';

sinon.stub(apiClient, 'post').callsFake(
  () =>
    ({
      data: {}
    } as any)
);
sinon.stub(apiClient, 'get').callsFake(
  () =>
    ({
      data: {}
    } as any)
);

const mockData: any = [
  {
    id: 1390,
    name: 'Bia Heiniken',
    code: 'NJM001390',
    description: 'fake_data',
    countryId: 6,
    tax: 10,
    categoryId: 3,
    categoryName: 'Beverages',
    subcategoryId: 10,
    subcategoryName: 'Beer',
    brandId: 7,
    brandName: 'Neptune',
    configurations: null,
    numberUom: 3,
    minGrossPrice: 0,
    maxGrossPrice: 0
  },
  {
    id: 1391,
    name: 'Bia Heiniken',
    code: 'NJM001390',
    description: 'fake_data',
    countryId: 6,
    tax: 10,
    categoryId: 3,
    categoryName: 'Beverages',
    subcategoryId: 10,
    subcategoryName: 'Beer',
    brandId: 7,
    brandName: 'Neptune',
    configurations: null,
    numberUom: 3,
    minGrossPrice: 1,
    maxGrossPrice: 2
  },
  {
    id: 1392,
    name: 'Bia Heiniken',
    code: 'NJM001390',
    description: 'fake_data',
    countryId: 6,
    tax: 10,
    categoryId: 3,
    categoryName: 'Beverages',
    subcategoryId: 10,
    subcategoryName: '',
    brandId: 7,
    brandName: 'Neptune',
    configurations: null,
    numberUom: null,
    minGrossPrice: null,
    maxGrossPrice: null
  }
];

describe('Render component', () => {
  it('should render without crash', () => {
    const { container } = renderWithProvider(<Component />);

    expect(container).toBeTruthy();
  });
  it('should render with data', () => {
    jest.spyOn(slice.selectors, 'selectSkuList').mockReturnValue(mockData);
    jest.spyOn(slice.selectors, 'selectTotal').mockReturnValue(100);
    const { container } = renderWithProvider(<Component />);

    expect(container).toBeTruthy();
  });
});
