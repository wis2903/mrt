import { all } from 'redux-saga/effects';
import { saga as languageSaga } from 'containers/LanguageProvider/slices';
import { saga as masterData } from 'store/masterData/slice';

export default function* rootSaga() {
  yield all([languageSaga(), masterData()]);
}
