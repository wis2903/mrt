const Upload: React.FC<any> = ({ value, onChange, beforeUpload, children }) => {
  const handleChange = () => {
    onChange({ file: { size: 1024 * 1024, originFileObj: new Blob(), status: 'uploading' } });
    onChange({ file: { originFileObj: new Blob(), status: 'uploading' } });
    onChange({ file: { response: { data: { url: 'q' } }, originFileObj: new Blob(), status: 'done' } });
  };
  return (
    <>
      <input type='file' data-testid='upload-beforeUpload' value={value} onChange={beforeUpload} />
      <input type='file' data-testid='upload-onChange' value={value} onChange={handleChange} />
      {children}
    </>
  );
};

export default Upload;
