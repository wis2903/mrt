import store from 'store/store';
import { notificationActions } from './slice';
describe('notificationSlice', () => {
  it('showNotification', () => {
    expect(store.dispatch(notificationActions.showNotification({}))).toBeTruthy();
  });
  it('removeNotification', () => {
    expect(store.dispatch(notificationActions.removeNotification())).toBeTruthy();
  });
});
