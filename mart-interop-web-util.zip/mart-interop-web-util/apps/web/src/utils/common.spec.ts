import {
  includeText,
  isEmptyValue,
  printHTML,
  removeAccentsVietnamese,
  saveData,
  showTotalPaginationItemsAmount,
  validateSKUConfig
} from './common'

describe('validateSKUConfig', () => {
  it('should return value', () => {
    expect(validateSKUConfig([])).toBeTruthy()
    expect(
      validateSKUConfig([
        { id: 1, name: 'test', generatedName: 'test', image: 'test', isPrimary: true, quantity: 1 },
        { id: 1, name: 'test', generatedName: 'test', image: 'test', isPrimary: true, quantity: 1 }
      ])
    ).toBeTruthy()
    expect(
      validateSKUConfig([
        { id: 1, name: 'test', generatedName: 'test', image: 'test', isPrimary: false, quantity: 1 },
        { id: 1, name: 'test', generatedName: 'test', image: 'test', isPrimary: false, quantity: 1 }
      ])
    ).toBeTruthy()
    expect(printHTML('test', 'test')).toBeTruthy()
    expect(saveData('test', 'test')).toBeUndefined()
  })
})
describe('removeAccentsVietnamese', () => {
  it('should return correct string', () => {
    const expected = 'test'
    expect(removeAccentsVietnamese('tést')).toEqual(expected)
  })
})

describe('includeText', () => {
  it('should return correct string', () => {
    const expected = true
    expect(includeText('tést', 'tést')).toEqual(expected)
  })
})
describe('showTotalPaginationItemsAmount', () => {
  it('should return correct string', () => {
    const expected = 'Showing 1-10 of 50 items'
    expect(showTotalPaginationItemsAmount(50, [1, 10])).toEqual(expected)
  })
})
describe('isEmptyValue', () => {
  it('should return correctly', () => {
    const expected = true
    expect(isEmptyValue('')).toEqual(expected)
    expect(isEmptyValue(undefined)).toEqual(expected)
    expect(isEmptyValue(null)).toEqual(expected)
    expect(isEmptyValue('aaa')).not.toEqual(expected)
  })
})
