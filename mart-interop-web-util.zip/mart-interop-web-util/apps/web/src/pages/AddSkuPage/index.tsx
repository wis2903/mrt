import React from 'react';
import AddSkuLeftContainer from 'containers/AddSkuLeftContainer';
import AddSkuRightContainer from 'containers/AddSkuRightContainer';
import useLocales from 'hooks/useLocales';
import Content from 'layouts/components/Content';
import PageFooter from 'layouts/components/PageFooter';
import PageHeader from 'layouts/components/PageHeader';
import SKUConfigurationsContainer from '../../containers/SKUConfigurationsContainer/index';
import Button from 'components/Button';
import { Card, Col, Form, Row, Spin } from 'antd';
import { useNavigate } from 'react-router-dom';
import { useInjectReducer, useInjectSaga } from 'redux-injectors';
import { useAppDispatch, useAppSelector } from 'store/hooks';
import { prepareAddSkuFormInitialValues, prepareSaveData } from './helpers';
import { AddSkuForm, SKUConfigurationForm } from './types';
import { selectors as masterDataSelectors } from 'store/masterData/slice';
import { isUndefined } from 'lodash';
import { Link } from 'react-router-dom';
import { SKUS_URI } from '../../routes/routes';
import { useState } from 'react';
import { validateSKUConfig } from 'utils/common';
import {
    sagaActions,
    selectors,
    sliceName,
    reducer,
    saga,
    reducerActions,
} from './slice';

const AddSkuPage = () => {
    useInjectReducer({ key: sliceName, reducer });
    useInjectSaga({ key: sliceName, saga });
    const { t } = useLocales();
    const routes = [
        {
            path: '',
            breadcrumbName: t('common.home'),
        },
        {
            path: '/add-sku',
            breadcrumbName: t('sku.addProductSku'),
        },
    ];

    const dispatch = useAppDispatch();
    const navigate = useNavigate();

    const loading = useAppSelector(selectors.selectLoading);
    const loadingMasterData = useAppSelector(masterDataSelectors.selectLoading);

    const [form] = Form.useForm<AddSkuForm>();
    const [submitted, setSubmitted] = useState(false);
    const [configurations, setConfigurations] = useState<
        SKUConfigurationForm[]
    >([]);

    const categories = useAppSelector(
        masterDataSelectors.selectorCategoryListLevel2
    );
    const countries = useAppSelector(
        masterDataSelectors.selectorByKey('countryList')
    );

    const countryOptions: SelectOptions[] = countries?.map((x) => ({
        value: x.id,
        label: x.name,
        code: x.code,
    }));

    const handleSave = (values: AddSkuForm) => {
        form.validateFields().then(() => {
            setSubmitted(true);
            if (!!validateSKUConfig(configurations)) return;
            const _values = { ...values, skuConfigurations: configurations };
            if (configurations.length === 1) {
                const skuConfigurations = [
                    { ...configurations[0], isPrimary: true },
                ];
                setConfigurations(skuConfigurations);
                const valuesHasPrimary = { ...values, skuConfigurations };
                return dispatch(
                    sagaActions.createSku({
                        params: prepareSaveData(valuesHasPrimary, categories),
                        navigate,
                        t,
                    })
                );
            }
            dispatch(
                sagaActions.createSku({
                    params: prepareSaveData(_values, categories),
                    navigate,
                    t,
                })
            );
        });
    };

    const handleChange = () => {
        dispatch(reducerActions.changeFormData(form.getFieldsValue()));
    };

    if (loadingMasterData || isUndefined(loadingMasterData))
        return <Spin size="large" />;
    return (
        <>
            <Form
                id="addSkuForm"
                form={form}
                labelWrap
                labelCol={{ span: 8 }}
                wrapperCol={{ span: 16 }}
                labelAlign="left"
                initialValues={prepareAddSkuFormInitialValues(countryOptions)}
                onFinish={handleSave}
                onChange={handleChange}
                validateMessages={{
                    required: t('common.message.required'),
                }}
            >
                <PageHeader
                    title={t('sku.addProductSku')}
                    breadcrumb={{ routes }}
                />
                <Content>
                    <Row gutter={32}>
                        <Col span={12}>
                            <Card className="h-100">
                                <AddSkuLeftContainer form={form} />
                            </Card>
                        </Col>
                        <Col span={12}>
                            <Card className="h-100">
                                <AddSkuRightContainer
                                    form={form}
                                    showHintText
                                />
                            </Card>
                        </Col>
                    </Row>
                    <br />
                    <br />
                    <Card>
                        <SKUConfigurationsContainer
                            isNew
                            parentForm={form}
                            submitted={submitted}
                            configurations={configurations}
                            onSetConfigurations={setConfigurations}
                            onChange={() => setSubmitted(false)}
                        />
                    </Card>
                </Content>
                <PageFooter>
                    <div className="right">
                        <Link to={SKUS_URI}>
                            <Button size="large" className="mr-md">
                                {t('common.button.cancel')}
                            </Button>
                        </Link>
                        <Form.Item>
                            <Button
                                size="large"
                                type="primary"
                                htmlType="submit"
                                loading={loading}
                            >
                                {t('common.button.save')}
                            </Button>
                        </Form.Item>
                    </div>
                </PageFooter>
            </Form>
        </>
    );
};
export default AddSkuPage;
