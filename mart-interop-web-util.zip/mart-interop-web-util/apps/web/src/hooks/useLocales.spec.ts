import * as intl from 'react-intl';
import { useTranslate } from './useLocales';

describe('useTranslate', () => {
  it('Should run normally', async () => {
    jest.spyOn(intl, 'useIntl').mockReturnValueOnce({ formatMessage: jest.fn() } as any);
    expect(useTranslate('test', { test: 'test' })).toBeUndefined();
  });
});
