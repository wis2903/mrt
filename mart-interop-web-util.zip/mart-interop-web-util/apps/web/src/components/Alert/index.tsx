import { Alert as AntdAlert } from 'antd'
import styled from 'styled-components'

const StyledAlert = styled(AntdAlert)`
  & {
    padding: 6px 10px;
    .ant-alert-message {
      color: #4c4c4c;
    }
  }
`

export default StyledAlert
