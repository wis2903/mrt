import { GetDistrictParams } from '../../types/Location';
import apiClient, { apiClientV2 } from 'apis/apiClient';
import { PROVINCES } from 'apis/apiUrl';
import { MASTER_DATA_API_URL } from 'v2/app/constants/url.constant';

export const getMasterData = () =>
    apiClientV2
        .get(`${MASTER_DATA_API_URL}`)
        .then((response) => response)
        .catch((err) => {
            throw err;
        });

export const getDistrict = (params: GetDistrictParams) =>
    apiClient
        .get(`${PROVINCES}/${params.province}/districts`)
        .then((response) => response)
        .catch((err) => {
            throw err;
        });
