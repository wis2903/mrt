import styled from 'styled-components';

import { FlexboxComponent } from '../../core/component/flexbox';
import { token } from '../../core/foundation/token';

export const font = `
    font-family: ${token.get<string>('global.typo.font-name')}, sans-serif;
    font-optical-sizing: auto;
    font-style: normal;
    font-variation-settings: 'wdth' 100;
    letter-spacing: -0.1px;
`;

export const StyledLayoutContainer = styled(FlexboxComponent)`
    width: 100%;
    background: ${token.get<string>('global.color.grey-9')};
    color: ${token.get<string>('global.color.grey-1')};
    font-size: ${token.get<string>('global.typo.font-size-7')};

    ${font};

    * {
        box-sizing: border-box;
        ${font};
    }

    a {
        text-decoration: none;
        color: ${token.get<string>('global.color.red-3')};

        &:hover {
            color: ${token.get<string>('global.color.red-4')};
        }
    }

    strong,
    b {
        font-weight: ${token.get<string>('global.typo.font-weight-bold')};
    }
`;
