import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { getSkuDetail, GetSkuDetailParams, updateSkuSellingPrice, UpdateSkuSellingPriceParams } from 'apis/sku';
import { loadingActions } from 'containers/LoadingContainer/slices';
import showNotification from 'containers/NotificationContainer/Notification';
import { call, put } from 'redux-saga/effects';
import { createSliceSaga, SagaType } from 'redux-toolkit-saga';
import { AppState } from 'store/store';
import SkuDetail, { SellingPriceTable, SKUConfiguration } from 'types/SKUDetail';
import { ALL_OPTIONS } from './constant';
import { prepareTableData } from './utils';
import { groupBy } from 'lodash';
import { selectors as masterDataSelectors } from 'store/masterData/slice';

// ---------------------------------------
const sliceName = 'priceConfig';
type PriceConfigState = {
  skuDetail?: SkuDetail;
  provincesFormData?: Partial<SellingPriceTable>[];
  originalProvincesFormData?: SellingPriceTable[];
  selectedRegion: string;
  searchValue?: string;
  selectedSkuConfig?: SKUConfiguration;
  isValidating?: boolean;
  isSaveSuccess?: boolean;
  isSaving?: boolean;
};
const initialState: PriceConfigState = {
  selectedRegion: ALL_OPTIONS.name
};

// ---------------------------------------
const reducers = {
  fetchSkuDetailSuccess: (state: PriceConfigState, action: PayloadAction<SkuDetail>) => {
    return {
      ...state,
      skuDetail: action.payload,
      provincesFormData: action.payload.configurations[0].sellingPrices as SellingPriceTable[],
      originalProvincesFormData: action.payload.configurations[0].sellingPrices as SellingPriceTable[],
      selectedSkuConfig: action.payload.configurations[0]
    };
  },
  updateFormData: (state: PriceConfigState, action: PayloadAction<Partial<SellingPriceTable>[]>) => {
    state.provincesFormData = action.payload;
  },
  changeSelectedRegion: (state: PriceConfigState, action: PayloadAction<string>) => {
    state.selectedRegion = action.payload;
    state.provincesFormData = state.selectedSkuConfig?.sellingPrices as SellingPriceTable[];
    state.originalProvincesFormData = state.selectedSkuConfig?.sellingPrices as SellingPriceTable[];
  },
  changeSearchValue: (state: PriceConfigState, action: PayloadAction<string>) => {
    state.searchValue = action.payload;
    state.provincesFormData = state.selectedSkuConfig?.sellingPrices as SellingPriceTable[];
    state.originalProvincesFormData = state.selectedSkuConfig?.sellingPrices as SellingPriceTable[];
  },
  changeSelectedSkuConfig: (state: PriceConfigState, action: PayloadAction<SKUConfiguration>) => {
    state.selectedSkuConfig = action.payload;
    state.selectedRegion = ALL_OPTIONS.name;
    state.provincesFormData = action.payload.sellingPrices as SellingPriceTable[];
    state.originalProvincesFormData = action.payload.sellingPrices as SellingPriceTable[];
  },
  changeIsValidating: (state: PriceConfigState, action: PayloadAction<boolean>) => {
    state.isValidating = action.payload;
  },
  changeIsSaveSuccess: (state: PriceConfigState, action: PayloadAction<boolean>) => {
    state.isSaveSuccess = action.payload;
  },
  changeSaving: (state: PriceConfigState, action: PayloadAction<boolean>) => {
    state.isSaving = action.payload;
  }
};

const sliceOption = {
  name: sliceName,
  initialState,
  reducers
};
const slice = createSlice(sliceOption);
const { reducer, actions: reducerActions } = slice;

const skuDetailSelector = (state: AppState) => {
  const dataSelected = state[sliceName] as PriceConfigState;
  return dataSelected?.skuDetail;
};

const provincesFormDataSelector = (state: AppState) => {
  const dataSelected = state[sliceName] as PriceConfigState;
  const provinceList = masterDataSelectors.selectorProvinceList(state);
  return prepareTableData(
    dataSelected?.provincesFormData || [],
    { region: dataSelected?.selectedRegion, searchValue: dataSelected?.searchValue },
    provinceList
  );
};

const selectedRegionSelector = (state: AppState) => {
  const dataSelected = state[sliceName] as PriceConfigState;
  return dataSelected?.selectedRegion;
};

const availableProvincesSelector = (state: AppState) => {
  const provincesFormData = provincesFormDataSelector(state);
  const selectedRegion = selectedRegionSelector(state);
  const excludedProvinceList = provincesFormData.map((formData) => formData.province?.value || formData.provinceId);
  const provinceList = masterDataSelectors.selectorProvinceList(state);
  const regions: any = { [ALL_OPTIONS.name]: provinceList, ...groupBy(provinceList, 'region') };
  return (
    regions[selectedRegion]?.filter(
      (province: any) =>
        !excludedProvinceList.includes(province.id) && (province.region === selectedRegion || selectedRegion === ALL_OPTIONS.name)
    ) || []
  );
};

const selectedSkuConfigSelector = (state: AppState) => {
  const dataSelected = state[sliceName] as PriceConfigState;
  return dataSelected?.selectedSkuConfig;
};

const originalProvincesFormDataSelector = (state: AppState) => {
  const dataSelected = state[sliceName] as PriceConfigState;
  const provinceList = masterDataSelectors.selectorProvinceList(state);
  return prepareTableData(
    dataSelected?.originalProvincesFormData || [],
    { region: dataSelected?.selectedRegion, searchValue: dataSelected?.searchValue },
    provinceList
  );
};

const isValidatingSelector = (state: AppState) => {
  const dataSelected = state[sliceName] as PriceConfigState;
  return dataSelected?.isValidating;
};

const isSaveSuccessSelector = (state: AppState) => {
  const dataSelected = state[sliceName] as PriceConfigState;
  return dataSelected?.isSaveSuccess;
};

const isSavingSelector = (state: AppState) => {
  const dataSelected = state[sliceName] as PriceConfigState;
  return dataSelected?.isSaving;
};

const selectors = {
  provincesFormDataSelector,
  skuDetailSelector,
  selectedRegionSelector,
  availableProvincesSelector,
  selectedSkuConfigSelector,
  originalProvincesFormDataSelector,
  isValidatingSelector,
  isSaveSuccessSelector,
  isSavingSelector
};

// ---------------------------------------

export const sagaOption = {
  name: sliceName,
  sagaType: SagaType.TakeLatest,
  caseSagas: {
    *fetchSkuDetail(action: PayloadAction<GetSkuDetailParams & { skipLoading?: boolean }>): any {
      try {
        if (!action.payload.skipLoading) {
          yield put(loadingActions.showLoading());
        }
        const { data } = yield call(getSkuDetail, action.payload);
        yield put(slice.actions.fetchSkuDetailSuccess(data.data));
      } catch (e: any) {
        showNotification({
          type: 'error',
          message: e.response?.data?.title || 'priceConfiguration.messages.fetchSKUFailed'
        });
      } finally {
        yield put(loadingActions.stopLoading());
      }
    },
    *updatePriceConfig(action: PayloadAction<UpdateSkuSellingPriceParams & { callback: () => void; t: (key: string) => string }>): any {
      try {
        const { callback, ...payload } = action.payload;
        yield put(slice.actions.changeSaving(true));
        yield call(updateSkuSellingPrice, payload);

        yield put(
          sliceSaga.actions.fetchSkuDetail({
            skuId: payload.skuId,
            skipLoading: true,
            t: action.payload.t
          })
        );

        yield put(reducerActions.changeIsValidating(false));
        yield put(reducerActions.changeIsSaveSuccess(true));
        showNotification({
          type: 'success',
          message: 'priceConfiguration.messages.savePriceSuccess'
        });
        callback();
      } catch (err: any) {
        showNotification({
          type: 'error',
          message: err.response?.data?.title || 'priceConfiguration.messages.savePriceFailed'
        });
      } finally {
        yield put(slice.actions.changeSaving(false));
      }
    }
  }
};
const sliceSaga = createSliceSaga(sagaOption);
const { saga, actions: sagaActions } = sliceSaga;
// ---------------------------------------

export { initialState, sliceName, reducer, saga, reducerActions, sagaActions, selectors };
