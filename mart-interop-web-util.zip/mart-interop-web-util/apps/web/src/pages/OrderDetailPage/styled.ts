import styled from 'styled-components';
import { Form } from 'antd';

import { defaultTheme } from 'styles/defaultTheme.styles';
import Select from 'components/Select';

export const FormStyled = styled(Form)`
  .ant-form-item {
    margin-bottom: ${defaultTheme.spacing.xs};
  }
`;

export const SelectStyled = styled(Select)`
  .ant-select:not(.ant-select-customize-input) .ant-select-selector {
    border-color: #d9d9d9;
  }
  .ant-select-selection-placeholder {
    color: inherit !important;
  }
`;
