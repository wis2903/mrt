import {
    ACTIVE_PROMOTION_SUBSTATUS_MASTER_DATA,
    INACTIVE_PROMOTION_SUBSTATUS_MASTER_DATA,
    InactivePromotionSubStatus,
    InactivePromotionSubStatusName,
    PromotionStatus,
} from 'constants/promotions';
import {
    CreatePromotionParams,
    GetPromotionsParams,
    InactivePromotionSubStatusType,
    PromotionSearchApi,
    PromotionStatusType,
} from 'types/Promotions';
import { DEFAULT_PAGE_NUMBER, PAGE_SIZE_OPTIONS, TIME_FORMAT_2 } from 'constants/common';
import { Lang, translationMessages } from 'i18n';
import { formatterMoney } from '../../utils/formatUtils';
import {
    AMAST_UOM,
    ComboDiscountAffectionEnum,
    ComboDiscountTypeEnum,
    IUOMData,
    PromotionDealType,
} from './@types';
import { getSkuDetail, getSkuList } from 'apis/sku';
import { AxiosResponse } from 'axios';
import { UseFormReturn } from 'react-hook-form';
import moment from 'moment';
import store from 'store/store';
import uuid from 'react-uuid';
import { isEmpty } from 'v2/app/helpers/utils.helper';

export const prepareGetPromotionsParams = (
    params: GetPromotionsParams
): PromotionSearchApi | undefined => {
    return {
        page: params?.page || undefined,
        size: params?.size || undefined,
        province_id: params.search?.provinceId || undefined,
        status: Number(params.search?.status) || undefined,
        sub_status: Number(params.search?.subStatus) || undefined,
        sort: params.search?.sort || undefined,
    };
};

export const prepareCreatePromotionsParams = (params: CreatePromotionParams) => {
    const startDate = moment(params.startDate).startOf('day').utc().format(TIME_FORMAT_2);
    const endDate = moment(params.endDate).endOf('day').utc().format(TIME_FORMAT_2);

    const res: Record<string, unknown> = {
        name: params.name,
        dealType: params.dealType,
        provinceId: Number(params.provinceId),
        countryId: Number(params.countryId),
        startDate: startDate,
        endDate: endDate,
        criteria: params.criteria,
        cxMeta: params.cxMeta,
    };

    if (!isEmpty(params.applyLimit)) {
        res.applyLimit = Number(params.applyLimit);
    }

    return res;
};

export const genSubStatus = (
    status: PromotionStatusType,
    subStatus?: PromotionStatusType[] | InactivePromotionSubStatusType[]
) => {
    let promotionSubstatus;
    if (status === PromotionStatus.Active) {
        promotionSubstatus = ACTIVE_PROMOTION_SUBSTATUS_MASTER_DATA.find(
            (promotion) => promotion.code === status
        );
    } else {
        promotionSubstatus = INACTIVE_PROMOTION_SUBSTATUS_MASTER_DATA.find(
            (promotion) => promotion.code === subStatus?.[0]
        );
        if (!promotionSubstatus)
            promotionSubstatus = {
                code: InactivePromotionSubStatus.Unknown,
                name: InactivePromotionSubStatusName.DEACTIVATED,
                tagConfig: {
                    textClassName: 'whitespace-nowrap',
                },
            };
    }

    return promotionSubstatus;
};

export const getTextByLocale = (key: string, lcl?: 'vi' | 'en'): string => {
    const locale = lcl || store.getState().language?.locale;
    if (!locale) return key;
    return (translationMessages[locale as Lang] as any)?.[key] || key;
};

export const getValidationMessageByLocale = (validationKey: string, field?: string): string => {
    const locale = store.getState().language?.locale;
    const transMessage = getTextByLocale(validationKey);
    if (locale === Lang.Vi)
        return `${transMessage.charAt(0).toUpperCase()}${transMessage.substring(1)}`;
    if (!field) return transMessage;
    const transField = getTextByLocale(field);
    return `${transField} ${getTextByLocale('is')} ${transMessage}`;
};

export const genSkuSummary = (validComboSkus: any[]) => {
    if (!validComboSkus.length) return '—';

    return (
        'Combo: ' +
        validComboSkus
            .reduce((skus: any[], item: any) => {
                const uom = (item?.uom?.name || '').toLowerCase();
                skus.push(`${formatterMoney(item.qty)} ${uom} ${item.sku?.name}`);

                return skus;
            }, [])
            .join(' + ')
    );
};

export const getDealTypeFromDiscountTypeAndDiscountAffection = (
    discountType: ComboDiscountTypeEnum,
    discountAffection: ComboDiscountAffectionEnum
): PromotionDealType | undefined => {
    if (
        discountType === ComboDiscountTypeEnum.priceAfterDiscount &&
        discountAffection === ComboDiscountAffectionEnum.theWholeCombo
    ) {
        return PromotionDealType.COMBO_SET_FLAT;
    }

    if (
        discountType === ComboDiscountTypeEnum.priceAfterDiscount &&
        discountAffection === ComboDiscountAffectionEnum.eachSKU
    ) {
        return PromotionDealType.COMBO_ITEM_FLAT;
    }

    return undefined;
};

export const calculateSKUTotalPrice = (unitPrice?: number, qty?: number): number => {
    return (unitPrice || 0) * (qty || 0);
};

export const getValidationTriggerFields = (
    discountType: ComboDiscountTypeEnum,
    discountAffection: ComboDiscountAffectionEnum
): string[] => {
    const commonValidationFields = [
        'combo',
        'startDate',
        'endDate',
        'name',
        'dealType',
        'provinceId',
        'countryId',
        'criteria.applyLimit',
    ];

    if (
        discountType === ComboDiscountTypeEnum.priceAfterDiscount &&
        discountAffection === ComboDiscountAffectionEnum.theWholeCombo
    ) {
        return [...commonValidationFields, 'criteria.discountForTheWholeCombo'];
    }

    if (
        discountType === ComboDiscountTypeEnum.priceAfterDiscount &&
        discountAffection === ComboDiscountAffectionEnum.eachSKU
    ) {
        return [...commonValidationFields, 'criteria.discountForEachSKU'];
    }

    return commonValidationFields;
};

export const calculateComboDefaultPrice = (combo: any[]): number =>
    combo.reduce<number>((total, item) => {
        total += (item.qty || 0) * ((item.uom as any)?.defaultPrice || 0);
        return total;
    }, 0);

export const getFinalFormData = (formValues: any): Record<string, unknown> => {
    const { combo, criteria, name, startDate, endDate } = formValues;

    const dealType = getDealTypeFromDiscountTypeAndDiscountAffection(
        formValues.internalValues.discountType,
        formValues.internalValues.discountAffection
    );

    const finalCriteria: Record<string, unknown> = {
        applyLimit: formValues.criteria.applyLimit,
        excludeCategory: [],
        skuCode: uuid(),
    };

    if (dealType === PromotionDealType.COMBO_SET_FLAT) {
        const { discountForTheWholeCombo } = criteria;
        const comboDefaultPrice = calculateComboDefaultPrice(combo);

        finalCriteria.combo = (combo as any[]).map((item) => ({
            skuCode: item.sku?.code,
            configurationId: item.uom?.id,
            amastUom: item.uom?.isPrimary ? AMAST_UOM.UN : AMAST_UOM.CT,
            quantity: item.qty,
        }));
        finalCriteria.discountFlat = comboDefaultPrice - (discountForTheWholeCombo || 0);
    } else if (dealType === PromotionDealType.COMBO_ITEM_FLAT) {
        const { discountForEachSKU } = criteria;

        finalCriteria.combo = (combo as any[]).map((item, idx) => ({
            skuCode: item.sku?.code,
            configurationId: item.uom?.id,
            amastUom: item.uom?.isPrimary ? AMAST_UOM.UN : AMAST_UOM.CT,
            quantity: item.qty,
            priceSet: discountForEachSKU[idx].price,
        }));
    }

    return {
        name,
        dealType,
        startDate,
        endDate,
        criteria: finalCriteria,
        provinceId: formValues.provinceId,
        countryId: formValues.countryId,
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
};

export const validateComboDiscountForTheWholeCombo = (
    formValues: any,
    setFieldError: () => void
) => {
    const {
        combo,
        criteria: { discountForTheWholeCombo },
    } = formValues;
    const comboDefaultPrice = calculateComboDefaultPrice(combo);

    if ((discountForTheWholeCombo || 0) > comboDefaultPrice) {
        setFieldError();
        return false;
    }

    return true;
};
export const validateComboDiscountForEachSKU = (
    formValues: any,
    setFieldError: (idx: number) => void
) => {
    let flag = true;
    const {
        combo,
        criteria: { discountForEachSKU },
    } = formValues;
    combo.forEach((item: any, idx: number) => {
        const itemDefaultPrice = (item.uom as any)?.defaultPrice || 0;
        const itemPriceAfterDiscount = discountForEachSKU[idx].price;
        if (itemDefaultPrice < (itemPriceAfterDiscount || 0)) {
            flag = false;
            setFieldError(idx);
        }
    });

    return flag;
};

export const searchSKUByKeyword = async (
    keyword: string
): Promise<AxiosResponse<any, any> | undefined> => {
    try {
        const response = await getSkuList({
            pageNumber: DEFAULT_PAGE_NUMBER,
            pageSize: PAGE_SIZE_OPTIONS[0],
            search: { search: keyword },
            t: () => '',
        });

        return response;
    } catch (e) {
        return undefined;
    }
};

export const getUOMsBySKUAndProvince = async (
    skuId: string | number,
    provinceId: string | number
): Promise<IUOMData[]> => {
    try {
        const skuDetailsResponse = await getSkuDetail({ skuId: String(skuId), t: () => '' });
        const skuDetailsData = skuDetailsResponse.data?.data;
        if (typeof skuDetailsData !== 'object') return [];
        const { configurations } = skuDetailsData;
        if (!Array.isArray(configurations) || !configurations.length) return [];

        const results: IUOMData[] = [];
        configurations.forEach((item) => {
            const { sellingPrices } = item;
            if (!Array.isArray(sellingPrices) || !sellingPrices.length) {
                results.push({
                    id: item.id,
                    name: item.name,
                    sellingPrice: 0,
                    isPrimary: Boolean(item.isPrimary),
                });
                return;
            }
            const activeSellingPricesForTheProvince = sellingPrices.find(
                (price) => String(price.provinceId) === String(provinceId)
            );
            if (!activeSellingPricesForTheProvince) {
                results.push({
                    id: item.id,
                    name: item.name,
                    sellingPrice: 0,
                    isPrimary: Boolean(item.isPrimary),
                });
                return;
            }
            results.push({
                id: item.id,
                name: item.name,
                sellingPrice: Number(activeSellingPricesForTheProvince.grossPrice),
                isPrimary: Boolean(item.isPrimary),
            });
        });

        return results;
    } catch (e) {
        return [];
    }
};

export const validateComboDiscountFormData = async (
    methods: UseFormReturn<any, any>,
    t: any
): Promise<boolean> => {
    const { getValues, trigger, setError } = methods;
    const formValues = getValues();
    const { discountType, discountAffection } = formValues?.internalValues;
    const validationFields = getValidationTriggerFields(discountType, discountAffection);

    const isValid = await trigger(validationFields as any);
    if (!isValid) return false;

    let isValidDiscount = true;
    switch (discountAffection) {
        case ComboDiscountAffectionEnum.theWholeCombo: {
            isValidDiscount = validateComboDiscountForTheWholeCombo(formValues, () => {
                setError('criteria.discountForTheWholeCombo', {
                    message: t('Over default price'),
                });
            });
            break;
        }
        case ComboDiscountAffectionEnum.eachSKU: {
            isValidDiscount = validateComboDiscountForEachSKU(formValues, (idx) => {
                setError(`criteria.discountForEachSKU.${idx}.price`, {
                    message: t('Over default price'),
                });
            });
            break;
        }
    }

    return isValidDiscount;
};

export const shortenText = (text: string, maxDisplayCharacters: number) => {
    if (text.length <= maxDisplayCharacters) return text;
    const leftCharactersNumber = Math.floor(maxDisplayCharacters / 2);
    const rightCharactersNumber = Math.ceil(maxDisplayCharacters / 2);
    const leftText = String(text).substring(0, leftCharactersNumber);
    const rightText = String(text).substring(text.length - rightCharactersNumber, text.length);
    return `${leftText}...${rightText}`;
};
