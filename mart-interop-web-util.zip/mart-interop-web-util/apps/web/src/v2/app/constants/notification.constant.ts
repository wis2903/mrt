import { NotificationCampaignStatusEnum, NotificationStatusEnum } from '../@types/enum.type';

export const NOTIFICATION_CAMPAIGN_STATUS = [
    {
        label: 'common.label.all',
        value: NotificationCampaignStatusEnum.all,
    },
    {
        label: 'notification.status.scheduled',
        value: NotificationCampaignStatusEnum.scheduled,
    },
    {
        label: 'notification.status.sent',
        value: NotificationCampaignStatusEnum.sent,
    },
];
