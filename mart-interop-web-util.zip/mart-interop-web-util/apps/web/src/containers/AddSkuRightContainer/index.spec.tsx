import { Form } from 'antd';
import { AddSkuForm } from 'pages/AddSkuPage/types';
import { renderWithProvider } from 'test';
import Component from '.';

describe('Render component', () => {
  it('should render without crash', () => {
    const Wrapper = () => {
      const [form] = Form.useForm<AddSkuForm>();
      return (
        <Form form={form}>
          <Component showHintText={false} readOnly form={form} />
        </Form>
      );
    };
    const { container } = renderWithProvider(<Wrapper />);
    expect(container).toBeTruthy();
  });
});
