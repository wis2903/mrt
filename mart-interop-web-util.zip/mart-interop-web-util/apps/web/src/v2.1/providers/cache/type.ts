export type CacheValueType = string | number;

export interface ICacheProviderContext {
    values: () => Record<string, CacheValueType[]>;
    add: (key: string, value: CacheValueType) => void;
    get: (key: string) => CacheValueType[];
    find: (value?: CacheValueType) => CacheValueType | undefined;
}

export interface ICacheProviderProperties {
    children?: React.ReactNode;
}
