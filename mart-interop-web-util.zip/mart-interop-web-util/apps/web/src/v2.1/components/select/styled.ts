import styled from 'styled-components';

// import common styled constants
import {
    BUTTON_RESET,
    HOVERED_BACKGROUND_COLOR,
    OVERLAY,
    StyledFadedInContainer,
    StyledClickableComponentContainer,
    StyledInputComponentContainer,
} from '../../common/styled';

const optionPlaceholderBeforeStyle = `
    &::before {
        content: '';
        position: absolute;
        width: 100%;
        height: 24px;
        background: #f5f5f5;
        left: 0;
        top: 50%;
        transform: translateY(-50%);
    }
`;

export const StyledSelectComponentContainer = styled.div`
    display: inline-block;
    position: relative;
`;

export const StyledSelectComponentTrigger = styled(StyledInputComponentContainer)`
    ${BUTTON_RESET}
    border: 1px solid #d5d5d5;
    border-radius: 2px;
    padding: 4px 8px;
    text-align: left;
    position: relative;
    z-index: 99999;

    &::-webkit-input-placeholder {
        color: #000000;
    }
    &::-moz-placeholder {
        color: #000000;
    }
    &:-ms-input-placeholder {
        color: #000000;
    }
    &:-moz-placeholder {
        color: #000000;
    }

    &:focus {
        &::-webkit-input-placeholder {
            color: #888888;
        }
        &::-moz-placeholder {
            color: #888888;
        }
        &:-ms-input-placeholder {
            color: #888888;
        }
        &:-moz-placeholder {
            color: #888888;
        }
    }
`;

export const StyledSelectComponentOverlay = styled.div`
    ${OVERLAY}
`;

export const StyledSelectComponentDropdown = styled(StyledFadedInContainer)`
    position: absolute;
    min-width: 100%;
    top: calc(100% + 4px);
    left: 0;
    border: 1px solid #e5e5e5;
    padding: 4px 0;
    background: #ffffff;
    display: flex;
    flex-direction: column;
    gap: 2px;
    z-index: 99999;
    box-shadow: rgba(100, 100, 111, 0.1) 0px 7px 29px 0px;
`;

export const StyledSelectComponentDropdownEmpty = styled.div`
    color: #aaaaaa;
    padding: 4px 8px;
    font-size: 13px;
`;

export const StyledSelectComponentOptionPlaceholder = styled.div`
    width: 100%;
    height: 28px;
    position: relative;
    ${optionPlaceholderBeforeStyle}
`;

export const StyledSelectComponentOption = styled(StyledClickableComponentContainer)<{
    selected?: boolean;
    preSelected?: boolean;
    invisible?: boolean;
}>`
    ${BUTTON_RESET}
    padding: 4px 8px;
    text-align: left;
    width: max-content;
    min-width: 100%;
    position: relative;

    ${(props): string => {
        if (props.selected) {
            return `
                background: #e5e5e5;

                &:hover{
                    background: #e5e5e5;
                }
            `;
        }

        if (props.preSelected) {
            return `
                background: ${HOVERED_BACKGROUND_COLOR};
            `;
        }

        return '';
    }}

    ${(props): string => {
        if (!props.invisible) return '';
        return `
            color: transparent;
        `;
    }}
`;
