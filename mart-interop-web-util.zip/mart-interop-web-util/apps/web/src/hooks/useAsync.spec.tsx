import { useAsync } from './useAsync';
jest.mock('react', () => ({
  ...jest.requireActual('react'),
  useState: jest.fn().mockReturnValue(['test', jest.fn()]),
  useCallback: jest.fn().mockImplementation((fn) => fn),
  useEffect: jest.fn().mockImplementation((fn) => fn()),
  useMemo: jest.fn().mockImplementation((fn) => fn())
}));
describe('useAsync', () => {
  it('should return', async () => {
    useAsync(jest.fn().mockReturnValue(Promise.resolve({ data: { data: false } }) as any), true, null);
    useAsync(jest.fn().mockReturnValue(Promise.reject({ data: { data: false } }) as any), true, null);
  });
});
