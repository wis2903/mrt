import { GetSkuListApi, GetSkuListParams } from 'types/SKUDetail';

export const prepareGetSkuListParams = (params: GetSkuListParams): GetSkuListApi => {
    const results: GetSkuListApi = {
        page: params.pageNumber - 1,
        size: params.pageSize,
        textSearch: params.search?.search?.trim?.(),
        categoryId: params.search?.categoryId,
        subcategoryId: params.search?.subCategoryId,
        brandId: params.search?.brandId,
        minGrossPrice: params.search?.totalFrom,
        maxGrossPrice: params.search?.totalTo,
        provinceId: params.search?.provinceId,
        countryId: params.search?.countryId,
        sortName: params.sortName,
        sortCategory: params.sortCategory,
        sortBrand: params.sortBrand,
    };

    if (params.search?.hasPrice !== undefined) {
        results.hasPrice = params.search?.hasPrice;
    }

    return results;
};
