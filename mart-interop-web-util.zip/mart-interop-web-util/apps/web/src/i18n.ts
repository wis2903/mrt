/* eslint-disable global-require */
/**
 * i18n.js
 *
 * This will setup the i18n language files and locale data for your app.
 *
 *   IMPORTANT: This file is used by the internal build
 *   script `extract-intl`, and must use CommonJS module syntax
 *   You CANNOT use import/export in this file.
 */

import enTranslationMessages from './locales/en/translation.json';
import viTranslationMessages from './locales/vi/translation.json';
export enum Lang {
  En = 'en',
  Vi = 'vi'
}
const DEFAULT_LOCALE = Lang.En;
const appLocales = [Lang.En, Lang.Vi];

const translationMessages = {
  en: enTranslationMessages,
  vi: viTranslationMessages
};

export { appLocales, translationMessages, DEFAULT_LOCALE };
