export type SelectComponentOptionValueType = string | number;

export interface ISelectComponentOption {
    label: string;
    value: SelectComponentOptionValueType;
}

export interface ISelectComponentProperties {
    value?: SelectComponentOptionValueType;
    options?: ISelectComponentOption[];
    searchFn?: (keyword: string) => ISelectComponentOption[] | Promise<ISelectComponentOption[]>;
    findByValueFn?: (
        value: SelectComponentOptionValueType
    ) => ISelectComponentOption | Promise<ISelectComponentOption | undefined> | undefined;
    onChange?: (option: ISelectComponentOption) => void;
    onBlur?: VoidFunction;
}

export interface IExtendedProperties extends ISelectComponentProperties {
    isShowDropdown?: boolean;
    isSsrSearching?: boolean;
    isReadyToShowDropdownContent?: boolean;
    activeOption?: ISelectComponentOption;
    filteredOptions?: ISelectComponentOption[];
    search?: string;
    preSelectedOption?: ISelectComponentOption;
    scrollableAreaRef?: React.RefObject<HTMLDivElement>;
    triggerRef?: React.RefObject<HTMLInputElement>;
    handleToggleDropdown?: VoidFunction;
    handleCloseDropdown?: VoidFunction;
    handleOnSelectOption?: (option: ISelectComponentOption) => VoidFunction;
    handleClearPreSelectedOption?: VoidFunction;
    handleClearTriggerValue?: VoidFunction;
    handleOnSearchChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
    handleOnTriggerBlur?: VoidFunction;
}

export type HocReturnType = {
    (properties: ISelectComponentProperties): JSX.Element,
    displayName?: string;
};
