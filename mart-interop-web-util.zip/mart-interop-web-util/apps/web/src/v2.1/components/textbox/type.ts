export interface ITextboxComponentProperties extends React.InputHTMLAttributes<HTMLInputElement> {}
