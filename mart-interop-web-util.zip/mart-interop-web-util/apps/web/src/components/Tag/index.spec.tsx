import { renderWithProvider } from 'test'
import Component from '.'
import { InactivePromotionSubStatusName } from 'constants/promotions'

describe('Render component', () => {
  it('should render with default state', () => {
    const { container } = renderWithProvider(<Component>{InactivePromotionSubStatusName.DISCONTINUED}</Component>)

    expect(container).toMatchSnapshot()
  })
  it('should render with custom state', () => {
    const { container } = renderWithProvider(
      <Component
        tagClassName='bg-[#ffdee4]'
        textClassName='text-[#c31424]'
        borderClassName='border border-solid border-[#c31424]'>
        {InactivePromotionSubStatusName.DISCONTINUED}
      </Component>
    )

    expect(container).toMatchSnapshot()
  })
})
