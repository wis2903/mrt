import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { call, put } from 'redux-saga/effects';
import { createSliceSaga, SagaType } from 'redux-toolkit-saga';
import { AppState } from 'store/store';
import { GetDistrictParams } from 'types/Location';
import { MasterDataKey, MasterDataItem } from 'types/MasterDataKey';
import { getDistrict, getMasterData } from './apis';
import { ProvinceDataItem } from '../../types/MasterDataKey';
import { orderBy } from 'lodash';

// ---------------------------------------
const sliceName = 'masterData';
export type MasterDataState = {
    masterData?: Record<MasterDataKey, MasterDataItem[]>;
    districts?: any[];
};
const initialState: MasterDataState = {};

// ---------------------------------------
const reducers = {
    changeLoading: (
        state: MasterDataState,
        action: PayloadAction<boolean>
    ) => ({
        ...state,
        loading: action.payload,
    }),
    fetchDataSuccess: (state: MasterDataState, action: PayloadAction<any>) => ({
        ...state,
        masterData: {
            ...action.payload,
            allProvinces: action.payload.provinceList,
        },
    }),
    fetchDistrictsSuccess: (
        state: MasterDataState,
        action: PayloadAction<any>
    ) => ({
        ...state,
        districts: action.payload,
    }),
    adjustMasterData: (state: MasterDataState, action: PayloadAction<any>) => ({
        ...state,
        masterData: {
            ...state.masterData,
            ...action.payload,
        },
    }),
};

const sliceOption = {
    name: sliceName,
    initialState,
    reducers,
};
const slice = createSlice(sliceOption);
const { reducer, actions: reducerActions } = slice;

// selectors
// -----------------------------------------------------

const selectorByKey =
    <T = MasterDataItem>(key: MasterDataKey) =>
    (state: AppState) => {
        const dataSelected = state[sliceName];
        return orderBy(dataSelected.masterData?.[key], 'name') as T[];
    };

const selectCategoryList = (state: AppState) => {
    const dataSelected = state[sliceName] as MasterDataState;
    return orderBy(dataSelected.masterData?.categoryList, 'name');
};

const selectorCategoryListLevel2 = (state: AppState) => {
    const dataSelected = state[sliceName] as MasterDataState;
    return orderBy(
        dataSelected.masterData?.categoryList
            .filter((category) => category.parentName)
            .map((category) => ({
                ...category,
                name: `${category.parentName} \\ ${category.name}`,
            })),
        'name'
    );
};

const selectorCategoryListAllLevel = (state: AppState) => {
    const dataSelected = state[sliceName] as MasterDataState;
    return orderBy(
        dataSelected.masterData?.categoryList.map((category) => ({
            ...category,
            name: category.parentName
                ? `${category.parentName} \\ ${category.name}`
                : category.name,
        })),
        'name'
    );
};

const selectorProvinceList = (state: AppState) => {
    const dataSelected = state[sliceName];
    return orderBy(
        dataSelected?.masterData?.provinceList,
        'name'
    ) as ProvinceDataItem[];
};

const selectLoading = (state: AppState) => {
    const dataSelected = state[sliceName];
    return dataSelected.loading;
};

const selectDistrict = (state: AppState) => {
    const dataSelected = state[sliceName] as MasterDataState;
    return orderBy(dataSelected.districts, 'name');
};

const selectors = {
    selectorByKey,
    selectorProvinceList,
    selectLoading,
    selectDistrict,
    selectCategoryList,
    selectorCategoryListLevel2,
    selectorCategoryListAllLevel,
};

// ---------------------------------------

const sagaOption = {
    name: sliceName,
    sagaType: SagaType.TakeLatest,
    caseSagas: {
        *fetchMasterData(): any {
            try {
                yield put(slice.actions.changeLoading(true));

                const { data } = yield call(getMasterData);

                yield put(slice.actions.fetchDataSuccess(data.data));
            } catch (err: any) {
                console.error('fetchMasterData error: ', err);
            } finally {
                yield put(slice.actions.changeLoading(false));
            }
        },
        *fetchMasterDataWithCallback(
            action: PayloadAction<{ callback: (data: any) => void }>
        ): any {
            try {
                yield put(slice.actions.changeLoading(true));
                const { data } = yield call(getMasterData);
                yield put(slice.actions.fetchDataSuccess(data.data));
                action.payload.callback(data.data);
            } catch (err: any) {
                console.error('fetchMasterData error: ', err);
            } finally {
                yield put(slice.actions.changeLoading(false));
            }
        },
        *fetchDistricts(action: PayloadAction<GetDistrictParams>): any {
            try {
                yield put(slice.actions.changeLoading(true));

                const { data } = yield call(getDistrict, action.payload);

                yield put(slice.actions.fetchDistrictsSuccess(data.data));
            } catch (err: any) {
                console.error('fetchMasterData error: ', err);
            } finally {
                yield put(slice.actions.changeLoading(false));
            }
        },
    },
};
const sliceSaga = createSliceSaga(sagaOption);
const { saga, actions: sagaActions } = sliceSaga;
// ---------------------------------------

export {
    initialState,
    sliceName,
    reducer,
    saga,
    reducerActions,
    sagaActions,
    selectors,
    sagaOption,
};
