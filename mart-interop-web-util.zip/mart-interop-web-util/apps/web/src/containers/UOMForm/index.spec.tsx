import userEvent from '@testing-library/user-event';
import { renderWithProvider, screen } from 'test';
import Component from '.';
jest.mock('apis/sku', () => ({
  ...jest.requireActual('apis/sku'),
  validateBarcode: jest.fn().mockReturnValue(Promise.resolve({ data: { data: false } }) as any)
}));
describe('Render component', () => {
  it('should render without crash', async () => {
    const props = {
      parentForm: {
        getFieldValue: jest.fn()
      } as any,
      disableQuantity: false,
      initialValues: {},
      selected: -1,
      configurations: [{ name: 'test', quantity: 1 }] as any[],
      onFinish: jest.fn(),
      onChange: jest.fn()
    };

    const { container } = renderWithProvider(<Component {...props} />);
    await userEvent.type(screen.getByTestId('uom-name'), 'test');
    await userEvent.type(screen.getByTestId('quantity'), '0');
    await userEvent.type(screen.getByTestId('barcode'), '0');
    await userEvent.click(screen.getByTestId('uom-name'));
    expect(container).toBeTruthy();
  });
});
