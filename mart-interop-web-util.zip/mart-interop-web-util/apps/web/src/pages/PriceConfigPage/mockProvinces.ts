import { ProvinceDataItem } from 'types/MasterDataKey';

export const mockProvinces: ProvinceDataItem[] = [
  {
    id: '01',
    name: 'Thành phố Hà Nội',
    warehouseId: null,
    region: 'Red River Delta'
  },
  {
    id: '02',
    name: 'Tỉnh Hà Giang',
    warehouseId: null,
    region: 'North East'
  },
  {
    id: '04',
    name: 'Tỉnh Cao Bằng',
    warehouseId: null,
    region: 'North East'
  },
  {
    id: '06',
    name: 'Tỉnh Bắc Kạn',
    warehouseId: null,
    region: 'North East'
  },
  {
    id: '08',
    name: 'Tỉnh Tuyên Quang',
    warehouseId: null,
    region: 'North East'
  },
  {
    id: '10',
    name: 'Tỉnh Lào Cai',
    warehouseId: null,
    region: 'North East'
  },
  {
    id: '11',
    name: 'Tỉnh Điện Biên',
    warehouseId: null,
    region: 'North East'
  },
  {
    id: '12',
    name: 'Tỉnh Lai Châu',
    warehouseId: null,
    region: 'North East'
  },
  {
    id: '14',
    name: 'Tỉnh Sơn La',
    warehouseId: null,
    region: 'North East'
  },
  {
    id: '15',
    name: 'Tỉnh Yên Bái',
    warehouseId: null,
    region: 'North East'
  },
  {
    id: '17',
    name: 'Tỉnh Hoà Bình',
    warehouseId: null,
    region: 'North East'
  },
  {
    id: '19',
    name: 'Tỉnh Thái Nguyên',
    warehouseId: null,
    region: 'North East'
  },
  {
    id: '20',
    name: 'Tỉnh Lạng Sơn',
    warehouseId: null,
    region: 'North East'
  },
  {
    id: '22',
    name: 'Tỉnh Quảng Ninh',
    warehouseId: null,
    region: 'North East'
  },
  {
    id: '24',
    name: 'Tỉnh Bắc Giang',
    warehouseId: null,
    region: 'North East'
  },
  {
    id: '25',
    name: 'Tỉnh Phú Thọ',
    warehouseId: null,
    region: 'North East'
  },
  {
    id: '26',
    name: 'Tỉnh Vĩnh Phúc',
    warehouseId: null,
    region: 'Red River Delta'
  },
  {
    id: '27',
    name: 'Tỉnh Bắc Ninh',
    warehouseId: null,
    region: 'Red River Delta'
  },
  {
    id: '30',
    name: 'Tỉnh Hải Dương',
    warehouseId: null,
    region: 'Red River Delta'
  },
  {
    id: '31',
    name: 'Thành phố Hải Phòng',
    warehouseId: null,
    region: 'Red River Delta'
  },
  {
    id: '33',
    name: 'Tỉnh Hưng Yên',
    warehouseId: null,
    region: 'Red River Delta'
  },
  {
    id: '34',
    name: 'Tỉnh Thái Bình',
    warehouseId: null,
    region: 'Red River Delta'
  },
  {
    id: '35',
    name: 'Tỉnh Hà Nam',
    warehouseId: null,
    region: 'Red River Delta'
  },
  {
    id: '36',
    name: 'Tỉnh Nam Định',
    warehouseId: null,
    region: 'Red River Delta'
  },
  {
    id: '37',
    name: 'Tỉnh Ninh Bình',
    warehouseId: null,
    region: 'Red River Delta'
  },
  {
    id: '38',
    name: 'Tỉnh Thanh Hóa',
    warehouseId: null,
    region: 'North Central Coast'
  },
  {
    id: '40',
    name: 'Tỉnh Nghệ An',
    warehouseId: null,
    region: 'North Central Coast'
  },
  {
    id: '42',
    name: 'Tỉnh Hà Tĩnh',
    warehouseId: null,
    region: 'North Central Coast'
  },
  {
    id: '44',
    name: 'Tỉnh Quảng Bình',
    warehouseId: null,
    region: 'North Central Coast'
  },
  {
    id: '45',
    name: 'Tỉnh Quảng Trị',
    warehouseId: null,
    region: 'North Central Coast'
  },
  {
    id: '46',
    name: 'Tỉnh Thừa Thiên Huế',
    warehouseId: null,
    region: 'North Central Coast'
  },
  {
    id: '48',
    name: 'Thành phố Đà Nẵng',
    warehouseId: 11,
    region: 'South Central Coast'
  },
  {
    id: '49',
    name: 'Tỉnh Quảng Nam',
    warehouseId: null,
    region: 'South Central Coast'
  },
  {
    id: '51',
    name: 'Tỉnh Quảng Ngãi',
    warehouseId: null,
    region: 'South Central Coast'
  },
  {
    id: '52',
    name: 'Tỉnh Bình Định',
    warehouseId: null,
    region: 'South Central Coast'
  },
  {
    id: '54',
    name: 'Tỉnh Phú Yên',
    warehouseId: null,
    region: 'South Central Coast'
  },
  {
    id: '56',
    name: 'Tỉnh Khánh Hòa',
    warehouseId: 10,
    region: 'South Central Coast'
  },
  {
    id: '58',
    name: 'Tỉnh Ninh Thuận',
    warehouseId: null,
    region: 'South Central Coast'
  },
  {
    id: '60',
    name: 'Tỉnh Bình Thuận',
    warehouseId: null,
    region: 'South Central Coast'
  },
  {
    id: '62',
    name: 'Tỉnh Kon Tum',
    warehouseId: null,
    region: 'Central Highlands'
  },
  {
    id: '64',
    name: 'Tỉnh Gia Lai',
    warehouseId: null,
    region: 'Central Highlands'
  },
  {
    id: '66',
    name: 'Tỉnh Đắk Lắk',
    warehouseId: null,
    region: 'Central Highlands'
  },
  {
    id: '67',
    name: 'Tỉnh Đắk Nông',
    warehouseId: null,
    region: 'Central Highlands'
  },
  {
    id: '68',
    name: 'Tỉnh Lâm Đồng',
    warehouseId: null,
    region: 'Central Highlands'
  },
  {
    id: '70',
    name: 'Tỉnh Bình Phước',
    warehouseId: null,
    region: 'South East'
  },
  {
    id: '72',
    name: 'Tỉnh Tây Ninh',
    warehouseId: null,
    region: 'South East'
  },
  {
    id: '74',
    name: 'Tỉnh Bình Dương',
    warehouseId: 14,
    region: 'South East'
  },
  {
    id: '75',
    name: 'Tỉnh Đồng Nai',
    warehouseId: 15,
    region: 'South East'
  },
  {
    id: '77',
    name: 'Tỉnh Bà Rịa - Vũng Tàu',
    warehouseId: null,
    region: 'South East'
  },
  {
    id: '79',
    name: 'Thành phố Hồ Chí Minh',
    warehouseId: null,
    region: 'South East'
  },
  {
    id: '80',
    name: 'Tỉnh Long An',
    warehouseId: 7,
    region: 'Mekong River Delta'
  },
  {
    id: '82',
    name: 'Tỉnh Tiền Giang',
    warehouseId: 8,
    region: 'Mekong River Delta'
  },
  {
    id: '83',
    name: 'Tỉnh Bến Tre',
    warehouseId: 12,
    region: 'Mekong River Delta'
  },
  {
    id: '84',
    name: 'Tỉnh Trà Vinh',
    warehouseId: 13,
    region: 'Mekong River Delta'
  },
  {
    id: '86',
    name: 'Tỉnh Vĩnh Long',
    warehouseId: 5,
    region: 'Mekong River Delta'
  },
  {
    id: '87',
    name: 'Tỉnh Đồng Tháp',
    warehouseId: 6,
    region: 'Mekong River Delta'
  },
  {
    id: '89',
    name: 'Tỉnh An Giang',
    warehouseId: 2,
    region: 'Mekong River Delta'
  },
  {
    id: '91',
    name: 'Tỉnh Kiên Giang',
    warehouseId: 3,
    region: 'Mekong River Delta'
  },
  {
    id: '92',
    name: 'Thành phố Cần Thơ',
    warehouseId: 2,
    region: 'Mekong River Delta'
  },
  {
    id: '93',
    name: 'Tỉnh Hậu Giang',
    warehouseId: 1,
    region: 'Mekong River Delta'
  },
  {
    id: '94',
    name: 'Tỉnh Sóc Trăng',
    warehouseId: 4,
    region: 'Mekong River Delta'
  },
  {
    id: '95',
    name: 'Tỉnh Bạc Liêu',
    warehouseId: 4,
    region: 'Mekong River Delta'
  },
  {
    id: '96',
    name: 'Tỉnh Cà Mau',
    warehouseId: 9,
    region: 'Mekong River Delta'
  }
];
