import { FormInstance, Modal } from 'antd';
import React, { FormEvent } from 'react';
import UOMForm from 'containers/UOMForm';
import { AddSkuForm, SKUConfigurationForm } from 'pages/AddSkuPage/types';
import useLocales from 'hooks/useLocales';
import Button from 'components/Button'
export interface EditUOMModalProps {
  index: number;
  parentForm: FormInstance<AddSkuForm>;
  configurations: SKUConfigurationForm[];
  onSetConfigurations: (configurations: SKUConfigurationForm[]) => void;
  onClose: () => void;
  onChange: (event: FormEvent<HTMLFormElement>) => void;
  isNew?: boolean;
}
const EditUOMModal: React.FC<EditUOMModalProps> = ({
  isNew,
  index,
  parentForm,
  configurations,
  onChange,
  onSetConfigurations,
  onClose
}) => {
  const { t } = useLocales();
  const handleFinish = (values: SKUConfigurationForm) => {
    const _configurations = configurations.map((item, i) => {
      if (i === index) {
        return {
          ...values,
          amastSellable: configurations[i].amastSellable
        };
      }
      return item;
    });
    onSetConfigurations(_configurations);
    onClose();
  };

  const disableQuantity = index === 0;
  const initialValues = configurations[index];

  return (
    <>
      <Modal
        title={t('common.Edit unit of measurement')}
        width={1000}
        visible
        destroyOnClose
        onCancel={onClose}
        footer={[
          <Button key='back' onClick={onClose}>
            {t('common.button.cancel')}
          </Button>,
          <Button key='submit' form='modalForm' type='primary' htmlType='submit'>
            {t('common.button.save')}
          </Button>
        ]}>
        <UOMForm
          isNew={isNew}
          selected={index}
          parentForm={parentForm}
          disableQuantity={disableQuantity}
          initialValues={initialValues}
          configurations={configurations}
          onChange={onChange}
          onFinish={handleFinish}
        />
      </Modal>
    </>
  );
};

export default EditUOMModal;
