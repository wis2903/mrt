const globalTest = require('./global.js')
describe('Global', () => {
  it('should return correct value', () => {
    const result = globalTest.process()
    expect(result.code).toBe('')
  })
})
