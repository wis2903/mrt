import PageHeader from 'layouts/components/PageHeader';
import Filters from './Filters';
import Content from 'layouts/components/Content';
import useLocales from 'hooks/useLocales';
import DropdownActions from 'v2/app/components/dropdown-actions/dropdown-actions';
import BlockableContainer from 'v2/app/layouts/blockable-container/blockable-container';
import { OrdersStyled } from 'pages/Orders/styled';
import { INVENTORY_URI } from '../../routes/routes';
import { ColumnsType } from 'antd/lib/table';
import { RequestStatus, useAsync } from 'hooks/useAsync';
import { fetchList, syncInventory } from 'apis/inventory';
import { useCallback, useContext, useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { AbilityContext } from 'casl/can';
import { Action, Page } from 'constants/ability';
import {
    Inventory,
    InventoryFilter,
    TypeOfQuantity,
} from '../../types/Inventory';
import { Empty, message, notification, Table } from 'antd';
import {
    DEFAULT_PAGE_NUMBER,
    DEFAULT_PAGE_SIZE,
    PAGE_SIZE_OPTIONS,
} from 'constants/common';

const HomePage = () => {
    const ability = useContext(AbilityContext);
    const initialFilters: InventoryFilter = {
        isGetAll: false,
        page: 1,
        size: PAGE_SIZE_OPTIONS[0],
    };
    const [isProcessing, setIsProcessing] = useState<boolean>(false);
    const [ts, setTs] = useState<number>(+new Date());
    const [searchParams, setSearchParams] = useSearchParams();
    const setFilters = (newFilters: any) => {
        const values: any = {
            wi: newFilters.warehouseId,
            on: newFilters.typeOfOnhandQuantity,
            av: newFilters.typeOfAvailableQuantity,
            s: newFilters.textSearch,
        };
        Object.keys(values).forEach((key) => {
            return !values[key]
                ? searchParams.delete(key)
                : searchParams.set(key, values[key]);
        });
        setSearchParams(searchParams);
    };
    const { t } = useLocales();

    const handleSyncInventory =
        (item: any): VoidFunction =>
        async (): Promise<void> => {
            setIsProcessing(true);
            try {
                await syncInventory({
                    productCode: item.skuCode,
                    warehouseId: item.warehouseId,
                });
                setTs(+new Date());
            } catch(e){
              message.error(Object(e).response?.data?.detail || 'Internal Server Error')
            } finally {
                setIsProcessing(false);
            }
        };

    const routes = [
        {
            path: '',
            breadcrumbName: t('Home'),
        },
        {
            path: INVENTORY_URI,
            breadcrumbName: t('Inventory'),
        },
    ];
    const columns: ColumnsType<Inventory> = [
        {
            title: t('Warehouse'),
            dataIndex: 'warehouseName',
            align: 'left',
            key: 'warehouseName',
        },
        {
            title: t('SKU Code'),
            dataIndex: 'skuCode',
            align: 'left',
            key: 'skuCode',
        },
        {
            title: t('SKU Name'),
            dataIndex: 'skuName',
            align: 'left',
            key: 'skuName',
        },
        {
            title: t('Primary UOM'),
            dataIndex: 'primaryUomName',
            align: 'left',
            key: 'primaryUomName',
        },
        {
            title: t('Barcode'),
            dataIndex: 'barcode',
            align: 'left',
            key: 'barcode',
        },
        {
            title: t('Onhand Quantity'),
            dataIndex: 'onhandQuantity',
            align: 'right',
            key: 'onhandQuantity',
        },
        {
            title: t('Onhold Quantity'),
            dataIndex: 'onholdQuantity',
            align: 'right',
            key: 'onholdQuantity',
        },
        {
            title: t('Available Quantity'),
            dataIndex: 'availableQuantity',
            align: 'right',
            key: 'availableQuantity',
        },
    ];

    if (ability.can(Action.SyncInventory, Page.Inventory)) {
        columns.push({
            title: t('common.Action'),
            dataIndex: 'action',
            align: 'right',
            key: 'action',
            render: (_, record, idx) => {
                return (
                    <DropdownActions
                        dropdownVerticalDirection={idx === (inventory.value.data.data?.length || 0) - 1 ? 'top' : 'bottom'}
                        actions={[
                            {
                                label: t('Resync inventory'),
                                onSelect: handleSyncInventory(record),
                            },
                        ]}
                    />
                );
            },
        });
    }

    const _fetchList = useCallback(
        async (_params: any) => {
            try {
                const response = await fetchList(_params);
                return response;
            } catch (e: any) {
                notification.error({
                    message: `Failed`,
                    description:
                        e.response?.data?.title ||
                        t('Failed to fetch inventory list, please try again.'),
                    placement: 'top',
                });
                return Promise.reject();
            }
            // eslint-disable-next-line react-hooks/exhaustive-deps
        },
        [t]
    );
    const inventory: {
        value: {
            data: {
                data: Inventory[];
                totalPage: number;
                totalElement: number;
            };
            status: RequestStatus;
        };
        status: RequestStatus;
        execute: any;
    } = useAsync(_fetchList, false, []);
    const pageNumber = parseInt(
        searchParams.get('pn') || DEFAULT_PAGE_NUMBER.toString()
    );
    const pageSize = parseInt(
        searchParams.get('ps') || DEFAULT_PAGE_SIZE.toString()
    );
    useEffect(() => {
        const _filters = {
            ...initialFilters,
            warehouseId: searchParams.get('wi')
                ? parseInt(searchParams.get('wi') as any)
                : null,
            page: pageNumber - 1,
            size: pageSize,
            greaterThanOnhand:
                searchParams.get('on') === TypeOfQuantity.GreaterThan0
                    ? 0
                    : null,
            equalOnhand:
                searchParams.get('on') === TypeOfQuantity.EqualTo0 ? 0 : null,
            greaterThanAvailable:
                searchParams.get('av') === TypeOfQuantity.GreaterThan0
                    ? 0
                    : null,
            equalAvailable:
                searchParams.get('av') === TypeOfQuantity.EqualTo0 ? 0 : null,
            textSearch: searchParams.get('s') || undefined,
        };
        inventory.execute(_filters);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [searchParams, ts]);
    const { status } = inventory;
    const data = inventory?.value?.data?.data;
    const totalPage = inventory?.value?.data?.totalPage;
    const totalElement = inventory?.value?.data?.totalElement;

    return (
        <OrdersStyled>
            <PageHeader title={t('Inventory_title')} breadcrumb={{ routes }} />
            <Content>
                <Filters
                    initialValues={initialFilters}
                    onChange={(value: InventoryFilter) => {
                        setFilters({
                            ...value,
                            pageSize: DEFAULT_PAGE_SIZE,
                            pageNumber: DEFAULT_PAGE_NUMBER,
                        });
                    }}
                />
                <BlockableContainer isBlocked={isProcessing}>
                    <Table
                        locale={{
                            emptyText: (
                                <Empty
                                    image={Empty.PRESENTED_IMAGE_SIMPLE}
                                    description={t('common.No Data')}
                                />
                            ),
                        }}
                        loading={status === RequestStatus.Pending}
                        columns={columns}
                        dataSource={data?.map(
                            (_inventory: Inventory, index: number) => ({
                                ..._inventory,
                                no: (index % totalPage) + 1,
                            })
                        )}
                        rowKey={'id'}
                        pagination={{
                            total: totalElement,
                            showTotal: (_total, range) =>
                                t('common.message.showingFromTo', {
                                    from: range[0].toString(),
                                    to: range[1].toString(),
                                    total: _total.toString(),
                                }),
                            pageSize: pageSize,
                            current: pageNumber,
                            showLessItems: true,
                            hideOnSinglePage:
                                !!totalPage &&
                                totalPage <= PAGE_SIZE_OPTIONS[0],
                            pageSizeOptions: PAGE_SIZE_OPTIONS,
                            onChange: (_pageNumber, _pageSize) => {
                                searchParams.set('pn', _pageNumber.toString());
                                searchParams.set('ps', _pageSize.toString());
                                setSearchParams(searchParams);
                            },
                        }}
                    />
                </BlockableContainer>
            </Content>
        </OrdersStyled>
    );
};
export default HomePage;
