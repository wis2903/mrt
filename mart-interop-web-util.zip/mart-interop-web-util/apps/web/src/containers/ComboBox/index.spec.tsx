import { renderWithProvider } from 'test';
import { selectors } from 'store/masterData/slice';
import Component from '.';

describe('Render component', () => {
  it('should render without crash', () => {
    jest.spyOn(selectors, 'selectorByKey').mockReturnValue(() => [{ id: 1, code: 'test', name: 'test', parentId: 1, parentName: 'test' }]);
    const { container } = renderWithProvider(<Component type='brandList' />);

    expect(container).toBeTruthy();
  });
});
