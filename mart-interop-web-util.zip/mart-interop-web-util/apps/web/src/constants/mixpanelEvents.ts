export enum MixpanelEvent {
  CLICKED_ORDER_LIST = 'Clicked order list',
  CLICKED_ORDER_DETAIL = 'Clicked order detail',
  CLICKED_ON_ACTION_MENU = 'Clicked on Action menu',
  CONFIRMED_ORDER = 'Confirmed order'
}

export enum MixpanelEventProperty {
  ORDER_ID = 'Order ID',
  PROVINCE = 'Province',
  PAGE = 'Page'
}
