import ScrollableArea from '../scrollable-area';
import { IExtendedProperties } from './type';
import { hoc } from './hoc';
import {
    StyledSelectComponentContainer,
    StyledSelectComponentDropdown,
    StyledSelectComponentOption,
    StyledSelectComponentOptionPlaceholder,
    StyledSelectComponentOverlay,
    StyledSelectComponentTrigger,
} from './styled';

const SelectComponent = hoc(
    ({
        isShowDropdown,
        isSsrSearching,
        isReadyToShowDropdownContent,
        search,
        activeOption,
        filteredOptions,
        preSelectedOption,
        scrollableAreaRef,
        triggerRef,
        handleToggleDropdown,
        handleCloseDropdown,
        handleOnSelectOption,
        handleOnSearchChange,
        handleOnTriggerBlur,
    }: IExtendedProperties): JSX.Element => {
        return (
            <StyledSelectComponentContainer>
                <StyledSelectComponentTrigger
                    spellCheck={false}
                    placeholder={activeOption?.label}
                    ref={triggerRef}
                    value={search}
                    onFocus={handleToggleDropdown}
                    onBlur={handleOnTriggerBlur}
                    onChange={handleOnSearchChange}
                />

                {isShowDropdown && !!filteredOptions?.length && (
                    <>
                        <StyledSelectComponentOverlay onClick={handleCloseDropdown} />
                        <StyledSelectComponentDropdown>
                            <ScrollableArea maxHeight={300} reference={scrollableAreaRef}>
                                {((): React.ReactNode => {
                                    if (isSsrSearching) {
                                        return (
                                            <>
                                                <StyledSelectComponentOptionPlaceholder />
                                                <StyledSelectComponentOptionPlaceholder />
                                                <StyledSelectComponentOptionPlaceholder />
                                                <StyledSelectComponentOptionPlaceholder />
                                            </>
                                        );
                                    }

                                    return filteredOptions.map((option) => (
                                        <StyledSelectComponentOption
                                            key={option.value}
                                            selected={option.value === activeOption?.value}
                                            preSelected={option.value === preSelectedOption?.value}
                                            invisible={!isReadyToShowDropdownContent}
                                            onClick={handleOnSelectOption?.(option)}
                                            data-value={option.value}
                                        >
                                            {option.label}
                                        </StyledSelectComponentOption>
                                    ));
                                })()}
                            </ScrollableArea>
                        </StyledSelectComponentDropdown>
                    </>
                )}
            </StyledSelectComponentContainer>
        );
    }
);

SelectComponent.displayName = 'SelectComponent';
export { SelectComponent };
