import { AbilityContext } from 'casl/can';
import * as authHook from 'hooks/useAuth';
import { useContext } from 'react';
import { renderWithProvider } from 'test';
import { mockUser } from '__mocks__/mockUser';
import Component from '.';
import { updateAbility } from '../casl/ability';
const data = {
  user: {},
  province: [],
  keycloak: null,
  initialing: false,
  signin: jest.fn(),
  signout: jest.fn()
};
describe('Router', () => {
  it('should render normally with truthy user', () => {
    jest.spyOn(authHook, 'useAuth').mockReturnValueOnce(data);
    const { container } = renderWithProvider(<Component />);
    expect(container).toBeTruthy();
  });
  it('should render normally with user null', () => {
    jest.spyOn(authHook, 'useAuth').mockReturnValueOnce({ ...data, user: null });
    const { container } = renderWithProvider(<Component />);
    expect(container).toBeTruthy();
  });
  it('should render normally', () => {
    jest.spyOn(authHook, 'useAuth').mockReturnValueOnce(data);
    const MockComponent = () => {
      const ability = useContext(AbilityContext);
      updateAbility(ability, mockUser);
      return <Component />;
    }
    const { container } = renderWithProvider(<MockComponent />);
    expect(container).toBeTruthy();
  });
});
