import userEvent from '@testing-library/user-event';
import { fireEvent, renderWithProvider, screen } from 'test';
import Component from '.';
import * as antd from 'antd';

describe('Render component', () => {
  it('should render without crash', () => {
    const { container } = renderWithProvider(<Component />);

    expect(container).toBeTruthy();
  });
});
describe('actions', () => {
  afterEach(() => {
    jest.clearAllMocks();
    jest.restoreAllMocks();
  });
  it('should handle beforeUpload', () => {
    const messageErr = jest.spyOn(antd.message, 'error');
    renderWithProvider(<Component />);
    const uploadBeforeUpload = screen.queryByTestId('upload-beforeUpload');

    const file = new File(['hello'], 'hello.png', { type: 'image/svg+xml' });
    uploadBeforeUpload && fireEvent.change(uploadBeforeUpload, { target: { file: { ...file, size: 4, status: 'done' }, files: [file] } });
    uploadBeforeUpload && fireEvent.change(uploadBeforeUpload, { target: { files: [{ ...file, status: 'done' }] } });

    expect(messageErr).toBeCalled();
  });
  it('should handle onChange', () => {
    const spyOnChange = jest.fn();
    renderWithProvider(<Component onChange={spyOnChange} />);

    const uploadBeforeUpload = screen.queryByTestId('upload-onChange');
    const file = new File(['hello'], 'hello.png', { type: 'image/svg+xml' });

    uploadBeforeUpload && fireEvent.change(uploadBeforeUpload, { file: file, files: [file] });

    expect(spyOnChange).toBeCalled();
  });
  it('should handle remove', async () => {
    const user = userEvent.setup();
    const spyOnChange = jest.fn();
    renderWithProvider(<Component onChange={spyOnChange} value='src' />);

    const uploadBeforeUpload = screen.getByTestId('remove');
    await user.click(uploadBeforeUpload);

    expect(spyOnChange).toBeCalled();
  });
});
