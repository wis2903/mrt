import React from 'react';
import { CacheValueType, ICacheProviderContext, ICacheProviderProperties } from './type';

export const CacheProviderContext = React.createContext<ICacheProviderContext>({
    values: () => ({}),
    add: () => undefined,
    get: () => [],
    find: () => undefined,
});

export const CacheProvider = ({ children }: ICacheProviderProperties): JSX.Element => {
    const cacheRef = React.useRef<Record<string, CacheValueType[]>>({});

    return (
        <CacheProviderContext.Provider
            value={{
                values: (): Record<string, CacheValueType[]> => {
                    return cacheRef.current;
                },
                add: (key: string, value: string | number): void => {
                    if (!cacheRef.current[key]) {
                        cacheRef.current[key] = [value];
                        return;
                    }
                    if (cacheRef.current[key].find((item) => item === value)) return;
                    if (cacheRef.current[key].length >= 100) {
                        cacheRef.current[key].splice(1);
                    }
                    cacheRef.current[key].push(value);
                },
                get: (key: string): CacheValueType[] => {
                    return cacheRef.current[key] || [];
                },
                find: (value?: CacheValueType): CacheValueType | undefined => {
                    if (value === 0) return value;
                    if (!value) return undefined;
                    const keys = Object.keys(cacheRef.current);
                    for (let i = 0; i < keys.length; i++) {
                        if (cacheRef.current[keys[i]].find((item) => item === value)) {
                            return value;
                        }
                    }

                    return undefined;
                },
            }}
        >
            {children}
        </CacheProviderContext.Provider>
    );
};
