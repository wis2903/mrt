import confirmModal from 'components/ConfirmModal';
import useLocales from 'hooks/useLocales';
import Content from 'layouts/components/Content';
import PageHeader from 'layouts/components/PageHeader';
import React, { useCallback, useEffect, useState } from 'react';
import ActivityLogs from './components/ActivityLogs';
import DeliveryAddress from './components/DeliveryAddress';
import OrderItems from './components/OrderItems';
import Overview from './components/Overview';
import Button from 'components/Button';
import CancelReasonSelection from 'pages/Orders/components/cancelReasonSelection/CancelReasonSelection';
import { LoadingOutlined } from '@ant-design/icons';
import { Card, Col, Row, message } from 'antd';
import { useDispatch } from 'react-redux';
import { useNavigate, useParams } from 'react-router-dom';
import { ORDERS_URI } from 'routes/routes';
import { useAppSelector, useInjectReducer, useInjectSaga } from 'store/hooks';
import { OrderDetail } from 'types/Orders';
import { SelectStyled } from './styled';
import { isEnablePrintOrder, printHTML } from 'utils/common';
import { RequestStatus, useAsync } from 'hooks/useAsync';
import { createDeliveryOrderAsync } from 'apis/orders';
import { getOrderActivityLog } from 'apis/reports';
import { trackOrderConfirmed } from 'utils/mixpanel';
import { AppV2ModuleEnum, AppV2Permission } from 'constants/ability';
import { usePermission } from 'v2/app/layouts/permission-container/use-permission';
import { generatePrintOrderTemplate } from 'v2/app/helpers/order.helper';
import {
    reducer,
    saga,
    sagaActions,
    selectors,
    sliceName,
    reducerActions,
} from './slice';

const OrderDetailPage: React.FC = () => {
    useInjectReducer({ key: sliceName, reducer });
    useInjectSaga({ key: sliceName, saga });
    const navigate = useNavigate();
    const { t } = useLocales();
    const { hasPermission } = usePermission();
    const { orderId } = useParams();
    const dispatch = useDispatch();
    const order = useAppSelector(selectors.selectOrder) as OrderDetail;
    const loading = useAppSelector(selectors.selectLoading);
    const [selectedAction, setAction] = useState(null);
    const _printOrder = useAsync(async () => {
        try {
            const printOrderData = await generatePrintOrderTemplate(Object(order));
            printHTML(
                `InterOp_Order_Detail_#${
                    order.haravanOrderNumber || order.orderId
                }`,
                printOrderData
            );
        } catch (e) {}
    }, false);
    useEffect(() => {
        if (orderId) dispatch(sagaActions.fetchOrderDetail(orderId));
        return function cleanup() {
            dispatch(reducerActions.removeStore());
        };
    }, [orderId, dispatch]);
    const getActivityLogs = useCallback(async (haravanOrderNumber: string) => {
        try {
            if (!haravanOrderNumber) return [];
            const {
                data: { data },
            } = await getOrderActivityLog(haravanOrderNumber);
            return data;
        } catch (e) {}
    }, []);
    const { execute, value: logs } = useAsync(getActivityLogs, false, []);
    useEffect(() => {
        if (order) {
            execute(order.haravanOrderNumber);
        }
    }, [execute, order]);
    const handleCancel = () => {
        navigate(ORDERS_URI);
    };

    const handleAction = (action: any) => {
        setAction(action);
        if (!orderId) return;

        if (action === 'CANCEL') {
            const confirm = confirmModal({
                t,
                content: (
                    <CancelReasonSelection
                        onCancel={() => {
                            confirm.destroy();
                            setAction(null);
                        }}
                        onOk={(reason) => {
                            confirm.destroy();
                            createDeliveryOrderAsync({
                                id: orderId,
                                action: 'CANCEL',
                                reason,
                            })
                                .then(() => {
                                    dispatch(
                                        sagaActions.fetchOrderDetail(orderId)
                                    );
                                })
                                .catch((error) => {
                                    message.error(error.message);
                                })
                                .finally(() => {
                                    setAction(null);
                                });
                        }}
                    />
                ),
                isDisabledFooter: true,
            });
        } else {
            confirmModal({
                t,
                onCancel: () => {
                    setAction(null);
                },
                onOk: () => {
                    if (action === 'CONFIRM') {
                        trackOrderConfirmed(order);
                    }
                    createDeliveryOrderAsync({
                        id: orderId,
                        action,
                    })
                        .then(() => {
                            dispatch(sagaActions.fetchOrderDetail(orderId));
                        })
                        .catch((error) => {
                            message.error(error.message);
                        })
                        .finally(() => {
                            setAction(null);
                        });
                },
            });
        }
    };

    if (!order) return <LoadingOutlined />;
    const menuItems = [];
    const isAbleToEditOrder = hasPermission([
        {
            module: AppV2ModuleEnum.Order,
            permission: AppV2Permission.Update,
        },
    ]);

    if (isAbleToEditOrder) {
        if ((order.currentStatus || '').toUpperCase() === 'CREATED') {
            menuItems.push({
                key: '1',
                label: t('orders.actions.confirm'),
                value: 'CONFIRM',
            });
            menuItems.push({
                key: '2',
                label: t('orders.actions.cancel'),
                value: 'CANCEL',
            });
        } else if ((order.currentStatus || '').toUpperCase() === 'PLACED') {
            menuItems.push({
                key: '2',
                label: t('orders.actions.cancel'),
                value: 'CANCEL',
            });
        } else if ((order.currentStatus || '').toUpperCase() === 'PROCESSING') {
            menuItems.push({
                key: '2',
                label: t('orders.actions.cancel'),
                value: 'CANCEL',
            });
        } else if ((order.currentStatus || '').toUpperCase() === 'DELIVERY') {
            menuItems.push({
                key: '2',
                label: t('orders.actions.cancel'),
                value: 'CANCEL',
            });
        }
    }
    const hiddenAction =
        (order.currentStatus || '').toUpperCase() === 'COMPLETED' ||
        (order.currentStatus || '').toUpperCase() === 'CANCELED';

    return (
        <>
            <PageHeader
                title={t('orders.orderDetails')}
                breadcrumb={{
                    routes: [
                        { breadcrumbName: t('orders.Home'), path: '' },
                        { breadcrumbName: t('orders.title'), path: 'orders' },
                        {
                            breadcrumbName:
                                order.haravanOrderNumber || `${order.orderId}`,
                            path: `${ORDERS_URI}/${order.orderId}`,
                        },
                    ],
                }}
                extra={
                    <>
                        <Button
                            data-testid="button-cancel"
                            onClick={handleCancel}
                        >
                            {t('common.button.back')}
                        </Button>
                        {hasPermission([
                            {
                                module: AppV2ModuleEnum.Order,
                                permission: AppV2Permission.Print,
                            },
                        ]) && (
                            <Button
                                data-testid="button-print"
                                hidden={!isEnablePrintOrder}
                                loading={
                                    _printOrder.status === RequestStatus.Pending
                                }
                                onClick={_printOrder.execute}
                            >
                                {t('Print_Order')}
                            </Button>
                        )}
                        {!hiddenAction && !!menuItems.length && (
                            <SelectStyled
                                loading={loading}
                                value={selectedAction}
                                key={(order.currentStatus || '').toUpperCase()}
                                style={{ width: 150 }}
                                onChange={handleAction}
                                placeholder={t('common.button.actions')}
                                data-testid="select-mode"
                                placement="bottomRight"
                                options={menuItems}
                            />
                        )}
                    </>
                }
            />
            <Content>
                <Row gutter={32}>
                    <Col span={12}>
                        <Card>
                            <Overview order={order} />
                        </Card>
                    </Col>
                    <Col span={12}>
                        <Card>
                            <DeliveryAddress order={order} />
                        </Card>
                    </Col>
                </Row>
                <Card className={'mt-md'}>
                    <OrderItems order={order} />
                </Card>
                {hasPermission([
                    {
                        module: AppV2ModuleEnum.Order,
                        permission: AppV2Permission.Logs,
                    },
                ]) && (
                    <Card className={'mt-md'}>
                        <ActivityLogs logs={logs} />
                    </Card>
                )}
            </Content>
        </>
    );
};

export default OrderDetailPage;
