import React from 'react';
import { Container } from './styled';

interface IProps {
    children?: React.ReactNode;
    className?: string;
    maxHeight?: number | string;
    height?: number | string;
    reference?: React.RefObject<HTMLDivElement>;
    isAlwaysShowVerticalScrollbar?: boolean;
    isRelativePosition?: boolean;
    margin?: string | number;
    style?: React.CSSProperties;
}

const ScrollableArea = ({
    className,
    children,
    maxHeight,
    height,
    reference,
    isAlwaysShowVerticalScrollbar,
    isRelativePosition,
    margin,
    style,
}: IProps): JSX.Element => {
    return (
        <Container
            isAlwaysShowVerticalScrollbar={isAlwaysShowVerticalScrollbar}
            isRelativePosition={isRelativePosition}
            className={className}
            ref={reference}
            style={{
                ...Object(style),
                maxHeight:
                    typeof maxHeight === 'string'
                        ? maxHeight
                        : maxHeight
                        ? `${maxHeight}px`
                        : 'auto',
                height: typeof height === 'string' ? height : height ? `${height}px` : 'auto',
            }}
        >
            {children}
        </Container>
    );
};

export default ScrollableArea;
