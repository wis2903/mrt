import styled from 'styled-components';
import { defaultTheme } from 'styles/defaultTheme.styles';

export const OrdersStyled = styled.div`
  .justify-end {
    display: flex;
    justify-content: end;
    margin-bottom: ${defaultTheme.spacing.md};
  }
`;
