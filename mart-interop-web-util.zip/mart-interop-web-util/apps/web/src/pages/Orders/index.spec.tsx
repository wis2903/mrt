import userEvent from '@testing-library/user-event'
import { renderWithProvider, screen, waitFor } from 'test'
import Component from '.'
import * as slice from './slice'
import sinon from 'sinon'
import apiClient from 'apis/apiClient'
jest.mock('mixpanel-browser')

sinon.stub(apiClient, 'post').callsFake(
  () =>
    ({
      data: {}
    } as any)
)
sinon.stub(apiClient, 'get').callsFake(
  () =>
    ({
      data: {}
    } as any)
)

const mockOrders: any = [
  {
    orderId: 553,
    source: 'NinjaMart on Zalo',
    total: 360000,
    createdDate: '2022-08-16T04:40:50.561226Z',
    totalItemCount: 1,
    totalQuantity: 2,
    currentStatus: 'CREATED',
    warehouseId: 11,
    // doNumber: 'DO-NJM-554',
    // sentToTkelog: true,
    customerDetails: {
      customerId: 16,
      customerZaloId: '3e2faea2-a206-4582-ae58-e78dda411172',
      customerName: 'NGUYEN VAN Test',
      phoneNumber: '0123456789',
      email: 'B@B.com'
    },
    firstItemDetail: null,
    shippingAddressDetails: {
      shippingCountry: 'Vietnam',
      shippingProvince: 'Đà Nẵng',
      shippingDistrict: 'Quận Cẩm Lệ',
      shippingAddress: '101/12 Ấp 5',
      shippingWard: 'Phường Hòa Phát',
      shippingCountryId: '6',
      shippingProvinceId: '48',
      shippingDistrictId: '495',
      shippingWardId: '20305'
    }
  },
  {
    orderId: 554,
    source: 'NinjaMart on Zalo',
    total: 360000,
    createdDate: '2022-08-16T04:40:50.561226Z',
    totalItemCount: 1,
    totalQuantity: 2,
    currentStatus: 'PLACED',
    warehouseId: 11,
    // doNumber: 'DO-NJM-554',
    // sentToTkelog: true,
    customerDetails: {
      customerId: 16,
      customerZaloId: '3e2faea2-a206-4582-ae58-e78dda411172',
      customerName: 'NGUYEN VAN Test',
      phoneNumber: '0123456789',
      email: 'B@B.com'
    },
    firstItemDetail: null,
    shippingAddressDetails: {
      shippingCountry: 'Vietnam',
      shippingProvince: 'Đà Nẵng',
      shippingDistrict: '',
      shippingAddress: '101/12 Ấp 5',
      shippingWard: 'Phường Hòa Phát',
      shippingCountryId: '6',
      shippingProvinceId: '48',
      shippingDistrictId: '495',
      shippingWardId: '20305'
    }
  },
  {
    orderId: 555,
    source: 'NinjaMart on Zalo',
    total: 360000,
    createdDate: '2022-08-16T04:40:50.561226Z',
    totalItemCount: 1,
    totalQuantity: 2,
    currentStatus: 'PROCESSING',
    warehouseId: 11,
    // doNumber: 'DO-NJM-554',
    // sentToTkelog: true,
    customerDetails: {
      customerId: 16,
      customerZaloId: '3e2faea2-a206-4582-ae58-e78dda411172',
      customerName: 'NGUYEN VAN Test',
      phoneNumber: '0123456789',
      email: 'B@B.com'
    },
    firstItemDetail: null,
    shippingAddressDetails: {
      shippingCountry: 'Vietnam',
      shippingProvince: 'Đà Nẵng',
      shippingDistrict: '',
      shippingAddress: '101/12 Ấp 5',
      shippingWard: 'Phường Hòa Phát',
      shippingCountryId: '6',
      shippingProvinceId: '48',
      shippingDistrictId: '495',
      shippingWardId: '20305'
    }
  },
  {
    orderId: 556,
    source: 'NinjaMart on Zalo',
    total: 360000,
    createdDate: '2022-08-16T04:40:50.561226Z',
    totalItemCount: 1,
    totalQuantity: 2,
    currentStatus: 'DELIVERY',
    warehouseId: 11,
    // doNumber: 'DO-NJM-554',
    // sentToTkelog: true,
    customerDetails: {
      customerId: 16,
      customerZaloId: '3e2faea2-a206-4582-ae58-e78dda411172',
      customerName: 'NGUYEN VAN Test',
      phoneNumber: '0123456789',
      email: 'B@B.com'
    },
    firstItemDetail: null,
    shippingAddressDetails: {
      shippingCountry: 'Vietnam',
      shippingProvince: 'Đà Nẵng',
      shippingDistrict: '',
      shippingAddress: '101/12 Ấp 5',
      shippingWard: 'Phường Hòa Phát',
      shippingCountryId: '6',
      shippingProvinceId: '48',
      shippingDistrictId: '495',
      shippingWardId: '20305'
    }
  },
  {
    orderId: 557,
    source: 'NinjaMart on Zalo',
    total: 360000,
    createdDate: '2022-08-16T04:40:50.561226Z',
    totalItemCount: 1,
    totalQuantity: 2,
    currentStatus: 'COMPLETED',
    warehouseId: 11,
    // doNumber: 'DO-NJM-554',
    // sentToTkelog: true,
    customerDetails: {
      customerId: 16,
      customerZaloId: '3e2faea2-a206-4582-ae58-e78dda411172',
      customerName: 'NGUYEN VAN Test',
      phoneNumber: '0123456789',
      email: 'B@B.com'
    },
    firstItemDetail: null,
    shippingAddressDetails: {
      shippingCountry: 'Vietnam',
      shippingProvince: 'Đà Nẵng',
      shippingDistrict: '',
      shippingAddress: '101/12 Ấp 5',
      shippingWard: 'Phường Hòa Phát',
      shippingCountryId: '6',
      shippingProvinceId: '48',
      shippingDistrictId: '495',
      shippingWardId: '20305'
    }
  }
]

describe('Render component', () => {
  it('should render without crash', () => {
    const { container } = renderWithProvider(<Component />)

    expect(container).toBeTruthy()
  })
  it('should render with data', () => {
    jest.spyOn(slice.selectors, 'selectOrders').mockReturnValue(mockOrders)
    jest.spyOn(slice.selectors, 'selectTotal').mockReturnValue(100)
    const { container } = renderWithProvider(<Component />)

    expect(container).toBeTruthy()
  })
})
describe('Actions', () => {
  beforeEach(() => {
    jest.spyOn(slice.selectors, 'selectOrders').mockReturnValue(mockOrders)
    jest.spyOn(slice.selectors, 'selectTotal').mockReturnValue(100)
  })
  it('should change pageNumber', async () => {
    const user = userEvent.setup()
    jest.spyOn(slice.reducerActions, 'changePageNumber')
    const { container } = renderWithProvider(<Component />)
    await user.click(screen.getAllByTitle('2')[0])
    expect(container).toBeTruthy()
  })
  it('should handleCreateDeliveryOrder', async () => {
    const { container } = renderWithProvider(<Component />)
    screen.getAllByTestId('1')[0].click()
    await waitFor(() => screen.getByText('OK'))
    await userEvent.click(screen.getByText('OK').parentElement as any)
    expect(container).toBeTruthy()
  })
  it('should handleCancel', async () => {
    const { container } = renderWithProvider(<Component />)
    screen.getAllByTestId('2')[0].click()
    expect(container).toBeTruthy()
  })
})
