import React from 'react';
import { useReference } from 'v2.1/hooks/useReference.hook';
import {
    ControllerProviderField,
    ControllerProviderFieldType,
    ControllerProviderFieldValidationEnum,
    IControllerProviderContext,
    IControllerProviderFieldValidation,
    IControllerProviderProperties,
} from './type';

export const ControllerProviderContext = React.createContext<IControllerProviderContext>({
    fields: {},
    field: () => undefined,
    value: () => undefined,
    meta: () => undefined,
    error: () => undefined,
    values: () => ({}),
    setValue: () => undefined,
    setMeta: () => undefined,
    validate: () => undefined,
    clearError: () => undefined,
});

export const ControllerProvider = ({
    children,
    schema,
}: IControllerProviderProperties): JSX.Element => {
    const [fields, setFields] = React.useState<{ [key: string]: ControllerProviderField }>(
        schema || {}
    );
    const fieldsRef = useReference(fields);

    const handleSpecificValidation = (
        fieldName: string,
        validation: IControllerProviderFieldValidation
    ): void => {
        const field = fieldsRef.current[fieldName];
        if (!field) return;

        switch (validation.type) {
            case ControllerProviderFieldValidationEnum.required:
                if (String(field.value) === '0') break;
                if (!field.value) {
                    setFields((current) => {
                        const _current = { ...current };
                        const field = _current[fieldName];
                        if (field) {
                            field.error = validation.message;
                        }
                        return _current;
                    });
                }
                break;
            default:
                break;
        }
    };

    return (
        <ControllerProviderContext.Provider
            value={{
                fields,
                field: (fieldName: string): ControllerProviderField | undefined => {
                    const fld = fieldsRef.current[fieldName];
                    if (!fld) return undefined;
                    return fld;
                },
                value: (fieldName: string): ControllerProviderFieldType => {
                    const field = fieldsRef.current[fieldName];
                    if (!field) return undefined;
                    return field.value;
                },
                meta: (fieldName: string): unknown => {
                    const field = fieldsRef.current[fieldName];
                    if (!field) return undefined;
                    return field.meta;
                },
                error: (fieldName: string): string | undefined => {
                    const field = fieldsRef.current[fieldName];
                    if (!field) return undefined;
                    return field.error;
                },
                values: (): Record<string, ControllerProviderFieldType> => {
                    const result: Record<string, ControllerProviderFieldType> = {};
                    Object.keys(fieldsRef.current).forEach((fieldName) => {
                        result[fieldName] = fieldsRef.current[fieldName].value;
                    });
                    return result;
                },
                setValue: (fieldName: string, value: ControllerProviderFieldType): void => {
                    setFields((current) => {
                        const _current = { ...current };
                        const field = _current[fieldName];
                        if (field) {
                            field.value = value;
                        }
                        return _current;
                    });
                },
                setMeta: (fieldName: string, meta: unknown): void => {
                    setFields((current) => {
                        const _current = { ...current };
                        const field = _current[fieldName];
                        if (field) {
                            field.meta = meta;
                        }
                        return _current;
                    });
                },
                validate: (fieldName: string): void => {
                    const field = fieldsRef.current[fieldName];
                    if (!field || !field.validations?.length) return;
                    field.validations.forEach((validation) => {
                        handleSpecificValidation(fieldName, validation);
                    });
                },
                clearError: (fieldName: string): void => {
                    setFields((current) => {
                        const _current = { ...current };
                        const field = _current[fieldName];
                        if (field) {
                            field.error = undefined;
                        }
                        return _current;
                    });
                },
            }}
        >
            {children}
        </ControllerProviderContext.Provider>
    );
};
