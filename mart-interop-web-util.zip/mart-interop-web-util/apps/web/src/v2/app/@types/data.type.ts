import {
    AmastUomEnum,
    NotificationCampaignStatusEnum,
    ProductStatusEnum,
    PromotionStatusEnum,
    PromotionTypeEnum,
    PromotionValidationEnum,
    UomStatusEnum,
} from './enum.type';

export interface ICountry {
    id: number;
    code: string;
    name: string;
}

export interface IProvince {
    id: number;
    name: string;
    region: string;
    warehouseId?: number;
    countryId: number;
}

export interface ICategory {
    id: number | string;
    newServiceId?: string;
    code: string;
    amastId: string;
    name: string;
    nameVi: string;
    parentId?: number | string;
    parentNewServiceId?: string;
    parentName?: string;
    parentNameVi?: string;
}

export interface IBrand {
    id: number | string;
    newServiceId?: string;
    code: string;
    name: string;
    countryId: number;
    amastId?: number | string;
}

export interface IMasterData {
    raw?: Record<string, unknown>,
    fetched?: boolean;
    provinces: IProvince[];
    categories: ICategory[];
    countries: ICountry[];
    warehouses: IWarehouse[];
    brands: IBrand[];
    hasError?: boolean;
}

export interface IPromotion {
    id: string;
    name: string;
    status: PromotionStatusEnum;
    type: PromotionTypeEnum;
    startDate: Date;
    endDate: Date;
    provinceId: number;
    countryId: number;
    criteria?: Record<string, unknown>;
    applyLimit?: number;
    appliedTimes?: number;
    meta?: string;
    version: number;
    versionId: string;
    updatedBy?: string;
    updatedAt?: Date;
}

export interface IPromotionServerValidation {
    type: PromotionValidationEnum;
    conflictPromotionName?: string;
    conflictPromotionId?: string;
}

export interface ISku {
    key?: string;
    id: number;
    newServiceId?: string;
    name: string;
    description?: string;
    code: string;
    amastCode?: string;
    countryId: number;
    categoryName: string;
    categoryId: number;
    categoryNewServiceId?: string;
    brandId: number;
    brandNewServiceId?: string;
    brandName: string;
    subcategoryId?: number;
    subcategoryNewServiceId?: string;
    subcategoryName?: string;
    uom: IUom[];
    previewImageUrl?: string;
    inventory?: IInventory;
    isFetchingDetails?: boolean;
    isFetchingInventory?: boolean;
    barcode?: string;
    noOfUOMs: number;
    tax: number;
    usageDays?: number;
    status?: ProductStatusEnum;
    createdAt?: Date;
}

export interface IUomPrice {
    id: number;
    newServiceId?: string;
    provinceId: number;
    warehouseNewServiceId: string;
    provinceName: string;
    grossPrice: number;
}

export interface IUom {
    id: number;
    newServiceId?: string;
    name: string;
    isPrimary: boolean;
    price: IUomPrice[];
    quantity: number;
    imageUrl?: string;
    additionalImageUrl?: string;
    barcode?: string;
    amastSellable?: boolean;
    cxSellable?: boolean;
    netWeight?: number;
    volume?: number;
    grossWeight?: number;
    amastCode?: AmastUomEnum;
    status?: UomStatusEnum;
    meta?: Record<string, unknown>;
}

export interface IWarehouse {
    id: number;
    newServiceId?: string;
    provinceId?: number;
    code: string;
    name: string;
    amastCode: string;
    tkeCode: string;
}

export interface IInventory {
    onhand: number;
    onhold: number;
    available: number;
}

export interface IInventoryAdvance {
    id: number;
    onhand: number;
    onhold: number;
    available: number;
    productId: number;
    productCode: string;
    productName: string;
    baseUOMName: string;
    warehouseId: number;
    warehouseName: String;
    product?: ISku;
}

export interface IReconcilication {
    id: number;
    system: number;
    from: number;
    to: number;
    status: string;
    message: string;
}

export interface INotificationCampaign {
    id: string;
    title: string;
    message: string;
    url: string;
    imageUrl: string;
    name: string;
    deliveredTime: Date;
    status: NotificationCampaignStatusEnum;
    createdBy: string;
    createdAt: Date;
}

export interface IDistrict {
    id: number | string;
    name: string;
    provinceId: number;
}
