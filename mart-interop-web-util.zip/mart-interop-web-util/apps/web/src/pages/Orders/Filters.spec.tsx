import userEvent from '@testing-library/user-event';
import apiClient from 'apis/apiClient';
import sinon from 'sinon';
import * as masterDataSlice from 'store/masterData/slice';
import { renderWithProvider, screen } from 'test';
import Component from '.';
import * as slice from './slice';

jest.mock('lodash', () => ({
  ...jest.requireActual('lodash'),
  debounce: (cb: any) => cb
}));

sinon.stub(apiClient, 'post').callsFake(
  () =>
    ({
      data: {}
    } as any)
);
sinon.stub(apiClient, 'get').callsFake(
  () =>
    ({
      data: {}
    } as any)
);

describe('Render component', () => {
  it('should render without crash', () => {
    const { container } = renderWithProvider(<Component />);

    expect(container).toBeTruthy();
  });
  it('should render with masterData', () => {
    jest.spyOn(masterDataSlice.selectors, 'selectorByKey').mockReturnValue(() => [
      {
        id: 1,
        code: 'test',
        name: 'test',
        parentId: 2,
        parentName: '1'
      }
    ]);
    jest.spyOn(masterDataSlice.selectors, 'selectDistrict').mockReturnValue([
      {
        id: 1,
        code: 'test',
        name: 'test',
        parentId: 2,
        parentName: '1'
      }
    ]);

    const { container } = renderWithProvider(<Component />);

    expect(container).toBeTruthy();
  });
});
describe('Actions', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });
  it('should fetch districts', async () => {
    const spyChangeSearch = jest.spyOn(slice.reducerActions, 'changeSearch');

    const user = userEvent.setup();
    const spyFetchDistricts = jest.spyOn(masterDataSlice.sagaActions, 'fetchDistricts');

    renderWithProvider(<Component />);
    await user.type(screen.getAllByTestId('select-onChange')[0], 'A');

    expect(spyFetchDistricts).toBeCalledTimes(1);

    // change search 3 times, 1 time at page load, mock select called 2 times
    expect(spyChangeSearch).toBeCalledTimes(0);
  });
  it('should run form onChange when change search textbox', async () => {
    const spyChangeSearch = jest.spyOn(slice.reducerActions, 'changeSearch');

    const user = userEvent.setup();

    renderWithProvider(<Component />);
    await user.type(screen.getAllByPlaceholderText(/Search/)[0], 'A');

    expect(spyChangeSearch).toBeCalledTimes(0);
  });
  it('should run changeSearch in every form control', async () => {
    const spyChangeSearch = jest.spyOn(slice.reducerActions, 'changeSearch');

    const user = userEvent.setup();

    renderWithProvider(<Component />);
    // Search textbox
    await user.type(screen.getAllByPlaceholderText(/Search/)[0], 'A');
    // Province
    await user.type(screen.getAllByTestId('select-onChange')[0], 'A');
    // District
    await user.type(screen.getAllByTestId('select-onChange')[1], 'A');
    // Total From
    await user.type(screen.getAllByPlaceholderText(/From/)[0], '1');
    // Total To
    await user.type(screen.getAllByPlaceholderText(/To/)[0], '1');
    // Status
    await user.type(screen.getAllByTestId('select-onChange')[2], 'A');
    // Created From
    await user.type(screen.getAllByTestId('rangePicker-onChange')[0], 'A');
    // Created To
    await user.type(screen.getAllByTestId('rangePicker-onChange')[0], 'A');

    expect(spyChangeSearch).toBeCalledTimes(0);
  });
  it('should run reset', async () => {
    const spyChangeSearch = jest.spyOn(slice.reducerActions, 'changeSearch');
    const user = userEvent.setup();

    renderWithProvider(<Component />);
    // Search textbox
    await user.type(screen.getAllByPlaceholderText(/Search/)[0], 'A');
    await user.click(screen.getAllByText(/Reset/)[0]);

    expect(spyChangeSearch).toBeCalledTimes(0);
  });
});
