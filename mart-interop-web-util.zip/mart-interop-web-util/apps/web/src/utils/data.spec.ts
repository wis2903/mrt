import { toSnakeCase, toCamelCase } from './data'

describe('data utils', () => {
  it('should return correct value', () => {
    const arr = [{ test_id: 1, createdAt: '2022-08-22T09:43:45.180164Z' }]
    expect(toSnakeCase(arr)).toEqual([{ test_id: 1, created_at: '2022-08-22T09:43:45.180164Z' }])
    expect(toCamelCase(arr)).toEqual([{ testId: 1, createdAt: '2022-08-22T09:43:45.180164Z' }])

    const obj = { test_id: 1, createdAt: '2022-08-22T09:43:45.180164Z' }
    expect(toSnakeCase(obj)).toEqual({ test_id: 1, created_at: '2022-08-22T09:43:45.180164Z' })
    expect(toCamelCase(obj)).toEqual({ testId: 1, createdAt: '2022-08-22T09:43:45.180164Z' })
  })
})
