import Select from 'components/Select';
import Button from 'components/Button';
import InputNumber from 'components/InputNumber';
import useLocales from 'hooks/useLocales';
import moment from 'moment';
import { SearchOutlined } from '@ant-design/icons';
import { Col, DatePicker, Divider, Form, Input, Row } from 'antd';
import { ORDER_STATUS_MASTER_DATA } from 'constants/orders';
import { debounce } from 'lodash';
import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useInjectReducer, useInjectSaga } from 'redux-injectors';
import { useAppDispatch, useAppSelector } from 'store/hooks';
import { OrderSearchForm } from 'types/Orders';
import { reducer, saga, sliceName } from './slice';
import { Moment } from 'moment';
import { RangeValue } from 'types/OrderActivityLogs';
import { sagaActions, selectors as masterDataSelectors } from 'store/masterData/slice';
import {
    DAY_MONTH_YEAR_FORMAT,
    DELAY_INPUT_TIME,
    MAX_LENGTH_INPUT,
    DEFAULT_PAGE_SIZE,
    DEFAULT_PAGE_NUMBER,
} from 'constants/common';
import { OrderTypeEnum } from 'v2/app/@types/enum.type';

const { RangePicker } = DatePicker;
const { Option } = Select;

const Filters = () => {
    useInjectReducer({ key: sliceName, reducer });
    useInjectSaga({ key: sliceName, saga });

    const [searchParams, setSearchParams] = useSearchParams();
    const [createdAt, setCreatedAt] = useState<any>([moment().subtract(1, 'week'), moment()]);

    const { t } = useLocales();

    const dispatch = useAppDispatch();

    const [form] = Form.useForm<OrderSearchForm>();

    const disabledDate = (current: Moment) => {
        const isFutureDate = current.diff(new Date()) > 0;
        return isFutureDate;
    };

    const provinceList = useAppSelector(masterDataSelectors.selectorByKey('provinceList'));
    const warehouseList = useAppSelector(masterDataSelectors.selectorByKey('warehouseList'));
    const orderStatusList = ORDER_STATUS_MASTER_DATA;
    const loading = useAppSelector(masterDataSelectors.selectLoading);
    const districts = useAppSelector(masterDataSelectors.selectDistrict);
    const _setSearchParamsFromForm = () => {
        const values = form.getFieldsValue();
        const _values: any = {
            pi: values.provinceId,
            di: values.districtId,
            tf: values.totalFrom,
            tt: values.totalTo,
            s: values.search,
            w: values.warehouseId,
            cdf: values.createdDate?.[0]?.unix?.() || -1,
            cdt: values.createdDate?.[1]?.unix?.() || -1,
            ps: DEFAULT_PAGE_SIZE,
            pn: DEFAULT_PAGE_NUMBER,
            si: values.statusId?.length ? values.statusId : undefined,
            tp: values.type,
        };
        Object.keys(_values).forEach((key) => {
            return !_values[key] ? searchParams.delete(key) : searchParams.set(key, _values[key]);
        });
        setSearchParams(searchParams);
        setCreatedAt(values.createdDate);
    };
    const handleChange = debounce(
        () => {
            _setSearchParamsFromForm();
        },
        DELAY_INPUT_TIME,
        { trailing: true }
    );

    const handleChangeProvince = () => {
        form.setFieldsValue({ districtId: undefined });
        _setSearchParamsFromForm();
    };
    const onReset = () => {
        form.resetFields();
        setSearchParams({
            pn: DEFAULT_PAGE_NUMBER.toString(),
            ps: DEFAULT_PAGE_SIZE.toString(),
            cdf: moment().subtract(1, 'week').unix().toString(),
            cdt: moment().unix().toString(),
        });
    };

    useEffect(() => {
        const createdDateFrom: Moment | null = searchParams.get('cdf')
            ? searchParams.get('cdf') !== '-1'
                ? moment.unix(parseInt(searchParams.get('cdf') as string))
                : null
            : moment().subtract(1, 'week');
        const createdDateTo: Moment | null = searchParams.get('cdt')
            ? searchParams.get('cdt') !== '-1'
                ? moment.unix(parseInt(searchParams.get('cdt') as string))
                : null
            : moment();
        const createdDate: RangeValue = [createdDateFrom, createdDateTo];
        form.setFieldsValue({
            createdDate: createdDate,
            provinceId: searchParams.get('pi') || undefined,
            districtId: searchParams.get('di') || undefined,
            statusId: (searchParams.get('si')?.split(',') as any) || [],
            totalFrom: searchParams.get('tf') as any,
            totalTo: searchParams.get('tt') as any,
            search: searchParams.get('s') as any,
            warehouseId: searchParams.get('w') as any,
            type: searchParams.get('tp') as OrderTypeEnum,
        });
        if (searchParams.get('pi')) {
            dispatch(
                sagaActions.fetchDistricts({
                    province: searchParams.get('pi') as any,
                })
            );
        }
        setCreatedAt(createdDate);
    }, [searchParams]);

    return (
        <>
            <Form
                form={form}
                layout="vertical"
                labelWrap
                labelAlign="left"
                onChange={handleChange}
                initialValues={{
                    createdDate: [moment().subtract(1, 'week'), moment()],
                }}
            >
                <Row gutter={24}>
                    <Col>
                        <Form.Item name="warehouseId" label={t('Warehouse')}>
                            <Select
                                allowClear
                                loading={loading}
                                onChange={handleChange}
                                placeholder={t('common.button.select')}
                                style={{ width: 240 }}
                                showSearch
                                optionFilterProp="children"
                                filterOption={(input, option) =>
                                    (option?.children as unknown as string)
                                        ?.toLowerCase()
                                        ?.includes(input?.toLowerCase())
                                }
                            >
                                {warehouseList?.map((x) => (
                                    <Option key={x.id} value={String(x.id)}>
                                        {x.name}
                                    </Option>
                                ))}
                            </Select>
                        </Form.Item>
                    </Col>

                    <Col>
                        <Form.Item name="provinceId" label={t('orders.province')}>
                            <Select
                                loading={loading}
                                onChange={handleChangeProvince}
                                allowClear
                                placeholder={t('common.button.select')}
                                style={{ width: 180 }}
                                showSearch
                                optionFilterProp="children"
                                filterOption={(input, option) =>
                                    (option?.children as unknown as string)
                                        ?.toLowerCase()
                                        ?.includes(input?.toLowerCase())
                                }
                            >
                                {provinceList?.map((x) => (
                                    <Option key={x.id} value={x.id}>
                                        {x.name}
                                    </Option>
                                ))}
                            </Select>
                        </Form.Item>
                    </Col>
                    <Col>
                        <Form.Item name="districtId" label={t('orders.district')}>
                            <Select
                                allowClear
                                loading={loading}
                                disabled={!form.getFieldValue('provinceId')}
                                onChange={handleChange}
                                placeholder={t('common.button.select')}
                                style={{ width: 180 }}
                                showSearch
                                optionFilterProp="children"
                                filterOption={(input, option) =>
                                    (option?.children as unknown as string)
                                        ?.toLowerCase()
                                        ?.includes(input?.toLowerCase())
                                }
                            >
                                {districts?.map((x) => (
                                    <Option key={x.id} value={x.id}>
                                        {x.name}
                                    </Option>
                                ))}
                            </Select>
                        </Form.Item>
                    </Col>

                    <Col>
                        <Form.Item
                            label={t('orders.grandTotal')}
                            className="mb-0 site-input-group-wrapper"
                        >
                            <Input.Group compact>
                                <Form.Item name="totalFrom">
                                    <InputNumber
                                        style={{ width: '180px' }}
                                        className="site-input-left"
                                        placeholder={t('common.input.from')}
                                    />
                                </Form.Item>
                                <Input
                                    className="site-input-split"
                                    style={{
                                        width: 30,
                                        borderLeft: 0,
                                        borderRight: 0,
                                        pointerEvents: 'none',
                                    }}
                                    placeholder="~"
                                    disabled
                                />
                                <Form.Item name="totalTo">
                                    <InputNumber
                                        style={{ width: '180px' }}
                                        className="site-input-right"
                                        placeholder={t('common.input.to')}
                                    />
                                </Form.Item>
                            </Input.Group>
                        </Form.Item>
                    </Col>
                </Row>
                <Row gutter={24}>
                    <Col>
                        <Form.Item name="statusId" label={t('orders.status')}>
                            <Select
                                allowClear
                                mode="multiple"
                                onChange={handleChange}
                                placeholder={t('common.button.select')}
                                style={{ width: 240 }}
                                showSearch
                                optionFilterProp="children"
                                filterOption={(input, option) =>
                                    (option?.children as unknown as string)
                                        ?.toLowerCase()
                                        ?.includes(input?.toLowerCase())
                                }
                            >
                                {orderStatusList?.map((x) => (
                                    <Option key={x.code} value={x.code}>
                                        {t(x.name)}
                                    </Option>
                                ))}
                            </Select>
                        </Form.Item>
                    </Col>

                    {/* <Col>
                        <Form.Item name="type" label={t('Type')}>
                            <Select
                                allowClear
                                onChange={handleChange}
                                placeholder={t('common.button.select')}
                                style={{ width: 180 }}
                                showSearch
                                optionFilterProp="children"
                                filterOption={(input, option) =>
                                    (option?.children as unknown as string)
                                        ?.toLowerCase()
                                        ?.includes(input?.toLowerCase())
                                }
                            >
                                <Option value={OrderTypeEnum.presale}>Pre-sale</Option>
                                <Option value={OrderTypeEnum.promptsale}>Prompt-sale</Option>
                            </Select>
                        </Form.Item>
                    </Col> */}

                    <Col flex="auto">
                        <div className="justify-content-between">
                            <Form.Item label={t('orders.createdAt')} name="createdDate">
                                <RangePicker
                                    allowClear
                                    allowEmpty={[true, true]}
                                    placeholder={[t('common.input.from'), t('common.input.to')]}
                                    onChange={handleChange}
                                    format={DAY_MONTH_YEAR_FORMAT}
                                    disabledDate={disabledDate}
                                />
                            </Form.Item>
                            <Button htmlType="button" onClick={onReset} className="mt-30 ml-md">
                                {t('common.button.reset')}
                            </Button>
                        </div>
                    </Col>
                </Row>
                <Divider dashed className="mt-0" />
                <Row justify="end">
                    <Form.Item name="search">
                        <Input
                            suffix={<SearchOutlined />}
                            placeholder={t('common.message.search')}
                            style={{ width: 200 }}
                            allowClear
                            onChange={handleChange}
                            maxLength={MAX_LENGTH_INPUT}
                        />
                    </Form.Item>
                </Row>
            </Form>
        </>
    );
};
export default Filters;
