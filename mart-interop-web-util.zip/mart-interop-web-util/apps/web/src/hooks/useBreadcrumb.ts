import { BreadcrumbProps } from 'antd'
import { useState } from 'react'
import { useBetween } from 'use-between'

const useBreadcrumb = () => {
  const [breadcrumb, setBreadcrumb] = useState<BreadcrumbProps | undefined>(undefined)
  return {
    breadcrumb,
    setBreadcrumb
  }
}
export const useSharedBreadcrumb = () => useBetween(useBreadcrumb)
