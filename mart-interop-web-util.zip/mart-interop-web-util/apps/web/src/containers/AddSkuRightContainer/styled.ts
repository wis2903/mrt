import { Card } from 'antd';
import styled from 'styled-components';

export const SkuConfigurationStyled = styled(Card)`
  position: relative;
  .delete {
    position: absolute;
    bottom: 24px;
    right: 24px;
  }
  margin-bottom: 16px;
`;
