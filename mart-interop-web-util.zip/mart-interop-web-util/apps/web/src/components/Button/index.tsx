import { ButtonProps } from 'antd'
import { StyledButton } from './styled'

const Button = (props: ButtonProps) => {
  return <StyledButton {...props} />
}

export default Button
