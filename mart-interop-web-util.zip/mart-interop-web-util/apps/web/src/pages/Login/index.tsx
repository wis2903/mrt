import useLocales from 'hooks/useLocales';
import Button from 'v2/kit/components/basic/button/button';

import { LOCAL_STORAGE_KEY } from 'constants/common';
import { useAuth } from 'hooks/useAuth';
import { useLocation } from 'react-router';
import { LoginStyled } from './styled';

export interface LocationTypeLogin {
    state: {
        from: {
            pathname: string;
        };
    };
}

export default function LoginPage() {
    const auth = useAuth();
    const { t } = useLocales();
    const { state } = useLocation();
    function handleSubmit() {
        const previousPathname = Object(state?.from).pathname || '/';
        const previousSearchParams = Object(state?.from).search || '';

        localStorage.setItem(
            LOCAL_STORAGE_KEY.LAST_ACCESS_URL,
            `${previousPathname}${previousSearchParams}`
        );

        auth.signin({
            idpHint: 'google',
            redirectUri: `${window.location.origin}`,
        });
    }

    return (
        <LoginStyled>
            <Button data-testid="submit" isPrimary onClick={handleSubmit}>
                <img className="google-logo" src="assets/google-logo.png" />
                {t('common.Sign in with Google')}
            </Button>
        </LoginStyled>
    );
}
