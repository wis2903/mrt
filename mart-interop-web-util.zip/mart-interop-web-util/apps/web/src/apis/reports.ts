import apiClient from './apiClient';
import { REPORT } from './apiUrl';
import { InventoryActivityLogsFilter } from '../types/InventoryActivityLogs';
import dayjs from 'dayjs';
import { TIME_FORMAT } from 'constants/common';

export const getOrderActivityLogs = (params: any) => {
  return apiClient.post(`${REPORT}/order-activity-logs/search`, params);
};

export const getOrderActivityLog = (haravanOrderNumber: string) => {
  return apiClient.get(`${REPORT}/order-activity-logs?haravanOrderNumber=${haravanOrderNumber}`);
};

export const getInventoryActivityLogs = (params: InventoryActivityLogsFilter) => {
  const _params = { ...params };
  if (params.createdDateFrom) {
    _params.createdDateFrom = dayjs(params.createdDateFrom).startOf('date').format(TIME_FORMAT);
  }
  if (params.createdDateTo) {
    _params.createdDateTo = dayjs(params.createdDateTo).endOf('date').format(TIME_FORMAT);
  }
  return apiClient.post(`${REPORT}/inventory-activity-logs/search`, _params);
};
