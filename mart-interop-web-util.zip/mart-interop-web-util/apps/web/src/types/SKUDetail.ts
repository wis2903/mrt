export interface SellingPrice {
    provinceId: string | number;
    tax: number;
    grossPrice: number;
    netPrice: number;
    discountPrice: number;
    id: number;
    isActive: boolean;
    note: string;
    lastModifiedBy: string;
    lastModifiedDate: string;
    newPrice: number;
}

export interface SellingPriceTable {
    isNew?: boolean;
    province?: {
        value?: string;
        label?: string;
        region?: string;
    };
    provinceId?: string;
    provinceName?: string;
    tax?: number;
    grossPrice: number;
    netPrice?: number;
    discountPrice?: number;
    id: number;
    isActive: boolean;
    note: string;
    lastModifiedBy: string;
    lastModifiedDate: string;
    newPrice: number;
    region?: string;
}

export interface SKUConfiguration {
    id: number;
    name: string;
    generatedName: string;
    quantity: number;
    barcode?: number;
    grossWeight?: number;
    netWeight?: number;
    volume?: number;
    isPrimary: boolean;
    imageUrls: string[];
    sellingPrices: SellingPrice[];
}

export default interface SkuDetail {
    id: number;
    code: string;
    name: string;
    description: string;
    countryId: number;
    tax: number;
    categoryId: number;
    categoryName?: string;
    subcategoryId: number;
    subcategoryName?: string;
    brandId: number;
    brandName?: string;
    usageDays?: number;
    configurations: SKUConfiguration[];
    numberUom?: number;
    minGrossPrice?: number;
    maxGrossPrice?: number;
    category?: string;
    brand?: string;
    sourceMappingList?: SkuSource[];
}

export interface SkuSource {
    id: number;
    isDisplay: boolean;
    skuId: number;
    sourceId: number;
}

export interface SkuListSearchForm {
    category?: number | string;
    categoryId?: number | string;
    subCategoryId?: number | string;
    brandId?: number | string;
    totalFrom?: number;
    totalTo?: number;
    search?: string;
    provinceId?: number;
    countryId?: number;
    hasPrice?: boolean | null;
}

export interface GetSkuListParams {
    pageNumber: number;
    pageSize: number;
    search?: SkuListSearchForm;
    sortName?: number;
    sortCategory?: number;
    sortBrand?: number;
    t: (key: string) => string;
}

export interface GetSkuListApi {
    page: number;
    size: number;
    textSearch?: string;
    categoryId?: number | string;
    subcategoryId?: number | string;
    brandId?: number | string;
    minGrossPrice?: number;
    maxGrossPrice?: number;
    provinceId?: number;
    countryId?: number;
    hasPrice?: boolean | null;
    sortName?: number;
    sortCategory?: number;
    sortBrand?: number;
}

export interface UpdatePriceConfigApi {
    id?: number;
    provinceId?: string;
    grossPrice?: number;
    discountPrice?: number;
    note: string;
    isActive: boolean;
}
