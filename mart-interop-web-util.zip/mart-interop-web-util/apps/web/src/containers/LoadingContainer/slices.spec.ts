import { reducer as loadingReducer, loadingActions, initialState, loadingSelectors, loadingSliceName } from './slices';

describe('reducerActions', () => {
  it('loadingActions', () => {
    expect(loadingReducer(initialState, loadingActions.showLoading())).toEqual({
      isLoading: true
    });
  });
  it('fetchWardsSuccess', () => {
    expect(loadingReducer(initialState, loadingActions.stopLoading())).toEqual({
      isLoading: false
    });
  });
});
describe('selectors', () => {
  const state = {
    [loadingSliceName]: {
      isLoading: true
    }
  };
  it('selectDistricts', () => {
    expect(loadingSelectors.selectIsLoading(state)).toEqual(true);
  });
});
