import userEvent from '@testing-library/user-event';
import { Form } from 'antd';
import { useForm } from 'antd/lib/form/Form';
import { AddSkuForm } from 'pages/AddSkuPage/types';
import React from 'react';
import { renderWithProvider, screen, waitFor } from 'test';
import Component from '.';
import { SKUConfigurationForm } from '../../pages/AddSkuPage/types';

jest.mock('utils/common', () => ({ validateSKUConfig: jest.fn().mockReturnValue(true) }));
describe('Render component', () => {
  it('should render without crash', async () => {
    const Wrapper = () => {
      const [form] = useForm<AddSkuForm>();
      const configs: SKUConfigurationForm[] = [{ id: 1, name: 'test', generatedName: 'test', quantity: 1, isPrimary: true, image: 'test' }];
      return (
        <Form form={form}>
          <Component
            submitted={false}
            readOnly
            parentForm={form}
            configurations={configs}
            onSetConfigurations={jest.fn()}
            onChange={jest.fn()}
          />
        </Form>
      );
    };
    const { container } = renderWithProvider(<Wrapper />);
    expect(container).toBeTruthy();
  });
  it('should render without crash', async () => {
    const Wrapper = () => {
      jest.spyOn(React, 'useState').mockReturnValue([0, jest.fn()]);
      const [form] = useForm<AddSkuForm>();
      const configs: SKUConfigurationForm[] = [
        { id: 1, name: 'test', generatedName: 'test', quantity: 1, isPrimary: true, image: 'test' },
        { id: 2, name: 'test', generatedName: 'test', quantity: 2, isPrimary: false, image: 'test' }
      ];
      return (
        <Form form={form}>
          <Component submitted parentForm={form} configurations={configs} onSetConfigurations={jest.fn()} onChange={jest.fn()} />
        </Form>
      );
    };
    const { container } = renderWithProvider(<Wrapper />);
    await userEvent.click(
      screen.getByRole('button', {
        name: /cancel/i
      })
    );
    await userEvent.click(screen.getAllByTestId('1')[0]);
    await userEvent.click(screen.getAllByTestId('1')[1]);
    await userEvent.click(screen.getAllByTestId('2')[0]);
    await waitFor(() =>
      screen.getByRole('button', {
        name: /ok/i
      })
    );
    await userEvent.click(
      screen.getByRole('button', {
        name: /ok/i
      })
    );
    expect(container).toBeTruthy();
  });
});
