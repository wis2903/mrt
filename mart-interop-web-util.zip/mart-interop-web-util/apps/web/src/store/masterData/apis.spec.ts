import apiClient from 'apis/apiClient';
import { getDistrict, getMasterData } from './apis';
afterEach(() => {
  jest.clearAllMocks();
  jest.restoreAllMocks();
});
describe('getMasterData', () => {
  it('Should return data', async () => {
    const putSpy = jest.spyOn(apiClient, 'get');
    putSpy.mockReturnValueOnce(Promise.resolve({}));
    const result = await getMasterData();
    expect(result).toEqual({});
  });
  it('Should throw exception', async () => {
    const putSpy = jest.spyOn(apiClient, 'get');
    putSpy.mockRejectedValueOnce({});
    expect(getMasterData).rejects.toEqual({});
  });
});
describe('getDistrict', () => {
  it('Should return data', async () => {
    const putSpy = jest.spyOn(apiClient, 'get');
    putSpy.mockReturnValueOnce(Promise.resolve({}));
    const result = await getDistrict({ province: 'test' });
    expect(result).toEqual({});
  });
  it('Should throw exception', async () => {
    const putSpy = jest.spyOn(apiClient, 'get');
    putSpy.mockRejectedValueOnce({});
    expect(() => getDistrict({ province: 'test' })).rejects.toEqual({});
  });
});
