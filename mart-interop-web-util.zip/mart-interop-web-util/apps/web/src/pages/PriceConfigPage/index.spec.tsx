import userEvent from '@testing-library/user-event';
import { loadingSelectors } from 'containers/LoadingContainer/slices';
import { fireEvent, renderWithProvider, screen, waitFor } from 'test';
import Component from '.';
import { fakeProduct } from './mockData';
import { selectors } from './slice';
import { selectors as masterDataSelectors } from 'store/masterData/slice';

jest.unmock('antd');

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useParams: () => {
    return {
      skuId: '1'
    };
  }
}));

describe('Render component', () => {
  it('should render without crash', () => {
    const { container } = renderWithProvider(<Component />);

    expect(container).toBeTruthy();
  });
});

describe('actions', () => {
  afterEach(() => {
    jest.clearAllMocks();
    jest.restoreAllMocks();
  });

  beforeEach(() => {
    jest.spyOn(selectors, 'skuDetailSelector').mockReturnValue(fakeProduct);
    jest.spyOn(loadingSelectors, 'selectIsLoading').mockReturnValue(false);
    jest.spyOn(masterDataSelectors, 'selectLoading').mockReturnValue(false);
  });

  it('should render without crash', () => {
    jest.spyOn(selectors, 'skuDetailSelector').mockReturnValueOnce(undefined);
    const { container } = renderWithProvider(<Component />);

    expect(container).toBeTruthy();
  });

  it('should switch to edit mode', async () => {
    const user = userEvent.setup();
    const { container } = renderWithProvider(<Component />);
    const modeSelect = screen.getByTestId('select-mode').firstElementChild;
    modeSelect && fireEvent.mouseDown(modeSelect);
    await waitFor(() => screen.getAllByText('Edit')[0]);
    await user.click(screen.getAllByText('Edit')[0]);

    expect(container).toBeTruthy();
  });

  it('should switch to edit mode then cancel', async () => {
    const user = userEvent.setup();
    const { container } = renderWithProvider(<Component />);

    const modeSelect = screen.getByTestId('select-mode').firstElementChild;
    modeSelect && fireEvent.mouseDown(modeSelect);
    await waitFor(() => screen.getAllByText('Edit')[0]);
    await user.click(screen.getAllByText('Edit')[0]);

    await waitFor(() => screen.getByTestId('button-cancel'));
    const cancelButton = screen.getByTestId('button-cancel');
    await waitFor(() => userEvent.click(cancelButton));

    expect(container).toBeTruthy();
  });

  it('should switch to edit mode then save', async () => {
    const user = userEvent.setup();
    const { container } = renderWithProvider(<Component />);

    const modeSelect = screen.getByTestId('select-mode').firstElementChild;
    modeSelect && fireEvent.mouseDown(modeSelect);
    await waitFor(() => screen.getAllByText('Edit')[0]);
    await user.click(screen.getAllByText('Edit')[0]);

    await waitFor(() => screen.getByTestId('button-save'));
    const saveButton = screen.getByTestId('button-save');
    await waitFor(() => userEvent.click(saveButton));

    expect(container).toBeTruthy();
  });
});
