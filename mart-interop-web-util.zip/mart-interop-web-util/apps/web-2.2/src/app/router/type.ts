export interface IRoute {
    isPrivate?: boolean;
    hasSidebar?: boolean;
    path?: string;
    name?: string;
    key?: string;
    element?: JSX.Element;
    children?: IRoute[];
}
