import { clearAccessToken, clearUserCredential, getErrorMessage, setAccessToken, setRefreshToken } from './helpers'
import { ACCESS_TOKEN, REFRESH_TOKEN } from 'constants/common'

describe('API helpers', () => {
  jest.spyOn(Object.getPrototypeOf(window.localStorage), 'setItem')
  jest.spyOn(Object.getPrototypeOf(window.localStorage), 'removeItem')
  Object.setPrototypeOf(window.localStorage.setItem, jest.fn())
  Object.setPrototypeOf(window.localStorage.removeItem, jest.fn())

  it('should get error message correctly', () => {
    const errorResponse = {
      response: { data: { message: 'test1' } }
    }
    expect(getErrorMessage(errorResponse)).toEqual('test1')

    const errorMessage = new Error('test2')
    expect(getErrorMessage(errorMessage)).toEqual('test2')

    const defaultMessage = 'default message'
    expect(getErrorMessage({}, defaultMessage)).toEqual('default message')
  })
  it('should set access token correctly', () => {
    setAccessToken('test')
    expect(window.localStorage.setItem).toHaveBeenCalledWith(ACCESS_TOKEN, 'test')
  })
  it('should refresh token successfully', () => {
    setRefreshToken('new-token')
    expect(window.localStorage.setItem).toHaveBeenCalledWith(REFRESH_TOKEN, 'new-token')
  })
  it('should clear access token successfully', () => {
    clearAccessToken()
    expect(window.localStorage.removeItem).toHaveBeenCalledWith(ACCESS_TOKEN)
  })
  it('should clear refresh token successfully', () => {
    clearAccessToken()
    expect(window.localStorage.removeItem).toHaveBeenCalledWith(ACCESS_TOKEN)
  })
  it('should clear user credential successfully', () => {
    clearUserCredential()
    expect(window.localStorage.removeItem).toHaveBeenCalledWith(ACCESS_TOKEN)
    expect(window.localStorage.removeItem).toHaveBeenCalledWith(REFRESH_TOKEN)
  })
})
