module.exports = {
  process() {
    return { code: '' };
  }
};
