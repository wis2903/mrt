import { TIME_FORMAT } from 'constants/common'
import dayjs from 'dayjs'
import { GetOrdersParams, Order, OrderDetail, OrderSearchApi } from 'types/Orders'

export const genOrderNumber = (order: Order | OrderDetail) => order?.haravanOrderNumber || order?.orderId
export const prepareGetOrdersParams = (params: GetOrdersParams): OrderSearchApi | undefined => {
  return {
    page: params?.pageNumber ? params.pageNumber - 1 : undefined,
    size: params?.pageSize,
    districtId: params.search?.districtId,
    provinceId: params.search?.provinceId,
    warehouseId: params.search?.warehouseId,
    createdDateFrom: params.search?.createdDate?.[0]
      ? dayjs(params.search?.createdDate?.[0]).startOf('date').format(TIME_FORMAT)
      : params.search?.createdDateFrom
      ? dayjs(params.search?.createdDateFrom).startOf('date').format(TIME_FORMAT)
      : undefined,
    createdDateTo: params.search?.createdDate?.[1]
      ? dayjs(params.search?.createdDate?.[1]).endOf('date').format(TIME_FORMAT)
      : params.search?.createdDateTo
      ? dayjs(params.search?.createdDateTo).endOf('date').format(TIME_FORMAT)
      : undefined,
    filterSearch: params.search?.search?.trim?.(),
    statusList: params.search?.statusId,
    status: params.search?.statusId,
    grandTotalFrom: params.search?.totalFrom,
    grandTotalTo: params.search?.totalTo || undefined,
    isGetAll: params?.search?.isGetAll,
    orderType: params?.search?.type,
  }
}
