import { PromotionStatusType, InactivePromotionSubStatusType } from 'types/Promotions'

export enum PromotionStatus {
  Active = 1,
  Inactive = 2
}

export enum InactivePromotionSubStatus {
  Unknown = -1,
  Discontinued = 1,
  Expired = 2,
  SoldOut = 3
}

export interface PromotionStatusMasterData {
  code: PromotionStatusType | InactivePromotionSubStatusType
  name: string
}

export const PROMOTION_STATUS_MASTER_DATA: PromotionStatusMasterData[] = [
  {
    code: PromotionStatus.Active,
    name: 'Active promos'
  },
  {
    code: PromotionStatus.Inactive,
    name: 'Inactive promos'
  }
]

export interface PromotionSubstatusTags extends PromotionStatusMasterData {
  tagConfig?: {
    tagClassName?: string
    textClassName?: string
    borderClassName?: string
  }
}

export const ACTIVE_PROMOTION_SUBSTATUS_MASTER_DATA: PromotionSubstatusTags[] = [
  {
    code: PromotionStatus.Active,
    name: 'Active',
    tagConfig: {
      tagClassName: 'bg-[#c7ffe9]',
      textClassName: 'text-[#077d52] whitespace-nowrap',
      borderClassName: ''
    }
  }
]

export const InactivePromotionSubStatusName = {
  DEACTIVATED: 'Deactivated',
  EXPIRED: 'Expired',
  SOLD_OUT: 'Sold out',
  DISCONTINUED: 'Discontinued'
}
export const INACTIVE_PROMOTION_SUBSTATUS_MASTER_DATA: PromotionSubstatusTags[] = [
  {
    code: InactivePromotionSubStatus.Expired,
    name: InactivePromotionSubStatusName.EXPIRED,
    tagConfig: {
      textClassName: 'whitespace-nowrap'
    }
  },
  {
    code: InactivePromotionSubStatus.SoldOut,
    name: InactivePromotionSubStatusName.SOLD_OUT,
    tagConfig: {
      textClassName: 'whitespace-nowrap'
    }
  },
  {
    code: InactivePromotionSubStatus.Discontinued,
    name: InactivePromotionSubStatusName.DISCONTINUED,
    tagConfig: {
      tagClassName: 'bg-[#ffdee4]',
      textClassName: 'text-[#c31424] whitespace-nowrap',
      borderClassName: ''
    }
  }
]

export const inactivePromotionSubStatusOptions = [
  {
    label: 'All',
    value: undefined
  },
  {
    label: InactivePromotionSubStatusName.EXPIRED,
    value: InactivePromotionSubStatus.Expired
  },
  {
    label: InactivePromotionSubStatusName.SOLD_OUT,
    value: InactivePromotionSubStatus.SoldOut
  },
  {
    label: InactivePromotionSubStatusName.DISCONTINUED,
    value: InactivePromotionSubStatus.Discontinued
  }
]

export const DEAL_TYPE = {
  ORDER: 1,
  MOQ_ITEM_PERCENTAGE: 2,
  CART_AMOUNT_FLAT: 3,
  MOQ_ITEM_FLAT: 4,
  COMBO_ITEM_PERCENTAGE: 5,
  COMBO_ITEM_FLAT: 6,
  COMBO_SET_PERCENTAGE: 7,
  COMBO_SET_FLAT: 8,
  COMBO: -2
}

export const DEAL_TYPE_2_STRING = {
  [DEAL_TYPE.ORDER]: 'Order discount',
  [DEAL_TYPE.CART_AMOUNT_FLAT]: 'Order discount',
  [DEAL_TYPE.COMBO_ITEM_FLAT]: 'Combo discount',
  [DEAL_TYPE.COMBO_SET_FLAT]: 'Combo discount',
  [DEAL_TYPE.COMBO_SET_PERCENTAGE]: 'Combo discount',
  [DEAL_TYPE.COMBO_ITEM_PERCENTAGE]: 'Combo discount',
  [DEAL_TYPE.MOQ_ITEM_FLAT]: 'SKU minimum qty discount',
  [DEAL_TYPE.MOQ_ITEM_PERCENTAGE]: 'SKU minimum qty discount'
}

export const dealTypeOptions = [
  {
    label: 'Combo discount',
    value: DEAL_TYPE.COMBO
  },
  {
    label: 'Order discount',
    value: DEAL_TYPE.ORDER
  },
  {
    label: 'SKU minimum qty discount',
    value: DEAL_TYPE.MOQ_ITEM_PERCENTAGE
  }
]
