export interface AddSkuForm {
  skuId?: string;
  name: string;
  description: string;
  category?: SelectOptions;
  brand?: SelectOptions;
  usageDays?: number;
  code: string;
  tax: number;
  country?: SelectOptions;
  source?: string;
  skuConfigurations: {
    id?: number;
    name?: string;
    generatedName?: string;
    quantity?: number;
    barcode?: number;
    image: string;
    isPrimary?: boolean;
    grossWeight?: number;
    netWeight?: number;
    volume?: number;
    amastSellable?: boolean;
  }[];
  displayNinjaMartOnZalo?: boolean;
  displayDms?: boolean;
  displayNinjaMartOnWhatsapp?: boolean;
  displayHaravan?: boolean;
  sources?: {
    [key: string]: boolean;
  }[];
}

export interface SKUConfigurationForm {
  id: number;
  name: string;
  generatedName: string;
  quantity: number;
  barcode?: number;
  grossWeight?: number;
  netWeight?: number;
  volume?: number;
  isPrimary: boolean;
  image: string;
  amastSellable?: boolean;
}

export interface InitialValueSkuForm extends Omit<AddSkuForm, 'brand' | 'category' | 'country'> {
  brand?: SelectOptions;
  category?: SelectOptions;
  country?: SelectOptions;
}
