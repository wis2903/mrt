import React from 'react';
import countriesJson from '../@mock/country.json';
import districtJson from '../@mock/district.json';
import provincesJson from '../@mock/province.json';
import wardJson from '../@mock/ward.json';

import { AppContext as Webv1AppContext } from '../../../../web/src/v2/app/providers/app.provider';
import { useToastProvider } from '../../core/component/toast';
import { ToastTypeEnum } from '../../core/component/toast/type';
import { token } from '../../core/foundation/token';
import { PandaEvent } from '../../core/shared/event';
import { PandaDebouncer } from '../../core/shared/lib/debouncer';
import { PandaObject } from '../../core/shared/lib/object';
import { parseJwt } from '../../core/shared/util';
import { link } from '../../core/store';
import { ILinkedComponentProps } from '../../core/store/type';
import { useI18nProvider } from '../provider/i18n';
import { extractMasterDataFromResponse } from '../service/master';
import { Brand } from '../shared/object/brand';
import { Category } from '../shared/object/category';
import { Country } from '../shared/object/country';
import { District } from '../shared/object/district';
import { Province } from '../shared/object/province';
import { Warehouse } from '../shared/object/warehouse';
import { EventTypeEnum, StorageKeyEnum } from '../shared/type';
import { ILayoutProps } from './type';
import { Ward } from '../shared/object/ward';

export const loadFontAssets = (): Promise<void> =>
    new Promise((resolve) => {
        const head = document.getElementsByTagName('head')[0];
        const link = document.createElement('link');
        link.href = token.get<string>('global.typo.font-url');
        link.rel = 'stylesheet';
        head.appendChild(link);
        resolve();
    });

export const LayoutFetcher = link(
    ({ store, isPrivate }: ILayoutProps & ILinkedComponentProps): JSX.Element => {
        const { masterData: webv1MasterData } = React.useContext(Webv1AppContext);
        const { open: openToast } = useToastProvider();
        const { translate, lang } = useI18nProvider();

        const [updateMasterDataAsFetchedDebouncer] = React.useState<PandaDebouncer>(
            new PandaDebouncer(50)
        );
        const [triggerMasterDataFetchedEventDebouncer] = React.useState<PandaDebouncer>(
            new PandaDebouncer(200)
        );

        const handleExtractMasterData = (): void => {
            const { warehouses, brands, categories } = extractMasterDataFromResponse({
                data: new PandaObject(webv1MasterData).get('raw'),
            });
            const provinces: Province[] = [];
            const countries: Country[] = [];
            const districts: District[] = districtJson.map((item) => new District(item));
            const wards: Ward[] = wardJson.map((item) => new Ward(item));

            try {
                const accessToken = String(localStorage.getItem(StorageKeyEnum.accessToken) || '');
                const userData = new PandaObject(parseJwt(accessToken));
                const userRoles = userData.get('realm_access.roles');
                const userGoogleAccountName = String(userData.get('name') || '');
                const userProvinceIdList = userData.get('province');

                store.update('account.googleAccountName', userGoogleAccountName);
                if (Array.isArray(userRoles)) store.update('account.roles', userRoles);
                if (!Array.isArray(userProvinceIdList)) throw new Error();

                userProvinceIdList.forEach((provinceId) => {
                    const prvnJson = provincesJson.find((item) => item.id === Number(provinceId));
                    if (!prvnJson) return;
                    const province = new Province(prvnJson);
                    const country = province.country;
                    if (!provinces.find((p) => p.id === province.id)) {
                        provinces.push(province);
                    }
                    if (country && !countries.find((c) => c.id === country.id)) {
                        countries.push(country);
                    }
                });
            } catch (e) {
                // handle error
            } finally {
                store.update('master.countries', Country.sort(countries));
                store.update('master.provinces', Province.sort(provinces));
                store.update('master.districts', District.sort(districts));
                store.update('master.wards', Ward.sort(wards));
                store.update('master.warehouses', Warehouse.sort(warehouses));
                store.update('master.brands', Brand.sort(brands));
                store.update('master.categories', categories);
                store.update('master.categoriesGroup', Category.group(categories));
                store.update(
                    'master.map.countryCodeToCountry',
                    countriesJson.reduce<Record<string, Country>>((map, item) => {
                        map[item.code] = new Country(item);
                        return map;
                    }, {})
                );
                store.update(
                    'master.map.countryIdToCountry',
                    countriesJson.reduce<Record<string, Country>>((map, item) => {
                        map[item.id] = new Country(item);
                        return map;
                    }, {})
                );
                store.update(
                    'master.map.provinceIdToProvince',
                    provincesJson.reduce<Record<string, Province>>((map, item) => {
                        map[item.id] = new Province(item);
                        return map;
                    }, {})
                );
                store.update(
                    'master.map.districtIdToDistrict',
                    districts.reduce<Record<string, District>>((map, item) => {
                        map[item.id] = item;
                        return map;
                    }, {})
                );
                store.update(
                    'master.map.wardIdToWard',
                    wards.reduce<Record<string, Ward>>((map, item) => {
                        map[item.id] = item;
                        return map;
                    }, {})
                );
                store.update(
                    'master.map.warehouseIdToWarehouse',
                    warehouses.reduce<Record<string, Warehouse>>((map, item) => {
                        map[item.id] = item;
                        return map;
                    }, {})
                );
                store.update(
                    'master.map.warehouseAmastCodeToWarehouse',
                    warehouses.reduce<Record<string, Warehouse>>((map, item) => {
                        map[item.amastCode] = item;
                        return map;
                    }, {})
                );
                store.update(
                    'master.map.brandIdToBrand',
                    brands.reduce<Record<string, Brand>>((map, item) => {
                        map[item.id] = item;
                        return map;
                    }, {})
                );
                store.update(
                    'master.map.brandCodeToBrand',
                    brands.reduce<Record<string, Brand>>((map, item) => {
                        map[item.code] = item;
                        return map;
                    }, {})
                );
                store.update(
                    'master.map.categoryIdToCategory',
                    categories.reduce<Record<string, Category>>((map, item) => {
                        map[item.id] = item;
                        return map;
                    }, {})
                );
                store.update(
                    'master.map.categoryAmastIdToCategory',
                    categories.reduce<Record<string, Category>>((map, item) => {
                        map[item.amastId] = item;
                        return map;
                    }, {})
                );
                store.update(
                    'master.map.categoryCodeToCategory',
                    categories.reduce<Record<string, Category>>((map, item) => {
                        map[item.code] = item;
                        return map;
                    }, {})
                );
                store.update('master.timestamp', +new Date());
                store.update('account.fetched', true);
                updateMasterDataAsFetchedDebouncer.execute(() => {
                    store.update('master.fetched', true);
                    triggerMasterDataFetchedEventDebouncer.execute(() => {
                        PandaEvent.instance.triggerEventListeners(EventTypeEnum.masterDataFetched);
                    });
                });
            }
        };

        React.useEffect(() => {
            const requestErrorListener = {
                type: EventTypeEnum.responseError,
                callback: (data: unknown): void => {
                    openToast({
                        type: ToastTypeEnum.error,
                        message: String(data || translate('general.message.request-error')),
                    });
                },
            };
            const requestSuccessListener = {
                type: EventTypeEnum.responseSuccess,
                callback: (): void => {
                    openToast({
                        type: ToastTypeEnum.success,
                        message: translate('general.message.request-success'),
                    });
                },
            };
            PandaEvent.instance.addEventListener(requestErrorListener);
            PandaEvent.instance.addEventListener(requestSuccessListener);

            return (): void => {
                PandaEvent.instance.removeEventListener(requestErrorListener);
                PandaEvent.instance.removeEventListener(requestSuccessListener);
            };
        }, [lang]);

        React.useEffect(() => {
            if (!isPrivate || store.state.get('master.fetched')) return;
            handleExtractMasterData();
        }, [isPrivate]);

        React.useEffect(() => {
            if (!isPrivate || !store.state.get('master.timestampAlt')) return;
            handleExtractMasterData();
        }, [store.state.get('master.timestampAlt')]);

        return <></>;
    }
);
