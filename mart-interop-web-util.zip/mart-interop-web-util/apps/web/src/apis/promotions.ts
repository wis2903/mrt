import { apiMartClient } from './apiClient';
import {
    COUNT_PROMOTION_APPLIED_TIMES,
    CREATE_PROMOTIONS,
    DELETE_PROMOTIONS,
    GET_PROMOTIONS,
    GET_PROMOTIONSV2,
    SYNC_PROMOTIONS,
    VALIDATE_PROMOTIONS,
} from './apiUrl';
import {
    CreatePromotionParams,
    ExtendPromotionParams,
    GetPromotionsParams,
} from 'types/Promotions';
import {
    prepareCreatePromotionsParams,
    prepareGetPromotionsParams,
} from 'pages/Promotions/helpers';
import { AxiosResponse } from 'axios';
import qs from 'qs';

export const getPromotions = (params: GetPromotionsParams) => {
    return apiMartClient.get(GET_PROMOTIONS, {
        params: prepareGetPromotionsParams(params),
    });
};

export const getPromotionsV2 = (params: Record<string, unknown>) => {
    return apiMartClient.get(GET_PROMOTIONSV2, {
        params,
        paramsSerializer: (params) => qs.stringify(params, { arrayFormat: 'repeat' }),
    });
};

export const createPromotion = (params: CreatePromotionParams) => {
    return apiMartClient.post(CREATE_PROMOTIONS, prepareCreatePromotionsParams(params));
};

export const updatePromotion = (id: string, params: CreatePromotionParams) => {
    return apiMartClient.put(`${CREATE_PROMOTIONS}${id}`, prepareCreatePromotionsParams(params));
};

export const extendPromotion = (id: string, params: ExtendPromotionParams) => {
    return apiMartClient.patch(`${CREATE_PROMOTIONS}${id}`, params);
};

export const validatePromotion = (params: CreatePromotionParams) => {
    return apiMartClient.post(VALIDATE_PROMOTIONS, prepareCreatePromotionsParams(params));
};

export const getPromotionDetails = (id: string) => {
    return apiMartClient.get(`${GET_PROMOTIONS}${id}`);
};

export const deletePromotion = (id: string | number): Promise<AxiosResponse<any, any>> => {
    return apiMartClient.delete(`${DELETE_PROMOTIONS}${id}`);
};

export const syncPromotions = (provinceId: number): Promise<AxiosResponse<any, any>> => {
    return apiMartClient.post(SYNC_PROMOTIONS, {
        provinceId,
    });
};

export const countPromotionAppliedTimes = (
    id: string | number
): Promise<AxiosResponse<any, any>> => {
    return apiMartClient.get(COUNT_PROMOTION_APPLIED_TIMES.replace(':id', String(id)));
};
