import confirmModal from 'components/ConfirmModal';
import dayjs from 'dayjs';
import useLocales from 'hooks/useLocales';
import Content from 'layouts/components/Content';
import PageHeader from 'layouts/components/PageHeader';
import moment from 'moment';
import Filters from './Filters';
import Button from 'components/Button';
import CancelReasonSelection from './components/cancelReasonSelection/CancelReasonSelection';
import Checkbox from 'v2/kit/components/basic/checkbox/checkbox';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { MoreOutlined } from '@ant-design/icons';
import { Dropdown, Empty, Menu, Table, Tag, Tooltip, message } from 'antd';
import { ORDER_STATUS_MASTER_DATA } from 'constants/orders';
import { RequestStatus, useAsync } from 'hooks/useAsync';
import { trim } from 'lodash';
import { FormattedNumber } from 'react-intl';
import { Link, useSearchParams } from 'react-router-dom';
import { useAppDispatch, useAppSelector } from 'store/hooks';
import { Order } from 'types/Orders';
import { saveData } from 'utils/common';
import { selectors } from './slice';
import { ExportDropdownItem, OrdersStyled } from './styled';
import { useFetchOrders } from './useFetchOrders';
import { genOrderNumber } from './helpers';
import { getTextByLocale } from 'pages/Promotions/helpers';
import { ExportWrapper } from './styled';
import { AppV2ModuleEnum, AppV2Permission } from 'constants/ability';
import { export2CSV, isEmpty } from 'v2/app/helpers/utils.helper';
import { selectors as masterDataSelectors } from 'store/masterData/slice';
import { usePermission } from 'v2/app/layouts/permission-container/use-permission';
import { createDeliveryOrderAsync, exportOrders } from 'apis/orders';
import { DAY_MONTH_YEAR_TIME_FORMAT, DEFAULT_PAGE_SIZE, PAGE_SIZE_OPTIONS } from 'constants/common';
import { OrderTypeEnum } from 'v2/app/@types/enum.type';
import { downloadOrderItemsReport } from 'v2/app/helpers/report.helper';
import type { ColumnsType } from 'antd/es/table';
import {
    trackOrderClickActionMenu,
    trackOrderConfirmed,
    trackOrdersDetailClicked,
} from 'utils/mixpanel';

const Orders: React.FC = () => {
    const dispatch = useAppDispatch();
    const {
        loading,
        total,
        search,
        fetch: fetchOrders,
        fetchWithoutDispatch: fetchOrdersWithoutDispatch,
    } = useFetchOrders();
    const { t } = useLocales();
    const { hasPermission } = usePermission();
    const [searchParams, setSearchParams] = useSearchParams();
    const [enableExport, setEnableExport] = useState(false);
    const [exporting, setExporting] = React.useState<boolean>(false);
    const [isCancelling, setIsCancelling] = useState<boolean>(false);
    const warehouses = useAppSelector(masterDataSelectors.selectorByKey('warehouseList'));
    const provinces = useAppSelector(masterDataSelectors.selectorByKey('provinceList'));
    const orders = useAppSelector(selectors.selectOrders);
    const pageNumber = parseInt(searchParams.get('pn') || '1');
    const pageSize = parseInt(searchParams.get('ps') || DEFAULT_PAGE_SIZE.toString());

    useEffect(() => {
        const dateFrom = searchParams.get('cdf');
        const dateTo = searchParams.get('cdt');

        if (dateFrom === '-1' || dateTo === '-1') {
            setEnableExport(false);
            return;
        }

        if (dateFrom && dateTo) {
            const dateFromInMoment = moment(Number(dateFrom) * 1000);
            const dateToInMoment = moment(Number(dateTo) * 1000);
            const diff = Math.abs(moment(dateToInMoment).diff(moment(dateFromInMoment), 'month'));
            if (diff > 0) {
                setEnableExport(false);
                return;
            }
        }
        setEnableExport(true);
    }, [searchParams]);

    const handleCreateDeliveryOrder = useCallback(
        (record: Order) => () => {
            confirmModal({
                t,
                onOk: () => {
                    trackOrderConfirmed(record);
                    setIsCancelling(true);
                    createDeliveryOrderAsync({
                        id: record.orderId,
                        action: 'CONFIRM',
                    })
                        .then(() => {
                            fetchOrders();
                        })
                        .catch((error) => {
                            message.error(error.message);
                        })
                        .finally(() => {
                            setIsCancelling(false);
                        });
                },
            });
        },
        [dispatch, t]
    );

    const handleCancel = useCallback(
        (orderId: number | string) => () => {
            const confirm = confirmModal({
                t,
                title: t('Cancel order'),
                content: (
                    <CancelReasonSelection
                        onCancel={() => {
                            confirm.destroy();
                        }}
                        onOk={(reason) => {
                            confirm.destroy();
                            setIsCancelling(true);
                            createDeliveryOrderAsync({
                                id: orderId,
                                action: 'CANCEL',
                                reason,
                            })
                                .then(() => {
                                    fetchOrders();
                                })
                                .catch((error) => {
                                    message.error(error.message);
                                })
                                .finally(() => {
                                    setIsCancelling(false);
                                });
                        }}
                    />
                ),
                isDisabledFooter: true,
            });
        },
        [dispatch, t]
    );

    const onActionButtonVisibleChange = useCallback((visible: boolean, record: Order) => {
        if (visible) {
            trackOrderClickActionMenu(record);
        }
    }, []);
    const trackOnclickOrderDetail = useCallback((record: Order) => {
        trackOrdersDetailClicked(record);
    }, []);

    const _exportOrders = useAsync(async (version?: 'v1' | 'v2') => {
        try {
            setExporting(true);
            const requestData = {
                search,
                pageNumber,
                pageSize,
            };
            if (version === 'v1') {
                const { data } = await exportOrders(requestData);
                saveData(
                    data,
                    `Order_Transaction_Export_Item_Level_${moment().format('YYYYMMDD_HHmmss')}.xlsx`
                );
            } else {
                await downloadOrderItemsReport({
                    params: {
                        createDateFrom: search.createdDateFrom,
                        createDateTo: search.createdDateTo,
                        provinceId: search.provinceId,
                        districtId: search.districtId,
                        warehouseId: search.warehouseId,
                        search: search.search,
                        grandTotalFrom: search.totalFrom,
                        grandTotalTo: search.totalTo,
                        status: search.statusId,
                    },
                    warehousesList: warehouses,
                });
            }
        } catch (e) {
        } finally {
            setExporting(false);
        }
    }, false);

    const handleExportSimpleOrders = async (): Promise<void> => {
        setExporting(true);
        const _orders = await fetchOrdersWithoutDispatch();

        export2CSV(
            'Order_Transaction_Export_Order_Level',
            (_orders.length ? _orders : [{}]).map((item: any) => ({
                ['Mã đơn hàng']: item.haravanOrderNumber,
                ['Nguồn']: item.source,
                ['Tình trạng']: item.currentStatus,
                ['Lý do huỷ']: item.cancellationReason
                    ? getTextByLocale(String(item.cancellationReason), 'vi')
                    : '',
                ['Người hủy']: String(item.cancelBy || ''),
                ['Giá trước khuyến mãi']: String(item.total || 0),
                ['Giảm']: String(item.discount || 0),
                ['Giá sau khuyến mãi']: String(
                    Number(item.total || 0) - Number(item.discount || 0)
                ),
                ['Tổng trọng lượng (gram)']: String(Number(item.grossWeight || 0)),
                ['Mã nhân viên sale']: item.salePersonId ? String(item.salePersonId) : '',
                ['Outlet ID']: ((): string => {
                    const customerDetails = item.customerDetails as any;
                    return customerDetails?.customerZaloId || '';
                })(),
                ['Tên người nhận']: ((): string => {
                    const customerDetails = item.customerDetails as any;
                    if (!customerDetails) return '';
                    return customerDetails.customerName || '';
                })(),
                ['Địa chỉ nhận hàng']: ((): string => {
                    const shippingAddressDetails = item.shippingAddressDetails as any;
                    if (!shippingAddressDetails) return '';
                    return shippingAddressDetails.shippingAddress || '';
                })(),
                ['Phường/Xã nhận hàng']: ((): string => {
                    const shippingAddressDetails = item.shippingAddressDetails as any;
                    if (!shippingAddressDetails) return '';
                    return shippingAddressDetails.shippingWard || '';
                })(),
                ['Quận/Huyện nhận hàng']: ((): string => {
                    const shippingAddressDetails = item.shippingAddressDetails as any;
                    if (!shippingAddressDetails) return '';
                    return shippingAddressDetails.shippingDistrict || '';
                })(),
                ['Tỉnh/TP nhận hàng']: ((): string => {
                    const shippingAddressDetails = item.shippingAddressDetails as any;
                    if (!shippingAddressDetails) return '';
                    return shippingAddressDetails.shippingProvince || '';
                })(),
                ['Quốc gia']: ((): string => {
                    const shippingAddressDetails = item.shippingAddressDetails as any;
                    if (!shippingAddressDetails) return '';
                    return shippingAddressDetails.shippingCountry || '';
                })(),
                ['Kho hàng']: ((): string => {
                    const warehouseId = item.warehouseId;
                    const warehouse = warehouses.find((w) => w.id === warehouseId);
                    return warehouse?.name || '';
                })(),
                ['Số điện thoại thanh toán']: ((): string => {
                    const customerDetails = item.customerDetails as any;
                    if (!customerDetails) return '';
                    return `'${customerDetails.phoneNumber || ''}`;
                })(),
                ['Người nhận tự lấy hàng']: item.selfPickup ? 1 : '',
                ['Ghi chú']: item.note ? String(item.note) : '',
                ['Ngày tạo']: item.createdDate
                    ? dayjs(String(item.createdDate)).format(DAY_MONTH_YEAR_TIME_FORMAT)
                    : '',
                ['Thời gian cập nhật cuối']: item.lastUpdated
                    ? dayjs(String(item.lastUpdated)).format(DAY_MONTH_YEAR_TIME_FORMAT)
                    : '',
            }))
        );
        setExporting(false);
    };

    const columns: ColumnsType<Order> = useMemo(
        () => [
            {
                title: t('orders.no'),
                dataIndex: 'no',
                key: 'no',
            },
            {
                title: t('orders.Order Number'),
                dataIndex: 'orderId',
                key: 'orderId',
                render: (_, record) => (
                    <Link
                        to={`${record?.orderId}`}
                        onClick={() => {
                            trackOnclickOrderDetail(record);
                        }}
                    >
                        {genOrderNumber(record)}
                    </Link>
                ),
            },
            {
                title: t('orders.source'),
                key: 'source',
                dataIndex: 'source',
            },
            {
                title: t('common.Type'),
                key: 'type',
                dataIndex: 'type',
                render: (_, record) => {
                    return (
                        <span className="whitespace-nowrap">
                            {record.orderType === OrderTypeEnum.promptsale
                                ? 'Prompt-sale'
                                : 'Pre-sale'}
                        </span>
                    );
                },
            },
            {
                title: t('orders.customer'),
                key: 'customer',
                render: (_, { customerDetails }) =>
                    (trim(customerDetails?.customerName) ? customerDetails?.customerName : null) ||
                    customerDetails?.phoneNumber ||
                    customerDetails?.email,
            },
            {
                title: t('orders.province'),
                key: 'province',
                dataIndex: ['shippingAddressDetails', 'shippingProvince'],
                render: (_, { shippingAddressDetails }) => {
                    let _value: string | undefined = shippingAddressDetails.shippingDistrict
                        ? `${shippingAddressDetails.shippingProvince} \\ ${shippingAddressDetails.shippingDistrict}`
                        : shippingAddressDetails.shippingProvince;

                    if (isEmpty(_value)) {
                        const _provinceId = shippingAddressDetails.shippingProvinceId;
                        const _province = provinces.find(
                            (prvn) => Number(prvn.id) === Number(_provinceId)
                        );
                        _value = _province?.name;
                    }
                    return (
                        <span style={{ minWidth: '100px', display: 'inline-block' }}>
                            {_value || '-'}
                        </span>
                    );
                },
            },
            {
                title: t('orders.quantity'),
                key: 'quantity',
                dataIndex: 'totalQuantity',
                align: 'right',
                render: (_, { totalQuantity }) => <FormattedNumber value={totalQuantity || 0} />,
            },
            {
                title: t('orders.grandTotal'),
                key: 'grandTotal',
                dataIndex: 'grandTotal',
                align: 'right',
                render: (_, { grandTotal: _total }) => {
                    return <FormattedNumber value={_total || 0} />;
                },
            },
            {
                title: (
                    <>
                        {t('sku.grossWeight')}
                        <br />
                        (gram)
                    </>
                ),
                key: 'grossWeight',
                dataIndex: 'grossWeight',
                align: 'right',
                render: (_, { grossWeight }) => (
                    <FormattedNumber value={Math.round(grossWeight || 0)} />
                ),
            },
            {
                title: t('orders.createdAt'),
                key: 'createdDate',
                dataIndex: 'createdDate',
                align: 'right',
                render: (_, { createdDate }) =>
                    dayjs(createdDate).format(DAY_MONTH_YEAR_TIME_FORMAT),
            },
            {
                title: t('orders.selfPickup'),
                key: 'selfPickup',
                dataIndex: 'selfPickup',
                align: 'center',
                render: (_, { selfPickup }) => (selfPickup ? <Checkbox disabled checked /> : ' '),
            },
            {
                title: t('orders.status'),
                key: 'status',
                dataIndex: 'status',
                align: 'center',
                render: (_, { currentStatus }) => {
                    if (!currentStatus) return '-';
                    const orderStatus = ORDER_STATUS_MASTER_DATA.find(
                        (order) => order.code.toLowerCase() === currentStatus.toLowerCase()
                    );
                    if (!orderStatus) return '-';
                    return <Tag color={orderStatus?.color}>{t(orderStatus?.name || '')}</Tag>;
                },
            },
        ],
        [
            handleCancel,
            handleCreateDeliveryOrder,
            onActionButtonVisibleChange,
            t,
            trackOnclickOrderDetail,
        ]
    );

    if (
        hasPermission([
            {
                module: AppV2ModuleEnum.Order,
                permission: AppV2Permission.Update,
            },
        ])
    ) {
        columns.push({
            title: t('common.button.actions'),
            key: 'action',
            align: 'center',
            render: (_, record) => {
                const menuItems: any[] = [];
                if ((record.currentStatus || '').toUpperCase() === 'CREATED') {
                    menuItems.push({
                        key: '1',
                        label: t('orders.actions.confirm'),
                        onClick: handleCreateDeliveryOrder(record),
                    });
                    menuItems.push({
                        key: '2',
                        label: t('orders.actions.cancel'),
                        onClick: handleCancel(record.orderId),
                    });
                } else if ((record.currentStatus || '').toUpperCase() === 'PLACED') {
                    menuItems.push({
                        key: '2',
                        label: t('orders.actions.cancel'),
                        onClick: handleCancel(record.orderId),
                    });
                } else if ((record.currentStatus || '').toUpperCase() === 'PROCESSING') {
                    menuItems.push({
                        key: '2',
                        label: t('orders.actions.cancel'),
                        onClick: handleCancel(record.orderId),
                    });
                } else if ((record.currentStatus || '').toUpperCase() === 'DELIVERY') {
                    menuItems.push({
                        key: '2',
                        label: t('orders.actions.cancel'),
                        onClick: handleCancel(record.orderId),
                    });
                } else {
                    return null;
                }
                return (
                    <Dropdown
                        onVisibleChange={(visible) => {
                            onActionButtonVisibleChange(visible, record);
                        }}
                        trigger={['click']}
                        overlay={<Menu items={menuItems} />}
                        placement="bottomRight"
                    >
                        <Button className="actions p-1 m-auto">
                            <MoreOutlined />
                        </Button>
                    </Dropdown>
                );
            },
        });
    }

    return (
        <OrdersStyled>
            <PageHeader
                title={t('orders.title')}
                extra={[
                    hasPermission([
                        {
                            module: AppV2ModuleEnum.Order,
                            permission: AppV2Permission.Export,
                        },
                    ]) ? (
                        <ExportWrapper>
                            {!enableExport && (
                                <span>{t('Can not export data in more than 1 month')}</span>
                            )}
                            <Dropdown
                                key="export"
                                trigger={['click']}
                                disabled={!enableExport || exporting}
                                overlay={
                                    <Menu
                                        items={[
                                            {
                                                key: 'orders-export',
                                                label: (
                                                    <ExportDropdownItem
                                                        disabled={!enableExport}
                                                        onClick={handleExportSimpleOrders}
                                                        className="export-dropdown-item"
                                                    >
                                                        {t('Orders level')}
                                                    </ExportDropdownItem>
                                                ),
                                            },
                                            {
                                                key: 'order-skus-export-v2',
                                                label: (
                                                    <ExportDropdownItem
                                                        disabled={!enableExport}
                                                        onClick={(): void => {
                                                            _exportOrders.execute('v2');
                                                        }}
                                                        className="export-dropdown-item"
                                                    >
                                                        {t('Order items level')}
                                                    </ExportDropdownItem>
                                                ),
                                            },
                                        ]}
                                    />
                                }
                                placement="bottomRight"
                            >
                                <Button
                                    loading={
                                        _exportOrders.status === RequestStatus.Pending || exporting
                                    }
                                >
                                    {exporting ? `${t('Processing')}...` : t('Export')}
                                </Button>
                            </Dropdown>
                        </ExportWrapper>
                    ) : undefined,
                ]}
            />
            <Content>
                <Filters />
                <Table
                    locale={{
                        emptyText: (
                            <Empty
                                image={Empty.PRESENTED_IMAGE_SIMPLE}
                                description={t('common.No Data')}
                            />
                        ),
                    }}
                    loading={loading || isCancelling}
                    columns={columns}
                    dataSource={orders?.map((order, index) => ({
                        ...order,
                        no: (index % pageSize) + 1,
                    }))}
                    rowKey={'orderId'}
                    pagination={{
                        total,
                        showTotal: (_total, range) =>
                            t('common.message.showingFromTo', {
                                from: range[0].toString(),
                                to: range[1].toString(),
                                total: _total.toString(),
                            }),
                        pageSize: pageSize,
                        current: pageNumber,
                        showLessItems: true,
                        hideOnSinglePage: !!total && total <= PAGE_SIZE_OPTIONS[0],
                        pageSizeOptions: PAGE_SIZE_OPTIONS,
                        onChange: (_pageNumber, _pageSize) => {
                            searchParams.set('pn', _pageNumber.toString());
                            searchParams.set('ps', _pageSize.toString());
                            setSearchParams(searchParams);
                        },
                    }}
                />
            </Content>
        </OrdersStyled>
    );
};

export default Orders;
