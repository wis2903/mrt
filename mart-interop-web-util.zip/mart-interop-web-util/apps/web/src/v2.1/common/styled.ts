import styled, { keyframes } from 'styled-components';

export const FADE_IN_ANIMATION = keyframes`
    0%{opacity: 0;}
    100% {opacity: 1;}
`;

export const HOVERED_BACKGROUND_COLOR = '#f5f5f5';

export const BUTTON_RESET = `
    background: #ffffff;
    border: 0;
    outline: 0;
`;

export const OVERLAY = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: 99998;
`;

export const StyledClickableComponentContainer = styled.button`
    ${BUTTON_RESET}

    &:hover {
        background-color: ${HOVERED_BACKGROUND_COLOR};
    }
`;

export const StyledInputComponentContainer = styled.input`
    ${BUTTON_RESET}

    &:hover {
        background-color: ${HOVERED_BACKGROUND_COLOR};
    }
`;

export const StyledFadedInContainer = styled.div`
    animation: ${FADE_IN_ANIMATION} linear 0.2s;
`;
