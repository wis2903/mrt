import { DEAL_TYPE } from 'constants/promotions'

export enum ComboDiscountTypeEnum {
  priceAfterDiscount = 1,
  discountAmount = 2,
  discountPercent = 3
}

export enum ComboDiscountAffectionEnum {
  eachSKU = 1,
  theWholeCombo = 2
}

export enum PromotionDealType {
  ORDER = DEAL_TYPE.ORDER,
  COMBO_ITEM_FLAT = DEAL_TYPE.COMBO_ITEM_FLAT,
  COMBO_SET_FLAT = DEAL_TYPE.COMBO_SET_FLAT,
  MOQ_ITEM_FLAT = DEAL_TYPE.MOQ_ITEM_FLAT,
  MOQ_ITEM_PERCENTAGE = DEAL_TYPE.MOQ_ITEM_PERCENTAGE
}

export enum PromotionApplyLimitation {
  unlimited = -1
}

export enum AMAST_UOM {
  CT = 'CT',
  UN = 'UN'
}

export interface IComboSKU {
  skuId?: string
  uom?: string
  qty?: number
}

export interface IUOMData {
  id: string | number
  name: string
  sellingPrice?: number
  isPrimary?: boolean
}
