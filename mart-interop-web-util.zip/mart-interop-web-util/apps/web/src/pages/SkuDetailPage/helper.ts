import { SKUConfiguration } from 'types/SKUDetail';

export const prepareSKUConfigurations = (skuConfigurations: SKUConfiguration[]) => {
  return skuConfigurations.map((skuConfiguration) => {
    return {
      ...skuConfiguration,
      image: skuConfiguration.imageUrls[0]
    };
  });
};
