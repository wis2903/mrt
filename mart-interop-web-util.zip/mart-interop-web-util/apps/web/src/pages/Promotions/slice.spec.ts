import { apiMartClient } from 'apis/apiClient'
import sinon from 'sinon'
import store from 'store/store'
import { reducerActions, sagaActions, sagaOption } from './slice'

const stub = sinon.stub(apiMartClient, 'get')
describe('sagaActions', () => {
  afterEach(() => {
    jest.clearAllMocks()
  })
  it('fetchPromotions successfully', async () => {
    stub.callsFake(
      () =>
        ({
          data: {
            data: {
              data: [
                {
                  id: 1
                }
              ],
              total: 12
            }
          }
        } as any)
    )
    const spyAction = jest.spyOn(reducerActions, 'fetchPromotionsSuccess')

    await store.runSaga(sagaOption.caseSagas.fetchPromotions, { payload: { pageNumber: 1, pageSize: 20 } }).toPromise()
    expect(spyAction).toBeCalledWith({
      promotions: [
        {
          id: 1
        }
      ],
      total: 12
    })
  })
  it('fetchOrders failed', async () => {
    stub.rejects()
    const spyAction = jest.spyOn(reducerActions, 'fetchPromotionsSuccess')

    await store.runSaga(sagaOption.caseSagas.fetchPromotions, { payload: { pageNumber: 1, pageSize: 20 } }).toPromise()
    expect(spyAction).not.toBeCalled()
  })
})
