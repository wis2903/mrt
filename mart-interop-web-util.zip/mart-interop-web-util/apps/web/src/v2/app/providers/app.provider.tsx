/* eslint-disable react-hooks/exhaustive-deps */
import React from 'react';
import Dialog, { IOnDialogLoadedAPI } from '../components/dialog/dialog';
import GlobalLoader from '../components/loader/global-loader';

import { LOCAL_STORAGE_KEY } from 'constants/common';
import { reducerActions } from 'containers/LanguageProvider/slices';
import { Outlet, useNavigate } from 'react-router-dom';
import { useAppDispatch } from 'store/hooks';
import { IAppContext, IAppContextUser } from 'v2/app/@types/context.type';
import { ICountry, IMasterData, IProvince } from 'v2/app/@types/data.type';
import { DEFAULT_LANG, EMPTY_MASTER_DATA, STORAGE_KEY } from 'v2/app/constants/common.constant';
import { isEmpty, parseJwt } from 'v2/app/helpers/utils.helper';
import { masterService } from 'v2/app/services/master.service';
import { fm } from '../../../../../web-2.2/src/app/provider/feature';
import { FeatureCodeEnum } from '../../../../../web-2.2/src/app/provider/feature/type';
import { PlainTextComponent } from '../../../../../web-2.2/src/core/component/plain';
import { token } from '../../../../../web-2.2/src/core/foundation/token';
import { PandaText } from '../../../../../web-2.2/src/core/shared/lib/text';
import { LangEnum } from '../@types/enum.type';
import { useLocale } from '../hooks/useLocale.hook';
import { storageService } from '../services/storage.service';

const APP_CONTEXT_DEFAULT_VALUE: IAppContext = {
    isFetchedData: false,
    isLoadingData: true,
    masterData: EMPTY_MASTER_DATA,
    activeProvinces: [],
    activeCountries: [],
    activeProvincesMatchSelectedCountryId: [],
    selectedProvinceId: -1,
    selectedCountryId: -1,
    defaultCountryId: -1,
    lang: LangEnum.en,
    user: {
        name: '',
    },
    cache: {},
    updateLang: () => undefined,
    updateSelectedProvinceId: () => undefined,
    updateSelectedCountryId: () => undefined,
    updateCache: () => undefined,
    updateMasterData: () => undefined,
    updateActiveProvincesMatchSelectedCountryId: () => undefined,
};

export const AppContext = React.createContext<IAppContext>(APP_CONTEXT_DEFAULT_VALUE);

export const AppProvider = (): JSX.Element => {
    const [state, setState] = React.useState<IAppContext>(APP_CONTEXT_DEFAULT_VALUE);

    const dispatch = useAppDispatch();
    const navigate = useNavigate();

    const fetchMasterData = async (): Promise<void> => {
        if (state.masterData.fetched) return;

        const data = await masterService.get();

        let activeProvinces: IProvince[] = [];
        let activeCountries: ICountry[] = [];
        let activeProvincesMatchSelectedCountryId: IProvince[] = [];
        let selectedCountryId: number = -1;
        let defaultCountryId: number = -1;
        let selectedProvinceId: number = -1;
        const user: IAppContextUser = { name: '' };
        const token = localStorage.getItem(LOCAL_STORAGE_KEY.KC_TOKEN);
        if (token) {
            const parsedToken = parseJwt(token);
            user.name = String(parsedToken.name || '-');

            const activeProvinceIdList = parsedToken.province;
            const { countries } = data;
            if (Array.isArray(activeProvinceIdList)) {
                activeProvinces = data.provinces.filter((province) =>
                    activeProvinceIdList.find((id) => Number(id) === Number(province.id))
                );
            }

            if (fm.enabled(FeatureCodeEnum.prioritizedKhanhHoa)) {
                const activeProvincesGroupedByCountryId = activeProvinces.reduce<
                    Record<string, IProvince[]>
                >((group, item) => {
                    if (!group[String(item.countryId)]) group[item.countryId] = [item];
                    else group[String(item.countryId)].push(item);
                    return group;
                }, {});
                const arrayOfcountryIdInString: string[] = [];
                Object.keys(activeProvincesGroupedByCountryId).forEach((key) => {
                    arrayOfcountryIdInString.push(key);
                    activeProvincesGroupedByCountryId[key].sort((a, b) => {
                        if (!fm.enabled(FeatureCodeEnum.prioritizedKhanhHoa)) {
                            return a.name < b.name ? -1 : 1;
                        }

                        return new PandaText(a.name).noneViAccent.includes('khanh hoa') &&
                            !new PandaText(b.name).noneViAccent.includes('khanh hoa')
                            ? -1
                            : 1;
                    });
                });
                arrayOfcountryIdInString.sort((a, b) => (a > b ? -1 : 1));

                let sortedProvinces: IProvince[] = [];
                arrayOfcountryIdInString.forEach((cId) => {
                    sortedProvinces = [
                        ...sortedProvinces,
                        ...activeProvincesGroupedByCountryId[cId],
                    ];
                });
                activeProvinces = sortedProvinces;
            }

            activeCountries = activeProvinces.reduce<ICountry[]>((result, prvn) => {
                const cntr = countries.find((item) => item.id === prvn.countryId);
                if (cntr && !result.find((item) => item.id === cntr.id)) result.push(cntr);
                return result;
            }, []);

            selectedCountryId = activeCountries[0]?.id;
            defaultCountryId = activeCountries[0]?.id;
            activeProvincesMatchSelectedCountryId = activeProvinces.filter(
                (prvn) => prvn.countryId === selectedCountryId
            );
            selectedProvinceId = activeProvincesMatchSelectedCountryId[0]?.id;
        }

        const storedLang = storageService.get(STORAGE_KEY.lang);
        let lang = DEFAULT_LANG;
        if (!isEmpty(storedLang) && storedLang === LangEnum.vi) lang = LangEnum.vi;

        setState((current) => ({
            ...current,
            isFetchedData: true,
            isLoadingData: false,
            activeProvinces,
            activeCountries,
            activeProvincesMatchSelectedCountryId,
            selectedProvinceId,
            defaultCountryId,
            selectedCountryId,
            masterData: {
                ...data,
                fetched: true,
            },
            lang,
            updateLang: (l: LangEnum): void => {
                dispatch(reducerActions.switchLang(l));
                setState((crnt) => ({
                    ...crnt,
                    lang: l,
                }));
                storageService.set(STORAGE_KEY.lang, l);
            },
            updateSelectedProvinceId: (id: number): void => {
                setState((crnt) => ({
                    ...crnt,
                    selectedProvinceId: id,
                }));
            },
            updateSelectedCountryId: (id: number): void => {
                setState((crnt) => ({
                    ...crnt,
                    selectedCountryId: id,
                }));
            },
            updateCache: (data: Record<string, any>): void => {
                setState((crnt) => ({
                    ...crnt,
                    cache: data,
                }));
            },
            updateMasterData: (data: IMasterData): void => {
                setState((crnt) => ({
                    ...crnt,
                    masterData: data,
                }));
            },
            updateActiveProvincesMatchSelectedCountryId: (data: IProvince[]): void => {
                setState((crnt) => ({
                    ...crnt,
                    activeProvincesMatchSelectedCountryId: data,
                }));
            },
        }));
    };

    React.useEffect(() => {
        fetchMasterData();
    }, []);

    if (state.isLoadingData) return <GlobalLoader />;

    return (
        <AppContext.Provider value={state}>
            <Outlet />
            {state.masterData.hasError && <ErrorDialog />}
        </AppContext.Provider>
    );
};

const ErrorDialog = (): JSX.Element => {
    const { translate } = useLocale();

    const handleOnDialogLoaded = (api: IOnDialogLoadedAPI): void => {
        api.addOnOkListener((): void => {
            window.location.reload();
        });
        api.requestOpenDialog();
    };

    return (
        <Dialog
            isDisabledClose
            title={translate('common.label.error')}
            okButtonText={translate('common.label.refresh')}
            onLoaded={handleOnDialogLoaded}
            disabledButton={['cancel']}
        >
            <PlainTextComponent
                text={translate('common.dialog.errorMasterData')}
                color={token.get<string>('global.color.red-4')}
            />
        </Dialog>
    );
};
