import Router from './routes';
import 'styles/global.less';
import { AuthProvider } from 'AuthProvider';

function App() {
    return (
        <AuthProvider>
            <Router />
        </AuthProvider>
    );
}

export default App;
