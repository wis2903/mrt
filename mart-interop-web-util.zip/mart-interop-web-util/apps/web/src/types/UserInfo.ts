export type UserInfo = {
  id?: string | number;
  phone?: string | null;
  address?: string;
  district?: any;
  ward?: any;
};
