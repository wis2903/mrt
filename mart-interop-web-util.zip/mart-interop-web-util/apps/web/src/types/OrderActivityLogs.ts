import { Moment } from 'moment';

export type RangeValue = [Moment | null, Moment | null] | null;

export interface OrderActivityLogs {
  orderId: string;
  createdDate: string;
  source: string;
  sourceId: number;
  currentOrderStatus: string;
  syncDirection: string;
  syncStatus: string;
  haravanOrderNumber: string;
  requestLoggedDate: string;
  responseLoggedDate: string;
  createdBy: string;
}

export interface GetOrderActivityLogsParams {
  pageNumber: number;
  pageSize: number;
  search?: OrderActivityLogsFilterForm;
}

export interface OrderActivityLogsFilterForm {
  orderNumber?: string;
  orderStatusList?: string[];
  createdDate: RangeValue;
  currentOrderStatus?: string;
  syncStatus?: string;
  createdBy?: string;
  orderStatus?: string;
  syncDirection?: string;
  createdDateFrom?: string;
  createdDateTo?: string;
}
export interface OrderActivityLog {
  id: string;
  activityDate: string;
  createdBy: string;
  currentOrderStatus: string;
  syncDirection: string;
  syncStatus: string;
  activityDescription: string;
  receivedAt: string;
  succeededAt: string;
  createdDate: string;
  requestLoggedDate: string;
  responseLoggedDate: string;
}

export const SYNC_DIRECTIONS = [
  { id: 'HRV_ITO', name: 'HRV → ITO' },
  { id: 'ITO_HRV', name: 'ITO → HRV' },
  { id: 'ITO_ITO', name: 'ITO → ITO' },
  { id: 'ITO_WMS', name: 'ITO → WMS' },
  { id: 'WMS_ITO', name: 'WMS → ITO' },
  { id: 'ITO_AMS', name: 'ITO → AMS' },
  { id: 'AMS_ITO', name: 'AMS → ITO' }
];
