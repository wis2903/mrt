import { combineReducers } from '@reduxjs/toolkit';
import { Reducer } from 'redux';
import { reducer as languageReducer } from 'containers/LanguageProvider/slices';
import { reducer as loadingReducer } from 'containers/LoadingContainer/slices';
import { reducer as notificationReducer } from 'containers/NotificationContainer/slice';
import { reducer as masterReducer } from 'store/masterData/slice';
import { reducer as uiReducer } from 'containers/UiContainer/slices'

function createReducer(injectedReducers: { [key: string]: Reducer } = {}) {
  const rootReducer = combineReducers({
    masterData: masterReducer,
    language: languageReducer,
    notifications: notificationReducer,
    loading: loadingReducer,
    ui: uiReducer,
    ...injectedReducers
  });
  return rootReducer;
}

export default createReducer;
